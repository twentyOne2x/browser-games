#!/bin/bash
set -euo pipefail
repo=$(cd "$(dirname "$0")/.." && pwd)
work=$(dirname "$repo")
export W="$work"
# Install the SDK commit and 3.1.64 release recorded in SOURCE.txt first.
source "$work/emsdk/emsdk_env.sh"
export EM_CACHE="$work/engine-cache"
emcmake cmake -S "$repo" -B "$work/rebuilt-engine" -DCMAKE_BUILD_TYPE=Release
cmake --build "$work/rebuilt-engine" -j4
node "$repo/scripts/sanitize-runtime.mjs" "$work/rebuilt-engine/freedoom.js" "$work/rebuilt-engine/freedoom-sanitized.js"
# Outputs remain separate from the proven, reused runtime in site/.
