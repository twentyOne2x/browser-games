"""Reuse the pinned page, verify both official mirrors, then assemble site/."""
from pathlib import Path
import difflib
import io
import shutil
import subprocess
import tarfile
import urllib.request
import zipfile
import hashlib
import gzip

repo = Path(__file__).resolve().parent.parent
work = repo.parent
pin = 'c8b31bcf5e5ad889f955b645dab125836cbba80c'
base = work / 'browser-games'
if not (base / '.git').exists():
    subprocess.run(['git', 'clone', '--no-checkout', 'https://github.com/twentyone2x/browser-games', str(base)], check=True)
subprocess.run(['git', 'checkout', '--detach', pin], cwd=base, check=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=base, text=True).strip() == pin
print('PIN', pin)
site = repo / 'site'
(site / 'legal').mkdir(parents=True, exist_ok=True)
expected = {
    'freedoom.js': '46303dc5f99f58747316dcfeb9f4694f69fcaa0f2bd4a99addc57350878d2675',
    'freedoom.wasm': '95872882bc3a9431d5ebf058b9cd5d7ea682a6368d9608e04b56618f6efeff14',
    'legal/source.tar.gz': 'e76aa892b28382753461bde33f0b84d8dcaebe333dca1c62e2ba83ab0bbb5e59'
}
for name, digest in expected.items():
    src = base / 'doom' / name
    assert hashlib.sha256(src.read_bytes()).hexdigest() == digest, name
    print('PINNED_ASSET', name, src.stat().st_size, digest)
    dest = site / name if not name.startswith('legal/') else site / 'legal/original-engine-source.tgz'
    shutil.copyfile(src, dest)
archives = []
for host, tag in [('https://www.gamers.org', 'gamers'), ('https://youfailit.net', 'youfailit')]:
    url = host + '/pub/idgames/idstuff/doom/doom19s.zip'
    target = work / ('doom19s-' + tag + '.zip')
    if not target.exists():
        with urllib.request.urlopen(url, timeout=90) as response:
            target.write_bytes(response.read())
    data = target.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert len(data) == 2450688 and digest == 'cacf0142b31ca1af00796b4a0339e07992ac5f21bc3f81e7532fe1b5e1b486e6'
    print('ARCHIVE', url, len(data), digest)
    archives.append(data)
assert archives[0] == archives[1]
with zipfile.ZipFile(io.BytesIO(archives[0])) as outer:
    assert outer.testzip() is None
    joined = outer.read('DOOMS_19.1') + outer.read('DOOMS_19.2')
    for name in ['DOOMS_19.DAT', 'INSTALL.BAT']:
        assert (repo / 'legal' / name).read_bytes() == outer.read(name)
with zipfile.ZipFile(io.BytesIO(joined)) as inner:
    assert inner.testzip() is None
    wad = inner.read('DOOM1.WAD')
    assert len(wad) == 4196020
    assert hashlib.md5(wad).hexdigest() == 'f0cefca49926d00903cf57551d901abe'
    assert hashlib.sha1(wad).hexdigest() == '5b2e249b9c5133ec987b3ea77596381dc0d6bc1d'
    assert hashlib.sha256(wad).hexdigest() == '1d7d43be501e67d927e415e0b8f3e29c3bf33075e859721816f652a526cac771'
    (site / 'DOOM1.WAD').write_bytes(wad)
    for name in ['README.TXT', 'HELPME.TXT', 'ORDER.FRM', 'DM.DOC', 'DWANGO.DOC']:
        assert (repo / 'legal' / name).read_bytes() == inner.read(name)
print('WAD', len(wad), hashlib.sha256(wad).hexdigest())
for src in (repo / 'web').iterdir():
    shutil.copyfile(src, site / src.name)
for src in (repo / 'legal').iterdir():
    shutil.copyfile(src, site / 'legal' / src.name)
for name in ['SOURCE.txt', 'DATA.md']:
    shutil.copyfile(repo / name, site / 'legal' / name)
patch = ''.join(''.join(difflib.unified_diff(
    (base / 'doom' / name).read_text().splitlines(True),
    (repo / 'web' / name).read_text().splitlines(True),
    fromfile='doom/' + name, tofile='web/' + name))
    for name in ['game.js', 'index.html', 'style.css'])
(repo / 'patches/shareware-frame.patch').write_text(patch)
# Ship current wrapper, proof and documentation beside the unchanged engine source.
def stable(info):
    info.uid = info.gid = 0
    info.uname = info.gname = ''
    info.mtime = 0
    return info

with (site / 'legal/source.tgz').open('wb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as archive:
    for name in ['web', 'legal', 'proof', 'scripts', 'patches', '.codex/GOAL.md',
                 'SOURCE.txt', 'DATA.md', 'DECISION.md', 'README-HOST.md',
                 'DEPENDENCIES.md', 'package.json', 'package-lock.json']:
        path = repo / name
        if path.is_dir():
            for child in sorted(path.rglob('*')):
                if child.is_file() and 'out' not in child.relative_to(path).parts and '__pycache__' not in child.parts:
                    archive.add(child, arcname=str(child.relative_to(repo)), filter=stable)
        else:
            archive.add(path, arcname=name, filter=stable)
print('PASS prepared site with unchanged WAD and pinned engine')
