import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { once } from 'node:events';
import { chromium } from 'playwright';
const root = process.cwd(), W = process.env.W || path.dirname(root);
const output = path.join(root, 'proof/out');
fs.mkdirSync(path.join(output, 'logs'), { recursive: true });
const mode = process.argv[2] || 'full';
const siteDir = process.env.SITE_DIR || path.join(W,'site');
const inputs = Object.fromEntries(['index.html','game.js','style.css','freedoom.js','freedoom.wasm','DOOM1.WAD'].map(name=>[name,createHash('sha256').update(fs.readFileSync(path.join(siteDir,name))).digest('hex')]));
const siteInputs = Object.fromEntries(fs.readdirSync(siteDir,{recursive:true}).filter(name=>fs.statSync(path.join(siteDir,name)).isFile()).sort().map(name=>[name,createHash('sha256').update(fs.readFileSync(path.join(siteDir,name))).digest('hex')]));
const proofInputs = Object.fromEntries(['full.mjs','init.js','outer.html','plcheck.html','server.py','run.sh','mutations.py'].map(name=>[name,createHash('sha256').update(fs.readFileSync(path.join(root,'proof',name))).digest('hex')]));
const results = [], servers = [], runs = [], metrics = {};
const browserPids = [];
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const yawDelta = (a, b) => ((b - a + 540) % 360) - 180;
const state = frame => frame.evaluate(() => window.__proof.state());
const nativeState = frame => frame.evaluate(() => JSON.parse(Module.UTF8ToString(Module._Browser_State())));
let browser, portA, portB;
function invariant(name, pass, numbers) {
  results.push({ name, pass, numbers });
  console.log(`${pass ? 'PASS' : 'FAIL'} ${name} ${JSON.stringify(numbers)}`);
  if (!pass) throw new Error(name);
}
async function server(dir, sitePort = 0) {
  const args = [path.join(root, 'proof/server.py'), '--root', dir, '--proof', path.join(root, 'proof'), '--port-a', String(sitePort)];
  const child = spawn('python3', args, { stdio: ['ignore', 'pipe', 'pipe'] });
  servers.push(child);
  child.stderr.pipe(fs.createWriteStream(path.join(output, 'logs', `server-${child.pid}.log`)));
  const reader = createInterface({ input: child.stdout });
  const [line] = await once(reader, 'line'); const { port } = JSON.parse(line);
  console.log(`SERVER pid=${child.pid} bind=127.0.0.1 port=${port} range=false wasm_type=text/plain`);
  return port;
}
function pngStats(bytes) {
  let offset = 8, width, height, type, depth; const blocks = [];
  while (offset < bytes.length) {
    const length = bytes.readUInt32BE(offset), name = bytes.toString('ascii', offset + 4, offset + 8);
    const data = bytes.subarray(offset + 8, offset + 8 + length);
    if (name === 'IHDR') { width = data.readUInt32BE(0); height = data.readUInt32BE(4); depth = data[8]; type = data[9]; }
    if (name === 'IDAT') blocks.push(data);
    offset += length + 12;
  }
  if (depth !== 8 || ![2,6].includes(type)) throw new Error('Unsupported screenshot PNG format');
  const channels = type === 6 ? 4 : 3, stride = width * channels;
  const packed = zlib.inflateSync(Buffer.concat(blocks)), pixels = Buffer.alloc(stride * height);
  let input = 0;
  function paeth(a, b, c) {
    const p = a + b - c, pa = Math.abs(p-a), pb = Math.abs(p-b), pc = Math.abs(p-c);
    return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
  }
  for (let y = 0; y < height; ++y) {
    const filter = packed[input++];
    for (let x = 0; x < stride; ++x) {
      const n = y * stride + x, left = x >= channels ? pixels[n-channels] : 0;
      const above = y ? pixels[n-stride] : 0, upperLeft = y && x >= channels ? pixels[n-stride-channels] : 0;
      const add = filter === 1 ? left : filter === 2 ? above : filter === 3 ? Math.floor((left+above)/2) : filter === 4 ? paeth(left, above, upperLeft) : 0;
      pixels[n] = (packed[input++] + add) & 255;
    }
  }
  let sum = 0, squares = 0, samples = 0, nonblack = 0, min = 255, max = 0; const colors = new Set();
  for (let n = 0; n < pixels.length; n += channels * 17) {
    const r = pixels[n], g = pixels[n+1], b = pixels[n+2], brightness = (r+g+b)/3;
    if (brightness > 3) ++nonblack;
    sum += brightness; squares += brightness*brightness; ++samples; min = Math.min(min,brightness); max = Math.max(max,brightness);
    colors.add((r<<16) | (g<<8) | b);
  }
  const mean = sum/samples;
  return { width, height, samples, mean, stddev: Math.sqrt(squares/samples-mean*mean), range: max-min, colors: colors.size, nonblack: nonblack/samples };
}
async function shot(run, name) {
  const bytes = await (name.startsWith('touch-') ? run.page.locator('#g') : run.frame.locator('#canvas')).screenshot();
  invariant('screenshot fits delivery limit ' + name, bytes.length <= 600*1024, { bytes: bytes.length });
  fs.writeFileSync(path.join(output,mode === 'full' ? name : mode + '-' + name),bytes);
  return pngStats(bytes);
}
function diagnostics(page) {
  const d = { errors: [], failed: [], outside: [], dialogs: [], requests: [] };
  page.on('pageerror', e => { d.errors.push(e.message); console.log('BROWSER_ERROR',e.message); });
  page.on('console', m => {
    if (m.type() === 'error') { d.errors.push(m.text()); console.log('CONSOLE_ERROR',m.text()); }
    if (m.type() === 'warning') console.log('CONSOLE_WARNING',m.text());
  });
  const origins = [`http://localhost:${portA}`, `http://127.0.0.1:${portB}`];
  page.on('dialog', async dialog => { d.dialogs.push(dialog.type()); await dialog.dismiss(); });
  page.on('websocket', socket => d.outside.push(socket.url()));
  page.on('request', r => {
    d.requests.push(r.url());
    const gameRequest = r.frame().parentFrame() !== null;
    if (gameRequest ? new URL(r.url()).origin !== origins[0] : !origins.includes(new URL(r.url()).origin)) d.outside.push(r.url());
  });
  page.on('requestfailed', r => d.failed.push({ url: r.url(), error: r.failure()?.errorText }));
  page.on('response', r => { if (r.status() >= 400) d.failed.push({ url: r.url(), status: r.status() }); });
  return d;
}
async function createRun(options = {}, prefix = '', initScript = '', startGame = true) {
  const context = await browser.newContext({ viewport: { width: 1000, height: 640 }, ...options });
  await context.addInitScript({ path: path.join(root,'proof/init.js') });
  if (initScript) await context.addInitScript(initScript);
  const page = await context.newPage(), diag = diagnostics(page);
  const begin = performance.now();
  const query = options.isMobile ? `?mobile=1&width=${options.viewport.width}&height=${options.viewport.height}` : prefix ? '?prefix=1' : '';
  await page.goto(`http://127.0.0.1:${portB}/outer.html${query}`);
  const frame = page.frames().find(f => f.parentFrame());
  console.log('IFRAME', JSON.stringify(await page.locator('#g').evaluate(e => Object.fromEntries([...e.attributes].map(a => [a.name,a.value])))));
  await frame.waitForFunction(() => window.__proof && !document.getElementById('start').disabled, null, { timeout: 60000 });
  const loadMs = performance.now()-begin;
  const run = { context, page, frame, diag, loadMs }; runs.push(run);
  if (!startGame) return run;
  // A 1 ms timer captures native readiness and backing size together before rAF.
  await frame.evaluate(() => {
    window.__readySamples = [];
    const deadline = performance.now() + 60000;
    function sample() {
      const native = JSON.parse(Module.UTF8ToString(Module._Browser_State()));
      const canvas = document.getElementById('canvas'), box = canvas.getBoundingClientRect();
      const time = performance.now(), samples = window.__readySamples;
      if (native.ready) samples.push({ time, ready: native.ready, frame: [innerWidth, innerHeight],
        css: [box.width, box.height], backing: [canvas.width, canvas.height], dpr: devicePixelRatio,
        density: [canvas.width / box.width, canvas.height / box.height] });
      if (time < deadline && (!samples.length || time < samples[0].time + 800)) setTimeout(sample, 1);
    }
    setTimeout(sample, 1);
  });
  await frame.locator('#start')[options.hasTouch ? 'tap' : 'click']();
  run.startInput = await frame.evaluate(() => window.__inputLog.filter(e => e.type === 'pointerdown' && e.target === 'start'));
  await frame.waitForFunction(() => window.__readySamples.length, null, { polling: 1, timeout: 60000 });
  await wait(800);
  run.readySamples = await frame.evaluate(() => window.__readySamples);
  run.firstStart = run.readySamples[0];
  return run;
}
function canvasSize(frame) {
  return frame.evaluate(() => {
    const canvas = document.getElementById('canvas'), box = canvas.getBoundingClientRect();
    return { frame: [innerWidth, innerHeight], css: [box.width, box.height],
      backing: [canvas.width, canvas.height], dpr: devicePixelRatio,
      density: [canvas.width / box.width, canvas.height / box.height] };
  });
}
async function firstStartDensity() {
  for (const [width, height] of [[390, 844], [844, 390], [320, 240]]) {
    const run = await createRun({ viewport: { width, height }, hasTouch: true, isMobile: true, deviceScaleFactor: 3 });
    try {
      const settled = await canvasSize(run.frame), first = run.firstStart;
      const capped = size => size.backing.every((n, i) => n <= size.css[i] * 2);
      const name = `touch ${width}x${height} S7 DPR3 first START backing density cap`;
      const bad = run.readySamples.filter(size => !capped(size));
      const pass = first.dpr === 3 && first.frame[0] === width && first.frame[1] === height && !bad.length && capped(settled)
        && run.startInput.some(e => e.trusted && e.pointerType === 'touch');
      const numbers = { first, settled, samples: run.readySamples.length, bad: bad.length, firstBad: bad[0], startInput: run.startInput };
      fs.writeFileSync(path.join(output, `ready-${width}x${height}.json`), JSON.stringify(run.readySamples, null, 2));
      results.push({ name, pass, numbers });
      console.log(`${pass ? 'PASS' : 'FAIL'} ${name} ${JSON.stringify(numbers)}`);
      if (!pass) process.exitCode = 1;
      await run.page.setViewportSize({ width: width + 1, height });
      await run.page.locator('#g').evaluate((e, w) => e.width = String(w), width + 1);
      await wait(300);
      const control = await canvasSize(run.frame);
      invariant(`touch ${width}x${height} S7 DPR3 live resize healthy control`, capped(control), control);
      await noLock(run, `touch ${width}x${height} first START S5`);
    } finally { await run.context.close(); }
  }
}
async function readinessDeadline() {
  const run = await createRun({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true, deviceScaleFactor: 3 }, '', '', false);
  try {
    await run.frame.evaluate(() => {
      // Resolve the lazy export before replacing only its observed ready field.
      Module._Browser_State();
      const original = Module._Browser_State;
      Module._Browser_State = () => {
        const ptr = original(), state = JSON.parse(Module.UTF8ToString(ptr)); state.ready = false;
        const bytes = new TextEncoder().encode(JSON.stringify(state));
        Module.HEAPU8.set(bytes, ptr); Module.HEAPU8[ptr + bytes.length] = 0; return ptr;
      };
      window.__restoreReady = () => Module._Browser_State = original;
      const request = window.requestAnimationFrame, cancel = window.cancelAnimationFrame, pending = new Set();
      window.__videoFrames = { callbacks: 0, pending: 0, maxPending: 0 };
      window.requestAnimationFrame = cb => {
        const shell = cb.name === 'resizeWhenReady';
        const id = request(time => {
          if (shell) { pending.delete(id); ++window.__videoFrames.callbacks; window.__videoFrames.pending = pending.size; }
          cb(time);
        });
        if (shell) { pending.add(id); window.__videoFrames.pending = pending.size; window.__videoFrames.maxPending = Math.max(window.__videoFrames.maxPending, pending.size); }
        return id;
      };
      window.cancelAnimationFrame = id => { pending.delete(id); window.__videoFrames.pending = pending.size; cancel(id); };
    });
    await run.frame.locator('#start').tap();
    const counts = [], begin = performance.now();
    for (const ms of [1000, 2000, 3300, 5000]) {
      await wait(Math.max(0, begin + ms - performance.now()));
      counts.push({ ms, ...await run.frame.evaluate(() => window.__videoFrames) });
    }
    const failure = await run.frame.evaluate(() => ({ ready: JSON.parse(Module.UTF8ToString(Module._Browser_State())).ready,
      status: document.getElementById('status').textContent, start: !document.getElementById('start-screen').hidden,
      enabled: !document.getElementById('start').disabled }));
    invariant('S8 false readiness stops shell callbacks within 5 seconds', counts[0].callbacks > 0 && counts[2].callbacks === counts[3].callbacks
      && counts[3].pending === 0 && !failure.ready && failure.start && failure.enabled && failure.status === 'VIDEO INITIALIZATION TIMED OUT', { counts, failure });
    for (let i = 0; i < 2; ++i) {
      await run.frame.locator('#start').tap(); await wait(100);
      await run.frame.evaluate(() => Module.onReturnToStart());
    }
    invariant('S8 two START restarts never stack readiness loops', await run.frame.evaluate(() => __videoFrames.maxPending === 1 && __videoFrames.pending === 0), await run.frame.evaluate(() => __videoFrames));
    for (const event of ['return', 'abort', 'hidden', 'pagehide']) {
      await run.frame.evaluate(() => Module.onReturnToStart());
      await run.frame.locator('#start').tap(); await wait(100);
      const before = await run.frame.evaluate(event => {
        if (event === 'return') Module.onReturnToStart();
        if (event === 'abort') Module.onAbort();
        if (event === 'hidden') {
          Object.defineProperty(document, 'hidden', { configurable: true, get: () => true });
          document.dispatchEvent(new Event('visibilitychange')); delete document.hidden;
        }
        if (event === 'pagehide') window.dispatchEvent(new Event('pagehide'));
        return { ...__videoFrames };
      }, event);
      await wait(200); const after = await run.frame.evaluate(() => __videoFrames);
      invariant('S8 readiness cancellation on ' + event, before.callbacks === after.callbacks && after.pending === 0, { before, after });
    }
    await run.frame.evaluate(() => Module.onReturnToStart());
    await run.frame.locator('#start').tap(); await wait(3300);
    invariant('S8 restarted false readiness also reaches the deadline', await run.frame.locator('#start-screen').isVisible()
      && await run.frame.locator('#status').textContent() === 'VIDEO INITIALIZATION TIMED OUT', await run.frame.evaluate(() => __videoFrames));
    await run.frame.evaluate(() => { __restoreReady(); Module.onReturnToStart(); });
    await run.frame.locator('#start').tap();
    await run.frame.waitForFunction(() => JSON.parse(Module.UTF8ToString(Module._Browser_State())).ready, null, { polling: 1, timeout: 60000 });
    await wait(800);
    invariant('S8 readiness recovery clears its timeout and starts E1M1', (await state(run.frame)).map === 'E1M1'
      && await run.frame.locator('#status').isHidden() && await run.frame.evaluate(() => __videoFrames.pending === 0), await state(run.frame));
    await movement(run, 'S8 recovered movement', false);
    await run.page.locator('#g').evaluate(e => e.width = '391'); await wait(300);
    const size = await canvasSize(run.frame);
    invariant('S8 recovered live resize preserves the density cap', size.backing.every((n, i) => n <= size.css[i] * 2), size);
    await noLock(run, 'S8 readiness S5');
  } finally { await run.context.close(); }
}
async function lifecycle(run) {
  const keys=Object.keys(await state(run.frame)).sort();
  invariant('C3 state reader has exactly the shared fields',JSON.stringify(keys)===JSON.stringify(['ready','map','frame','pos','yaw','pitch','health','ammo','shots','lock_calls'].sort()),{keys});
  invariant('C3 START audio is unlocked',await run.frame.evaluate(()=>Module.SDL2.audioContext.state==='running'),{state:await run.frame.evaluate(()=>Module.SDL2.audioContext.state)});
  await run.page.keyboard.press('Escape'); await wait(150);
  invariant('C3 Escape opens the keyboard menu',await run.frame.evaluate(()=>!!Module._Browser_MenuActive()),{menuActive:await run.frame.evaluate(()=>Module._Browser_MenuActive())});
  await run.page.keyboard.press('Escape');
  await run.page.keyboard.press(']');
  let stored=await run.frame.evaluate(()=>localStorage.getItem('doom-shareware-sensitivity'));
  const b=await run.frame.locator('#canvas').boundingBox();const x=b.x+b.width/2,y=b.y+b.height/2;
  await run.page.mouse.move(x,y); const a=await state(run.frame);
  await run.page.mouse.down();await run.page.mouse.move(x+100,y,{steps:10});await run.page.mouse.up();await wait(200);const c=await state(run.frame);
  invariant('C3 sensitivity keys change the real turn formula',Math.abs(yawDelta(a.yaw,c.yaw)+33)<1 && Math.abs(Number(stored)-.33)<.000001,{stored,yawDelta:yawDelta(a.yaw,c.yaw),expected:-33});
  await run.page.reload();run.frame=run.page.frames().find(f=>f.parentFrame());
  await run.frame.waitForFunction(()=>window.__proof && !document.getElementById('start').disabled,null,{timeout:60000});
  await run.frame.locator('#legal').click();
  await run.frame.locator('a[href="SOURCE.txt"]').waitFor();
  const links=await run.frame.locator('a').evaluateAll(elements=>elements.map(e=>e.getAttribute('href')));
  const source=await run.page.request.get(`http://localhost:${portA}/legal/original-engine-source.tgz`);
  invariant('G6 corner link stays inside the sandbox and offers source',new URL(run.frame.url()).pathname.endsWith('/legal/index.html') && links.includes('GPL-2.0.txt') && links.includes('DOOMS_19.DAT') && links.includes('README.TXT') && source.status()===200 && Number(source.headers()['content-length'])>1000000,{url:run.frame.url(),links,sourceStatus:source.status(),sourceBytes:Number(source.headers()['content-length'])});
  await run.frame.locator('#return-start').click();
  await run.frame.waitForFunction(()=>window.__proof && !document.getElementById('start').disabled,null,{timeout:60000});
  await run.frame.locator('#start').click();await run.frame.waitForFunction(()=>window.__proof.state().ready,null,{timeout:60000});await wait(500);
  const box=await run.frame.locator('#canvas').boundingBox();const px=box.x+box.width/2,py=box.y+box.height/2;
  await run.page.mouse.move(px,py);const p=await state(run.frame);
  await run.page.mouse.down();await run.page.mouse.move(px+100,py,{steps:10});await run.page.mouse.up();await wait(200);const q=await state(run.frame);
  invariant('C3 sensitivity survives page reload',Math.abs(yawDelta(p.yaw,q.yaw)+33)<1,{yawDelta:yawDelta(p.yaw,q.yaw),expected:-33});
  await run.page.keyboard.press('[');
  for(const hidden of [false,true]) {
    await run.page.keyboard.down('w');await run.page.mouse.move(px,py);await run.page.mouse.down();await run.page.mouse.move(px+20,py,{steps:2});
    await run.frame.evaluate(hidden=>{
      if(hidden){Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'));delete document.hidden;}
      else window.dispatchEvent(new Event('blur'));
    },hidden);
    await wait(100);const stopped=await state(run.frame);await wait(500);const still=await state(run.frame);
    const ui=await run.frame.evaluate(()=>({paused:!document.getElementById('pause-screen').hidden,dragging:document.getElementById('canvas').classList.contains('dragging'),audio:Module.SDL2.audioContext.state}));
    await run.page.mouse.up();await run.page.keyboard.up('w');
    invariant('C3 '+(hidden?'hidden':'blur')+' lifecycle releases input and pauses audio',ui.paused && !ui.dragging && ui.audio==='suspended' && Math.hypot(still.pos[0]-stopped.pos[0],still.pos[1]-stopped.pos[1])<1 && Math.abs(yawDelta(stopped.yaw,still.yaw))<.05,{...ui,positionDrift:Math.hypot(still.pos[0]-stopped.pos[0],still.pos[1]-stopped.pos[1]),yawDrift:yawDelta(stopped.yaw,still.yaw),eventSource:'forced browser lifecycle event'});
    await run.frame.locator('#resume').click();
  }
  await run.page.keyboard.press('Escape');await run.page.keyboard.press('q');await run.page.keyboard.press('Enter');await wait(200);
  invariant('C3 keyboard quit returns to the single START control',await run.frame.locator('#start-screen').isVisible() && !(await run.frame.locator('#touch-controls').isVisible()),{startVisible:await run.frame.locator('#start-screen').isVisible()});
  await run.frame.locator('#start').click();await wait(700);const fresh=await state(run.frame);
  invariant('C3 START begins a fresh first level',fresh.map==='E1M1' && fresh.ammo===50 && fresh.shots===0 && fresh.health===100,{map:fresh.map,ammo:fresh.ammo,shots:fresh.shots,pos:fresh.pos});
  await noLock(run,'C3 lifecycle S5');
}
async function layout(run) {
  for(const [width,height] of [[320,240],[390,844],[844,390],[1920,1080],[1080,1920]]) {
    await run.page.locator('#g').evaluate((e,s)=>{e.width=s.width;e.height=s.height;},{width,height});await wait(350);
    const dims=await run.frame.evaluate(()=>{const c=document.getElementById('canvas'),r=c.getBoundingClientRect();return {frame:[innerWidth,innerHeight],css:[r.width,r.height],backing:[c.width,c.height],dpr:devicePixelRatio,position:[r.x,r.y]};});
    invariant('C3 resize '+width+'x'+height+' keeps aspect and caps backing pixels',dims.frame[0]===width && dims.frame[1]===height && dims.css[0]<=width+.1 && dims.css[1]<=height+.1 && Math.abs(dims.css[0]/dims.css[1]-4/3)<.005 && dims.backing[0]<=dims.css[0]*2+2 && dims.backing[1]<=dims.css[1]*2+2,{...dims,cap:2});
  }
  await noLock(run,'C3 layout S5');
}
async function fallbacks() {
  const script="Object.defineProperty(window,'localStorage',{configurable:true,get(){throw new Error('Storage unavailable')}});window.AudioContext=class{constructor(){throw new Error('Audio unavailable')}};window.webkitAudioContext=undefined;";
  const run=await createRun({},'',script);
  invariant('S6 unavailable audio and storage retain a playable level',(await state(run.frame)).ready && await run.frame.locator('#status').textContent()==='AUDIO UNAVAILABLE',{map:(await state(run.frame)).map,status:await run.frame.locator('#status').textContent()});
  await run.page.keyboard.press(']');
  const b=await run.frame.locator('#canvas').boundingBox(),x=b.x+b.width/2,y=b.y+b.height/2;
  await run.page.mouse.move(x,y);const before=await state(run.frame);await run.page.mouse.down();await run.page.mouse.move(x+100,y,{steps:10});await run.page.mouse.up();await wait(200);const after=await state(run.frame);
  invariant('S6 storage fallback keeps sensitivity in memory',Math.abs(yawDelta(before.yaw,after.yaw)+33)<1,{yawDelta:yawDelta(before.yaw,after.yaw),expected:-33});
  await movement(run,'S6 fallback movement',false);
  await fire(run,'S6 fallback F',()=>run.page.keyboard.down('f'),()=>run.page.keyboard.up('f'));
  await noLock(run,'S6 fallback S5');await run.context.close();
}
async function startInvariant(run, label = 'S1') {
  const before = await state(run.frame); await wait(250); const after = await state(run.frame);
  invariant(label+' data name owns the page title',await run.frame.evaluate(()=>document.title===GAME_NAME),{title:await run.frame.title()});
  const pixels = await shot(run, label === 'S1' ? 'start.png' : 'prefix-start.png');
  invariant(label + ' start, first map and real rendered pixels', after.ready && after.map === 'E1M1' && after.frame > before.frame && after.health > 0 && after.ammo === 50 && pixels.stddev > 10 && pixels.colors > 32 && pixels.range > 40 && pixels.nonblack > .5, { map: after.map, frameBefore: before.frame, frameAfter: after.frame, health: after.health, ammo: after.ammo, loadToStartMs: run.loadMs, pixels });
  if (label === 'S1') metrics.firstLoadMs = run.loadMs;
}
async function movement(run, label = 'S3', allDirections = true) {
  const before = await state(run.frame), rad = before.yaw * Math.PI/180;
  await run.page.keyboard.down('w'); await wait(1000); const moving = await state(run.frame); await run.page.keyboard.up('w');
  const forward = (moving.pos[0]-before.pos[0])*Math.cos(rad) + (moving.pos[1]-before.pos[1])*Math.sin(rad);
  const lateral = -(moving.pos[0]-before.pos[0])*Math.sin(rad) + (moving.pos[1]-before.pos[1])*Math.cos(rad);
  const friction = 0xe800/65536, acceleration = 25*2048/65536;
  let velocity = 0, expectedWalk = 0;
  for (let i=0;i<35;++i) { velocity += acceleration; expectedWalk += velocity; velocity *= friction; }
  await wait(500); const stopped = await state(run.frame); await wait(500); const later = await state(run.frame);
  const stopDrift = Math.hypot(later.pos[0]-stopped.pos[0],later.pos[1]-stopped.pos[1]);
  invariant(label + ' W walks along yaw and release stops', forward >= expectedWalk*.85 && Math.abs(lateral) < 8 && stopDrift < 1, { expectedWalk, minimum: expectedWalk*.85, forward, lateral, stopDrift, before: before.pos, moving: moving.pos, stopped: stopped.pos });
  if (!allDirections) return;
  for (const [key, axis, sign] of [['a','left',1],['s','forward',-1],['d','left',-1]]) {
    const a = await state(run.frame); await run.page.keyboard.down(key); await wait(350); await run.page.keyboard.up(key); await wait(200); const b = await state(run.frame);
    const dx=b.pos[0]-a.pos[0],dy=b.pos[1]-a.pos[1];
    const distance = axis === 'left' ? -dx*Math.sin(rad)+dy*Math.cos(rad) : dx*Math.cos(rad)+dy*Math.sin(rad);
    invariant(label + ' ' + key.toUpperCase() + ' moves in the correct direction', sign*distance > 20, { distance, expectedSign: sign, before:a.pos,after:b.pos });
  }
}
async function look(run, label = 'S3') {
  const box = await run.frame.locator('#canvas').boundingBox(); const x=box.x+box.width/2,y=box.y+box.height/2;
  await run.page.mouse.move(x,y); const before = await state(run.frame);
  await run.page.mouse.down();
  invariant(label+' drag hides the cursor',await run.frame.locator('#canvas').evaluate(e=>getComputedStyle(e).cursor==='none'),{cursor:await run.frame.locator('#canvas').evaluate(e=>getComputedStyle(e).cursor)});
  await run.page.mouse.move(x+300,y,{steps:10}); await run.page.mouse.up(); await wait(250); const after=await state(run.frame);
  const delta=yawDelta(before.yaw,after.yaw);
  invariant(label+' primary drag has the configured yaw', delta < 0 && Math.abs(delta+90)<=22.5, { delta,expected:-90,tolerance:22.5,pixels:300,sensitivity:.3 });
  await run.page.mouse.move(x-100,y+30,{steps:10}); await wait(300); const hover=await state(run.frame);
  invariant(label+' unheld movement leaves yaw unchanged', Math.abs(yawDelta(after.yaw,hover.yaw))<.05, { delta:yawDelta(after.yaw,hover.yaw) });
  await run.page.mouse.move(x,y); await run.page.mouse.down(); await run.page.mouse.move(x,y+120,{steps:10}); await run.page.mouse.up(); await wait(250); const vertical=await state(run.frame);
  invariant(label+' vertical drag leaves Doom yaw and pitch unchanged', Math.abs(yawDelta(hover.yaw,vertical.yaw))<.05 && vertical.pitch===0, { yawDelta:yawDelta(hover.yaw,vertical.yaw),pitch:vertical.pitch });
  await wait(1000); const still=await state(run.frame);
  invariant(label+' release leaves no continued turning', Math.abs(yawDelta(vertical.yaw,still.yaw))<.05, { delta:yawDelta(vertical.yaw,still.yaw),milliseconds:1000 });
  await run.page.mouse.move(x,y); await run.page.mouse.down(); await run.page.mouse.move(990,y,{steps:10}); await run.page.mouse.up(); await wait(300); const outside=await state(run.frame); await wait(1000); const outsideStill=await state(run.frame);
  const captureEnded=await run.frame.locator('#canvas').evaluate(e=>!e.classList.contains('dragging') && !e.hasPointerCapture(1));
  invariant(label+' captured drag ending outside the frame releases', captureEnded && Math.abs(yawDelta(outside.yaw,outsideStill.yaw))<.05, { captureEnded,yawDrift:yawDelta(outside.yaw,outsideStill.yaw),endX:990,frameRight:960 });
  await shot(run,'turned.png');
}
async function fire(run, label, down, up) {
  const before=await nativeState(run.frame); const animation=new Set([before.weapon_frame]);
  await down();
  const release = (async () => { await wait(80); await up(); })();
  for(let i=0;i<4;++i) { await wait(20); animation.add((await nativeState(run.frame)).weapon_frame); }
  await release;
  for(let i=0;i<12;++i) { await wait(20); animation.add((await nativeState(run.frame)).weapon_frame); }
  const after=await state(run.frame);
  invariant(label+' accepted engine fire uses one round and animates', after.shots===before.shots+1 && before.ammo-after.ammo===1 && animation.size>1, { shotsBefore:before.shots,shotsAfter:after.shots,ammoBefore:before.ammo,ammoAfter:after.ammo,weaponFrames:[...animation] });
  await wait(250);
}
async function noLock(run,label='S5') {
  const s=await state(run.frame),pl=await run.frame.evaluate(()=>({calls:window.__lockCalls,events:window.__plLog}));
  invariant(label+' lock counters and browser diagnostics remain clear', s.lock_calls===0 && pl.calls===0 && !pl.events.length && !run.diag.errors.length && !run.diag.failed.length && !run.diag.outside.length && !run.diag.dialogs.length, { lock_calls:s.lock_calls,events:pl.events,consoleErrors:run.diag.errors,failedRequests:run.diag.failed,outsideRequests:run.diag.outside,dialogs:run.diag.dialogs,requests:run.diag.requests.length });
}
async function mouseRelease(run) {
  const b=await run.frame.locator('#canvas').boundingBox();
  await run.page.mouse.move(b.x+b.width/2,b.y+b.height/2);
  await run.page.mouse.down({button:'right'});await wait(180);
  await run.page.mouse.move(990,300,{steps:5});await run.page.mouse.up({button:'right'});
  await wait(500);const released=await state(run.frame);await wait(1100);const still=await state(run.frame);
  invariant('S3 right mouse release outside the frame stops fire',still.shots===released.shots,{shotsAfterRelease:released.shots,shotsLater:still.shots,endX:990});
}
async function touch(run, orientation) {
  invariant('S4 ' + orientation + ' begins with trusted touch at DPR 3', run.firstStart.dpr === 3
    && run.startInput.some(e => e.trusted && e.pointerType === 'touch'), { dpr: run.firstStart.dpr, startInput: run.startInput });
  invariant('S4 '+orientation+' touch overlay is visible', await run.frame.locator('#touch-controls').isVisible(), { viewport:run.page.viewportSize() });
  const session=await run.context.newCDPSession(run.page);
  const stick=await run.frame.locator('#stick').boundingBox(),fireBox=await run.frame.locator('#touch-fire').boundingBox(),canvas=await run.frame.locator('#canvas').boundingBox();
  const sx=stick.x+stick.width/2,sy=stick.y+stick.height/2;
  const fx=fireBox.x+fireBox.width/2,fy=fireBox.y+fireBox.height/2;
  const lx=canvas.x+canvas.width*.75,ly=canvas.y+canvas.height*.35;
  async function send(type,points) { await session.send('Input.dispatchTouchEvent',{type,touchPoints:points.map(p=>({id:p[0],x:p[1],y:p[2],radiusX:2,radiusY:2,force:1}))}); }
  const before=await state(run.frame);
  await send('touchStart',[[11,sx,sy]]); await send('touchMove',[[11,sx,sy-40]]); await wait(600); const moved=await state(run.frame);
  invariant('S4 '+orientation+' stick moves the engine',Math.hypot(moved.pos[0]-before.pos[0],moved.pos[1]-before.pos[1])>40,{distance:Math.hypot(moved.pos[0]-before.pos[0],moved.pos[1]-before.pos[1]),before:before.pos,after:moved.pos});
  await send('touchStart',[[11,sx,sy-40],[12,lx,ly]]);
  for(let i=1;i<=10;++i) await send('touchMove',[[11,sx,sy-40],[12,lx+6*i,ly]]);
  const preFire=await nativeState(run.frame); const animation=new Set([preFire.weapon_frame]);
  const fireStart=performance.now();
  await send('touchStart',[[11,sx,sy-40],[12,lx+60,ly],[13,fx,fy]]);
  let fireReleaseMs;
  const release = (async () => { await wait(80); await send('touchEnd',[[11,sx,sy-40],[12,lx+60,ly]]); fireReleaseMs=performance.now()-fireStart; })();
  for(let i=0;i<4;++i) { await wait(20); animation.add((await nativeState(run.frame)).weapon_frame); }
  await release;
  for(let i=0;i<12;++i) { await wait(20); animation.add((await nativeState(run.frame)).weapon_frame); }
  const after=await state(run.frame);
  await send('touchEnd',[]); await wait(350);
  const stopped=await state(run.frame); await wait(500); const still=await state(run.frame);
  invariant('S4 '+orientation+' stick look and fire overlap',yawDelta(moved.yaw,after.yaw)<-13.5 && Math.abs(yawDelta(moved.yaw,after.yaw)+18)<=4.5 && after.shots===preFire.shots+1 && preFire.ammo-after.ammo===1 && animation.size>1,{yawDelta:yawDelta(moved.yaw,after.yaw),expected:-18,shotsBefore:preFire.shots,shotsAfter:after.shots,ammoBefore:preFire.ammo,ammoAfter:after.ammo,weaponFrames:[...animation],fireReleaseMs,distanceWhileLooking:Math.hypot(after.pos[0]-moved.pos[0],after.pos[1]-moved.pos[1])});
  invariant('S4 '+orientation+' released pointers leave no movement or turn',Math.hypot(still.pos[0]-stopped.pos[0],still.pos[1]-stopped.pos[1])<1 && Math.abs(yawDelta(stopped.yaw,still.yaw))<.05,{positionDrift:Math.hypot(still.pos[0]-stopped.pos[0],still.pos[1]-stopped.pos[1]),yawDrift:yawDelta(stopped.yaw,still.yaw)});
  const viewport=run.page.viewportSize(),blankX=viewport.width*(orientation==='portrait'?.6:.85),blankY=viewport.height*(orientation==='portrait'?.15:.35);
  const blankBefore=await state(run.frame);await send('touchStart',[[44,blankX,blankY]]);
  for(let i=1;i<=10;++i)await send('touchMove',[[44,blankX+4*i,blankY]]);
  await send('touchEnd',[]);await wait(250);const blankAfter=await state(run.frame);
  invariant('S4 '+orientation+' right letterbox drag also looks',Math.abs(yawDelta(blankBefore.yaw,blankAfter.yaw)+12)<2,{yawDelta:yawDelta(blankBefore.yaw,blankAfter.yaw),expected:-12,point:[blankX,blankY]});
  await shot(run,'touch-'+orientation+'.png'); await noLock(run,'S4 '+orientation+' S5');
  await run.frame.locator('#touch-menu').tap();
  await run.frame.waitForFunction(() => !!Module._Browser_MenuActive());
  await run.frame.locator('#touch-keys summary').tap();
  const keys = await run.frame.locator('#touch-key-buttons button[data-key]').evaluateAll(es => es.map(e => e.dataset.key));
  invariant('S4 '+orientation+' touch drawer covers keys and menu entry',
    ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Enter','Escape','Backspace','ShiftLeft','Tab','Pause',...Array.from({length:26},(_,i)=>'Key'+String.fromCharCode(65+i)),...Array.from({length:10},(_,i)=>'Digit'+i)].every(k=>keys.includes(k)), {keys});
  await run.frame.locator('[data-key="ArrowDown"]').tap();
  await run.frame.locator('[data-key="Enter"]').tap();
  await run.frame.locator('[data-key="Escape"]').tap();
  await run.frame.locator('[data-key="Escape"]').tap();
  await run.frame.waitForFunction(() => !Module._Browser_MenuActive());
  invariant('S4 '+orientation+' touch operates and closes native menus', !(await run.frame.evaluate(()=>Module._Browser_MenuActive())), {menuActive:false});
  await run.frame.locator('#touch-keys summary').tap();
  invariant('S4 '+orientation+' legal link remains available during play', await run.frame.locator('#legal').isVisible(), {href:await run.frame.locator('#legal').getAttribute('href')});
  await noLock(run,'S4 '+orientation+' drawer S5');
}
async function touchKey(run, selector) {
  for(let i=0;i<5;++i) {
    const key=run.frame.locator(selector);
    if(await key.isVisible()) {
      const rect=await key.evaluate(e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,right:r.right,bottom:r.bottom,w:innerWidth,h:innerHeight};});
      invariant('S4 touch key is inside frame '+selector,rect.x>=0&&rect.y>=0&&rect.right<=rect.w&&rect.bottom<=rect.h,rect);
      await key.tap();await wait(50);return;
    }
    await run.frame.locator('#touch-key-next').tap();
  }
  throw new Error('Unreachable touch key '+selector);
}
async function saveNameTouch(run) {
  await run.frame.locator('#touch-menu').tap();
  await run.frame.waitForFunction(()=>!!Module._Browser_MenuActive());
  await run.frame.locator('#touch-keys summary').tap();
  const pageCount=Number((await run.frame.locator('#touch-key-page').textContent()).split('/')[1]);
  for(let i=0;i<pageCount;++i) {
    const boxes=await run.frame.locator('#touch-key-buttons button:visible,#touch-key-pages button').evaluateAll(es=>es.map(e=>{const r=e.getBoundingClientRect();return {text:e.textContent,x:r.x,y:r.y,right:r.right,bottom:r.bottom,w:innerWidth,h:innerHeight};}));
    invariant('S4 compact drawer page '+(i+1)+' fits without scrolling',boxes.every(b=>b.x>=0&&b.y>=0&&b.right<=b.w&&b.bottom<=b.h),{boxes});
    await run.frame.locator('#touch-key-next').tap();
  }
  await touchKey(run,'[data-key="KeyS"]');
  await touchKey(run,'[data-key="Enter"]');
  await touchKey(run,'[data-key="Enter"]');
  for(let i=0;i<24;++i) await touchKey(run,'[data-key="Backspace"]');
  for(const selector of ['[data-key="KeyF"]','[data-key="KeyE"]','[data-key="Space"]','[data-character="!"]','[data-character="?"]']) await touchKey(run,selector);
  await touchKey(run,'[data-key="Enter"]');await wait(250);
  const saved=await run.frame.evaluate(()=>{
    const files=[];
    function walk(dir,depth=0) {
      if(depth>10)return;
      for(const name of Module.FS.readdir(dir)) {
        if(name==='.'||name==='..')continue;
        const p=(dir==='/'?'':dir)+'/'+name,stat=Module.FS.lstat(p);
        if(Module.FS.isDir(stat.mode)){if(!['/dev','/proc'].includes(p))walk(p,depth+1);}
        else if(p.endsWith('.dsg'))files.push({path:p,name:new TextDecoder().decode(Module.FS.readFile(p).subarray(0,24)).split('\0')[0]});
      }
    }
    walk('/');return files;
  });
  invariant('S4 native save records touch letters space and punctuation',saved.some(s=>s.name==='FE !?'),{saved});
  await run.frame.locator('#touch-keys summary').tap();
  await noLock(run,'S4 compact text S5');
}
try {
  portA=await server(process.env.SITE_DIR || path.join(W,'site')); portB=await server(path.join(root,'proof'),portA);
  const flags=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage','--no-sandbox'];
  const executablePath = process.env.PROOF_CHROMIUM_PATH;
  console.log('BROWSER playwright=1.63.0 executable='+JSON.stringify(executablePath || chromium.executablePath())+' flags='+JSON.stringify(flags));
  browser=await chromium.launch({headless:true,args:flags,executablePath});
  console.log('BROWSER_VERSION',await browser.version());
  for(const name of fs.readdirSync('/proc').filter(n=>/^\d+$/.test(n))) {
    try {
      const stat=fs.readFileSync('/proc/'+name+'/stat','utf8');
      const parent=Number(stat.slice(stat.lastIndexOf(')')+2).split(' ')[1]);
      const command=fs.readFileSync('/proc/'+name+'/cmdline','utf8');
      if(parent===process.pid && command.includes('/chrom') && command.includes(process.env.TMPDIR)) {
        browserPids.push(Number(name));console.log('BROWSER_PID',name);
      }
    } catch {}
  }
  if(!browserPids.length) throw new Error('Browser process identity must be recorded');
  if(mode==='first-start-density') { await firstStartDensity(); }
  else if(mode==='readiness-deadline') { await readinessDeadline(); }
  else {
  if(mode==='full') {
    const context=await browser.newContext(); await context.addInitScript({path:path.join(root,'proof/init.js')}); const page=await context.newPage(); const messages=[];
    page.on('console',m=>messages.push(m.text()));
    await page.goto(`http://127.0.0.1:${portB}/outer.html?control=1`); const frame=page.frames().find(f=>f.parentFrame());
    await frame.locator('#control').click(); await wait(300);
    const control=await frame.evaluate(()=>({calls:window.__lockCalls,granted:!!document.pointerLockElement,events:window.__plLog}));
    invariant('S0 sandbox refuses the real lock request',control.calls===1 && !control.granted,{...control,browserMessages:messages}); await context.close();
  }
  const desktop=await createRun();
  if(mode==='mutation-lock') { await noLock(desktop); }
  else if(mode==='mutation-drag') { await look(desktop); }
  else if(mode==='touch-text') {
    await desktop.context.close();
    const compact=await createRun({viewport:{width:320,height:240},hasTouch:true,isMobile:true});
    await saveNameTouch(compact);await compact.context.close();
  }
  else {
    await startInvariant(desktop);
    invariant('S2 START directly begins the shareware episode', (await state(desktop.frame)).ready && (await state(desktop.frame)).map==='E1M1', {input:'START click',map:(await state(desktop.frame)).map});
    await movement(desktop); await look(desktop);
    const b=await desktop.frame.locator('#canvas').boundingBox(); await desktop.page.mouse.move(b.x+b.width/2,b.y+b.height/2);
    await fire(desktop,'S3 right mouse',()=>desktop.page.mouse.down({button:'right'}),()=>desktop.page.mouse.up({button:'right'}));
    await fire(desktop,'S3 F',()=>desktop.page.keyboard.down('f'),()=>desktop.page.keyboard.up('f'));
    await fire(desktop,'S3 short primary click',()=>desktop.page.mouse.down(),()=>desktop.page.mouse.up());
    await mouseRelease(desktop);
    await shot(desktop,'fired.png'); await noLock(desktop);
    if(mode==='full') {
      await lifecycle(desktop);await desktop.context.close();
      await firstStartDensity();
      await readinessDeadline();
      for(const [orientation,viewport] of [['portrait',{width:390,height:844}],['landscape',{width:844,height:390}]]) {
        const run=await createRun({viewport,hasTouch:true,isMobile:true,deviceScaleFactor:3}); await touch(run,orientation); await run.context.close();
      }
      const compact=await createRun({viewport:{width:320,height:240},hasTouch:true,isMobile:true});
      await saveNameTouch(compact);await compact.context.close();
      const prefixed=await createRun({},'nested/doom-shareware/'); await startInvariant(prefixed,'S7 S1'); await movement(prefixed,'S7 S2',false); await noLock(prefixed,'S7 S5');
      const response=await prefixed.page.request.get(`http://localhost:${portA}/nested/doom-shareware/freedoom.wasm`,{headers:{Range:'bytes=0-31'}});
      invariant('S7 Range-less and wrong wasm MIME load works',response.status()===200 && response.headers()['content-type']==='text/plain' && (await response.body()).length>1000000,{status:response.status(),type:response.headers()['content-type'],bytes:(await response.body()).length});
      await prefixed.context.close();
      const sized=await createRun({deviceScaleFactor:3});await layout(sized);await sized.context.close();await fallbacks();
    }
  }
  }
} catch(e) {
  console.error('PROOF_ERROR',e.stack); if(!results.some(r=>!r.pass)) results.push({name:'browser execution completes',pass:false,numbers:{error:e.message}}); process.exitCode=1;
} finally {
  if(browser) await browser.close();
  for(const pid of browserPids) {
    if(fs.existsSync('/proc/'+pid)) throw new Error('Recorded browser process remains: '+pid);
    console.log('BROWSER_PID_STOPPED',pid);
  }
  for(const child of servers) { child.kill('SIGTERM'); await once(child,'exit'); console.log('PID_STOPPED',child.pid); }
  const report={utc:new Date().toISOString(),mode,inputs,siteInputs,proofInputs,results,metrics,pass:results.filter(r=>r.pass).length,fail:results.filter(r=>!r.pass).length,skip:0};
  fs.writeFileSync(path.join(output,mode==='full'?'report.json':`report-${mode}.json`),JSON.stringify(report,null,2));
  console.log(`COUNTS PASS ${report.pass} FAIL ${report.fail} SKIP 0`);
}
