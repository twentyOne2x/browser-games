#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
export W="$(dirname "$PWD")"
export TMPDIR="$W/tmp"
export PLAYWRIGHT_BROWSERS_PATH="${PROOF_BROWSERS_PATH:-${PLAYWRIGHT_BROWSERS_PATH:-$W/browsers}}"
export SITE_DIR="${SITE_DIR:-$PWD/site}"
mkdir -p "$TMPDIR" proof/out/logs
printf 'PROOF UTC_START %s COMMAND bash proof/run.sh %s\n' "$(date -u +%FT%TZ)" "$*"
set +e
node proof/full.mjs "${1:-full}" 2>&1 | tee "proof/out/logs/proof-${1:-full}.log"
result=${PIPESTATUS[0]}
set -e
if [ "$result" -eq 0 ] && [ "${1:-full}" = full ]; then
  python3 proof/mutations.py 2>&1 | tee proof/out/logs/mutations.log
fi
printf 'PROOF UTC_END %s EXIT %s\n' "$(date -u +%FT%TZ)" "$result"
exit "$result"
