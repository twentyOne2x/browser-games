# Reuse decision

REUSE twentyone2x/browser-games doom/ at c8b31bcf5e5ad889f955b645dab125836cbba80c.
Round 3 also reuses the six-commit delivery at 2766c8f1abaa5e8f67ceed7ec41f416a7ed19659
and the supplied predecessor-aae298d6.bundle at aae298d65f0e6f369c1979408952815b3afaa10f.
The following stopped-lane observations describe the original delivery context.
The stopped lane 2 entry is stale per the supplied successor notice. No surviving work was supplied from lanes 1 through 3 or q/doom-host-1.
Shared fleet logs and Mac/Q LEGOS indexes are unavailable on this box. RESEARCH-HG01's Doom row and first five briefs were read before implementation.
The existing engine accepts an alternate IWAD through its filesystem and -iwad argument, so a rebuild would add no value to this task.

Keep the exact runtime JS, WASM, original corresponding source and inherited engine patches.
Change only the loader's WAD, touch access, legal presentation and proof assumptions.
Use the publisher's actual PLEASE DISTRIBUTE!!! notice, preserve the vendor text, and leave DOOM1.WAD unchanged. Do not claim the archive contains a standalone EULA.
The original FAQ's separate restrictions prevent its inclusion in the playable site.

The proof reads the existing native Browser_State bridge: real player position,
yaw, rendered frames, health, ammunition, accepted shots and weapon animation.
The proof never writes gameplay state. Chromium delivers desktop input through
Playwright and phone touch through Chromium's Input.dispatchTouchEvent.
Both static servers bind 127.0.0.1 with OS-selected ports. The parent and iframe
have different origins. The iframe's only sandbox tokens are allow-scripts and
allow-same-origin, and it has no allow attribute.

First load is one local observation from fresh browser-context navigation to
the enabled START button, after WAD download and WASM initialization complete.
It includes the outer document and local asset requests, and excludes the START
click. It is not a deployment estimate or frame-rate comparison. Successful
responses, clear error counters and subsequent real E1M1 rendering validate it.

KIT-GAP digest: pluginpad kits are outside this task's allowed repository downloads. Existing inherited provenance and proof hashing use standard hashlib and node:crypto; no new hashing library or algorithm was introduced.

Review handoff found native save-name parity and compact drawer reachability gaps.
The shell now maps touch text through the same menu ASCII rule as keyboard,
releases unmapped text keys, and paginates instead of relying on native scrolling.
The proof saves FE !? using real touches at 320x240 and reads the resulting native
save file. The right-mouse release outside frame check passed on the healthy
runtime, so no speculative engine or capture patch was added.
