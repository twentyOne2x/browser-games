# NORTH_STAR

PLAY-DOOM-SHAREWARE-1: provide a static Doom shareware page for the Play app iframe.
Reuse twentyone2x/browser-games doom/ and its pinned Chocolate Doom engine.

# DEFINITION_OF_DONE

Verify the two named mirror archives and unchanged DOOM1.WAD v1.9.
Preserve vendor redistribution notices, engine licences and corresponding source.
Pass rerunnable S1 through S6 and both negative mutations, restoring exact bytes.
Deliver hashed site and proof archives, branch main bundle and hosting documents.
Stop every lane-owned process and leave attn-packs unchanged.

# STANDING_AUTHORIZATION

Work only in /root/work/game and deliver files in /root/work/out.
Use only the named repositories, their build/proof dependencies and named data mirrors.
No publication, payment, account, telemetry, multiplayer or Computer Use.

# HUMAN_ONLY_GATES

An unavailable named source, missing redistribution permission or required secret.
