# Pinned dependencies and downloaded identities

The engine is reused without rebuilding. Its exact JS, WASM and source archive come from twentyone2x/browser-games commit c8b31bcf5e5ad889f955b645dab125836cbba80c, doom tree e790c78975880035c4678375f72c8e3586b45f0d.
The original engine source records doom-wasm commit 65e0d3ae2ffa604155eebd96ed40da6567bd08f4 and Emscripten 3.1.64 at SDK commit 35ff8a6d150541276abbc6bae512ca90bcfbe220. This lane did not fetch or execute Emscripten.

| Reused file | Bytes | SHA-256 |
| --- | ---: | --- |
| freedoom.js | 192621 | 46303dc5f99f58747316dcfeb9f4694f69fcaa0f2bd4a99addc57350878d2675 |
| freedoom.wasm | 1976868 | 95872882bc3a9431d5ebf058b9cd5d7ea682a6368d9608e04b56618f6efeff14 |
| legal/source.tar.gz | 20507254 | e76aa892b28382753461bde33f0b84d8dcaebe333dca1c62e2ba83ab0bbb5e59 |

SDL2 2.28.4 and SDL2_mixer 2.8.0 sources and zlib licences are preserved in the unchanged corresponding source archive. No extra engine dependency was downloaded by this lane.

| Included source | Bytes | SHA-256 |
| --- | ---: | --- |
| sdl2-2.28.4.zip | 8903394 | 078183c0603cf59f4a97435284e347fff3ec615635d028cc19deea587ebff31d |
| sdl2_mixer-2.8.0.zip | 11176840 | 3aa9b3abd7cefb3e7952ec2d0acf38c70947f04be14d74ed45f57155c7457386 |

Playwright 1.63.0 and playwright-core 1.63.0 use Apache-2.0. package-lock.json pins npm URLs and SHA-512 integrity. Chromium headless shell 153.0.8010.12 revision 1243 and FFmpeg revision 1011 are the pinned Playwright proof tools. They are not part of the hosted site. The matching installed Chromium licensing files are supplied with the tool download.

Those browser download identities describe the predecessor delivery. The repair
uses the box's already installed Chromium headless shell 149.0.7827.55, revision
1228, selected through PROOF_CHROMIUM_PATH. Its executable and actual version
are recorded in each proof log. No browser or FFmpeg download was added.

| Proof tool download | Bytes | SHA-256 |
| --- | ---: | --- |
| chrome-headless-shell-linux64.zip | 119809080 | a9da028861a0cf789ff25c2fed45f5f1aaf969ed9247835b6a7821a4f7af9d1d |
| ffmpeg-linux.zip | 2376500 | ebc74fc5b94830176a3c2914ae96bd8bc7f6a91f4f33890230f84a172ee61ccc |
| playwright-1.63.0.tgz | 899597 | 195a5ee9bfed7c6e9c03965950e32e5e4dbedaa02e740e5a530eb4b87dae050c |
| playwright-core-1.63.0.tgz | 3123044 | 208593d4e1bcd8f8fe5f869cad1cc332dc7f1d70dc1d58c102dc3ac36e30f26c |

Npm sources: https://registry.npmjs.org/playwright/-/playwright-1.63.0.tgz and https://registry.npmjs.org/playwright-core/-/playwright-core-1.63.0.tgz.
Browser source: https://cdn.playwright.dev/builds/cft/153.0.8010.12/linux64/chrome-headless-shell-linux64.zip.
FFmpeg source: https://cdn.playwright.dev/builds/ffmpeg/1011/ffmpeg-linux.zip. The installer's dbazure endpoint initially installed successfully; a later attempt to retain its archive returned HTTP 400, so the equivalent pinned CDN endpoint from Playwright's own registry was used.
