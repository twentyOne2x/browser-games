# Host the Doom shareware page

Upload every file from site/ together under one directory on a plain static host.
The directory may be nested under any path prefix. Preserve filename case.
No backend, Range support, account, cookie, service worker, COOP/COEP or third-party origin is required.

Recommended content types: .html text/html; .js text/javascript; .css text/css;
.wasm application/wasm; .WAD application/octet-stream; .svg image/svg+xml;
.txt text/plain; .md text/plain; .tgz application/gzip.
The loader supplies ArrayBuffer bytes to the runtime, so incorrect WASM MIME also works.

Embed from a different origin:

```html
<iframe src="https://YOUR-STATIC-HOST/YOUR-PREFIX/index.html"
  sandbox="allow-scripts allow-same-origin"
  style="display:block;width:100%;height:100%;border:0"
  title="Doom shareware"></iframe>
```

Give the iframe's containing element an explicit height. Do not add an allow attribute.
The canvas fits at 4:3, follows frame resizes and caps backing density at 2.
START opens E1M1 directly. WASD moves, arrows turn, hold and drag looks,
F or right mouse fires, E uses, Shift runs, Tab opens the map.
On phones, use the stick, drag on the right, FIRE, USE and NEXT WEAPON.
MENU and the paginated KEYS drawer provide the remaining keyboard actions,
menu and text entry, previous weapon and sensitivity. PREV KEYS and NEXT KEYS
reach every key at 320x240 without scrolling. Tap the corner link for notices.
Saves live in the current engine's memory filesystem and are lost on page reload.
Sensitivity persists only when localStorage is available and otherwise stays in memory.

## Recreate and prove

Requires Python 3, Git, Node 20 or newer, npm and Chromium's Linux libraries.
Work in /root/work/game/repo, or clone the delivered repo.bundle into that path.

```sh
python3 scripts/prepare.py
npm ci --cache /root/work/game/npm-cache
export PLAYWRIGHT_BROWSERS_PATH=/home/cloudlane/.cache/ms-playwright
export PROOF_CHROMIUM_PATH=/home/cloudlane/.cache/ms-playwright/chromium_headless_shell-1228/chrome-headless-shell-linux64/chrome-headless-shell
bash proof/run.sh
bash scripts/ci/fast
```

PROOF_CHROMIUM_PATH selects the box's existing Chromium; the proof records its
executable and actual version. On another box, set it to that box's executable.
Run `bash proof/run.sh first-start-density` for fresh DPR 3 first START checks
at 390x844, 844x390 and 320x240 using trusted touch. A 1 ms timer samples native
readiness and backing size together, including every ready sample for 800 ms.
Each case also checks a physical resize. Ordinary mobile gameplay uses DPR 3.
Run `bash proof/run.sh readiness-deadline` for controlled false native readiness,
five-second callback counts, two restarts, cancellation and playable recovery.
The shell's named 3000 ms deadline starts at START after assets/runtime loading;
normal native startup takes about 1.3 seconds in this box's observed controls.
Timeout returns to START with a status line. Abort, return and page hide cancel
the wait. START retries the existing initialized engine through NewGame.

prepare.py fetches only the pinned owned repository and the two named data mirrors,
verifies their hashes and recreates site/. It does not fetch registered data.
proof/run.sh starts only two loopback static servers and an owned headless browser,
records their PIDs, and closes them in its finally block. Reports, logs and screenshots
are in proof/out/. Healthy controls run before each negative mutation, and game.js
is restored byte for byte even if a mutation fails. Exit 0 requires both mutations.
The original engine source and pinned build instructions are in legal/original-engine-source.tgz.
Current shell source, patches and proof are in legal/source.tgz.

## Delivered archives

Extract the site archive into the hosting upload directory. It contains site/ at the top.
Extract proof.tgz to inspect proof/ reports, logs and screenshots.
Verify delivery files with `sha256sum -c SHA256SUMS.txt` from /root/work/out.
No deployment or real ChatGPT rendering claim is made by this local headless proof.
