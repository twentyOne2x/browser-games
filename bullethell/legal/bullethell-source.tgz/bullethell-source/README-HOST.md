# Host Bullet Hell in the owner's Play app

This is the real game at upstream commit 75173f8c37868ac7f30b886da6d28560e8e4418b.
The page title remains Bullet Hell. It is single player, anonymous and entirely static.
Use it only in the owner's own Play app. Do not add it to the submitted public listing.

Upload every file inside the built `site/` folder to one folder on your static host.
Retain `legal/`, its archives and every notice. No build, database or server is deployed.
All runtime URLs are relative, so `/bullethell/` and any deeper prefix work.

Set these content types when possible:

| Extension | Content type |
| --- | --- |
| .html | text/html; charset=utf-8 |
| .js | text/javascript |
| .css | text/css |
| .ttf | font/ttf |
| .txt, .md | text/plain; charset=utf-8 |
| .json | application/json |
| .tgz | application/gzip |

No WASM or Range requests are used. A plain server returning full files works.
The frame reserves room for reachable controls, then maximally fits the original
600x750 playfield into the remaining area without changing world coordinates.
It follows resize and caps both logical density and rendered backing density at 2.

Use this iframe on the owner app's different origin, substituting the actual host:

```html
<iframe src="https://YOUR-OWN-HOST/YOUR-PREFIX/bullethell/"
  sandbox="allow-scripts allow-same-origin"
  style="width:100%;height:100%;border:0" title="Bullet Hell"></iframe>
```

Do not add an `allow` attribute. Start with the Start game button, which works by
mouse or touch. Keyboard: arrows/WASD move, Z/B fire, X/N slow, C/M bomb, P pause.
Touch: move stick and held Fire, Slow and Bomb. Pause, New game and Controls are
always reachable. Controls exposes all five original display toggles.
Every touch action has a rectangular hit area of at least 44x44 CSS pixels,
including the rounded buttons and Move stick. The lower-right legal link
navigates in the same frame. Portrait layout reserves its 44px bottom row and
moves the gameplay rail above it. Controls opens a menu: the Start button and
gameplay rail hide until the menu closes, while the toolbar and Legal stay active.
The menu fits above Legal. The original world dimensions and rules are retained;
the fitted portrait canvas uses the space left above the raised gameplay rail.

Rebuild and rerun from a clean bundle checkout:

```bash
npm ci --ignore-scripts --no-audit --no-fund
python3 build.py
bash proof/run.sh
```

The proof uses local cached Chromium when available. Else install the browser
version pinned by Playwright 1.58.2 with `npx playwright install chromium`, or set
`CHROMIUM_PATH` to an existing Chromium executable. The harness records its version.
Both fixture servers bind 127.0.0.1 on free ports in the proof process and close in
its finally block. The report records the process id, source head and cleanup.
No shared service is touched. The shipped page starts no server or background worker.

For the delivered archive, extract it under an owned directory, then run:

```bash
SITE_ROOT=/root/work/game/extracted/site SITE_ARCHIVE=/root/work/out/site.tgz bash proof/run.sh
cd /root/work/game/extracted/site
sha256sum -c legal/FILES.sha256
```

S7 measures Start, New game, Pause, Controls, FPS, Low graphics, Hitboxes,
Black background, Stars, Legal, Move, Fire, Slow and Bomb at 320x240, 240x320,
390x844, 844x390, 1920x1080 and 1080x1920. At fresh boot, during play and after
live resize, it checks both menu states, expected active controls, all rectangle
pairs, and elementFromPoint at each centre and four corners 1px inside the bounds.
Each point must return that exact control. It rejects undersized, clipped,
intercepted or overlapping controls and document/options scrolling. Trusted
lower-Bomb taps at every size must decrease bombs and remain in the game.
The proof kills input-disabled, pointer-lock, off-origin fetch, restored-32px
and restored-colliding-layout CSS mutants. A healthy control precedes each;
files restore byte for byte and healthy controls run again. Off-origin attempts
count even when CSP blocks the request.

Recreate the delivery archive deterministically after `python3 build.py`:

```bash
tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner -C .. -cf - site | gzip -n > /root/work/out/site.tgz
```

The round 3 bundle is incremental and requires round 2 head
`71edb84ea71f92cec4c473892bbb3f27bb1d8c1e`. Import the supplied prior bundles
first, then fetch `repo.bundle` into a new branch. Upload hashes exclude
SHA256SUMS.txt itself and cover exactly the seven delivery files.

The proof demonstrates the frame contract in headless Chromium. Actual ChatGPT
rendering and remote publication belong to the host owner handoff; no public
listing, login, payment or account setup is part of this artifact.
