"""Package the committed, already-vendored static page without network access."""
from pathlib import Path
import subprocess, shutil, tarfile, gzip, json
repo = Path(__file__).resolve().parent
site = repo.parent / 'site'
pin = '75173f8c37868ac7f30b886da6d28560e8e4418b'
def sha(path):
    return subprocess.check_output(['sha256sum', str(path)], text=True).split()[0]
def grant(path, start, end):
    text = path.read_text().replace('\n', ' ').replace('\r', ' ')
    return ' '.join(text[text.index(start):text.index(end)].split())
mit = grant(repo/'LICENSE', 'Permission', 'The above copyright')
ofl = grant(repo/'legal/OFL-1.1.txt', 'Permission', '1) Neither')
lgpl = grant(repo/'legal/LGPL-2.1.txt', '1. You may copy', 'You may charge')
files = sorted([repo/'index.html', repo/'style.css', *[p for p in (repo/'scripts').rglob('*.js') if p.is_file()], *[p for p in (repo/'fonts').rglob('*') if p.is_file()]])
lines = ['# Bullet Hell data and source inventory', '', 'All game art, models and levels are procedural code. No external image, sound, map or data archive is loaded.', '', 'Original source: https://github.com/selenebun/bullethell/tree/'+pin, '', '## Free distribution grants', '', 'MIT, code and procedural data: "'+mit+'"', '', 'OFL 1.1, unchanged Source Code Pro: "'+ofl+'"', '', 'LGPL 2.1 section 1, p5 source: "'+lgpl+'"', '', 'LGPL sections 4 and 6 source obligations are met by local p5-source.tgz, including preferred modules, build scripts, readable library and dependency sources. The whole LGPL text is shipped.', '', 'ieee754 BSD-3-Clause: "Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:" Full conditions and disclaimer are preserved.', '', 'Other bundled dependencies use MIT, with grants and attribution in legal/dependency-notices/. Pins and download hashes are in legal/DEPENDENCIES.json.', '', '## Runtime files', '', '| File | Bytes | SHA256 | Licence and source |', '| --- | ---: | --- | --- |']
for p in files:
    name = str(p.relative_to(repo))
    if name.startswith('fonts/'):
        licence = 'OFL 1.1, upstream pinned font name table 0/13, Adobe 2010/2012, version 1.017'
    elif name == 'scripts/lib/p5.min.js':
        licence = 'LGPL 2.1 and bundled MIT/BSD notices; official npm p5@0.6.0, unchanged'
    else:
        licence = 'MIT; upstream pinned file' + (' with listed frame patch' if name in ['index.html','style.css','scripts/main.js'] else '')
        if name == 'scripts/frame.js': licence = 'MIT; our frame adapter source supplied locally'
    lines.append(f'| {name} | {p.stat().st_size} | `{sha(p)}` | {licence} |')
lines += ['', 'Each original file source address is https://raw.githubusercontent.com/selenebun/bullethell/'+pin+'/ followed by its file name. The three modified files and added adapter are listed in legal/SOURCE.txt. The p5 npm address is https://registry.npmjs.org/p5/-/p5-0.6.0.tgz.', '', 'Notices and source archives are accompanying provenance, not separately loaded game data. legal/FILES.sha256 inventories every served file except itself. It intentionally excludes self entries.', '']
(repo/'DATA.md').write_text('\n'.join(lines))
shutil.copy(repo/'DATA.md', repo/'legal/DATA.md')
# The game source archive includes exact runtime source, notices and rerun tools.
source_files = files + [repo/p for p in ['LICENSE','README.md','README-HOST.md','DECISION.md','DATA.md','build.py','package.json','package-lock.json','proof/check.mjs','proof/run.sh','scripts/ci/fast','legal/SOURCE.txt','legal/MIT.txt','legal/OFL-1.1.txt','legal/LGPL-2.1.txt']]
with (repo/'legal/bullethell-source.tgz').open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for p in sorted(source_files):
                info = archive.gettarinfo(str(p), arcname='bullethell-source/'+str(p.relative_to(repo)))
                info.mtime=0; info.uid=0; info.gid=0; info.uname=''; info.gname=''
                with p.open('rb') as data: archive.addfile(info,data)
if site.exists(): shutil.rmtree(site)
site.mkdir()
for name in ['index.html','style.css','fonts','legal']:
    source=repo/name; dest=site/name
    if source.is_dir(): shutil.copytree(source,dest)
    else: shutil.copy(source,dest)
for p in files:
    if p.is_relative_to(repo/'scripts'):
        dest=site/p.relative_to(repo); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy(p,dest)
manifest=site/'legal/FILES.sha256'
manifest.unlink(missing_ok=True)
served=sorted(p for p in site.rglob('*') if p.is_file())
manifest.write_text(''.join(sha(p)+'  '+str(p.relative_to(site))+'\n' for p in served))
served.append(manifest)
stats={'unpackedBytes':sum(p.stat().st_size for p in served),'files':len(served),'largestFileBytes':max(p.stat().st_size for p in served)}
assert stats['unpackedBytes'] <= 150*1024*1024 and stats['largestFileBytes'] <= 90*1024*1024
print(json.dumps(stats))
