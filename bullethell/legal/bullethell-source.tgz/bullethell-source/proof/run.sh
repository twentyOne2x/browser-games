#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p proof/results
node proof/check.mjs 2>&1 | tee proof/results/run.log
