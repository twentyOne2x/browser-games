import { chromium } from 'playwright';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { resolve, extname } from 'node:path';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
const root = resolve(process.env.SITE_ROOT || '.');
const output = resolve('proof/results');
await mkdir(output, { recursive: true });
const prefix = '/mount/prefix/bullethell/';
const requests = [];
const types = {'.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.ttf':'font/ttf'};
const gameServer = createServer(async (req, res) => {
    requests.push({url:req.url, range:req.headers.range || null});
    try {
        let path = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
        if (!path.startsWith(prefix)) { res.writeHead(404).end(); return; }
        path = path.slice(prefix.length);
        if (!path || path.endsWith('/')) path += 'index.html';
        const file = resolve(root, path);
        assert(file.startsWith(root + '/'));
        const data = await readFile(file);
        // Deliberately ignore Range and use the wrong WASM type.
        res.writeHead(200, {'Content-Type':types[extname(file)] || 'application/octet-stream'});
        res.end(data);
    } catch { res.writeHead(404).end(); }
});
await new Promise(r => gameServer.listen(0, '127.0.0.1', r));
const origin = `http://127.0.0.1:${gameServer.address().port}`;
const parentServer = createServer((req, res) => {
    res.writeHead(200, {'Content-Type':'text/html'});
    res.end(`<!doctype html><html><head><style>html,body{margin:0;height:100%;overflow:hidden}iframe{width:100%;height:100%;border:0;display:block}</style></head><body><iframe src="${origin}${prefix}" sandbox="allow-scripts allow-same-origin"></iframe></body></html>`);
});
await new Promise(r => parentServer.listen(0, '127.0.0.1', r));
const parentOrigin = `http://127.0.0.1:${parentServer.address().port}`;
const cached = '/home/cloudlane/.cache/ms-playwright/chromium-1228/chrome-linux64/chrome';
const executablePath = process.env.CHROMIUM_PATH || (existsSync(cached) ? cached : chromium.executablePath());
const report = {ticket:'PLAY-HOST-BULLETHELL-3', head:execFileSync('git',['rev-parse','HEAD']).toString().trim(),
    sourceTree:execFileSync('git',['diff','--binary','HEAD']).toString(), root, pid:process.pid,
    chromium:executablePath, tests:[], mutations:[], requests, started:new Date().toISOString()};
if (process.env.SITE_ARCHIVE) report.siteArchiveSHA256=execFileSync('sha256sum',[process.env.SITE_ARCHIVE]).toString().split(' ')[0];
let browser;
function pass(id, detail) { report.tests.push({id,status:'PASS',detail}); console.log(`PASS ${id} ${JSON.stringify(detail)}`); }
async function state(frame) {
    return frame.evaluate(() => ({x:pl.pos.x,y:pl.pos.y,hp:pl.hp,level,score,bombs,paused,
        shots:bullets.filter(b => b.fromPlayer && !b.dead).length,slowTime,nextSlowdownTime,dt:dt(),
        showFPS,lowGraphics,showHitboxes,blackStarfield,showStars}));
}
async function open(denied=false, size={width:960,height:720}) {
    const context = await browser.newContext({viewport:size,hasTouch:true,deviceScaleFactor:3});
    const external = [], errors = [], dialogs = [];
    await context.addInitScript(({denied}) => {
        window.frameAudit = {pointerLock:0,fullscreen:0,open:0,dialogs:0,workers:0,serviceWorkers:0,sharedBuffers:0,foreignAttempts:[]};
        const originalFetch=window.fetch;
        window.fetch=function(input,...args) {
            const target=new URL(input instanceof Request ? input.url : String(input),location.href);
            if (target.origin!==location.origin) frameAudit.foreignAttempts.push(target.href);
            return originalFetch.call(this,input,...args);
        };
        Element.prototype.requestPointerLock = function() { frameAudit.pointerLock++; return Promise.reject(new Error('proof blocked pointer lock')); };
        Element.prototype.requestFullscreen = function() { frameAudit.fullscreen++; return Promise.reject(new Error('proof blocked fullscreen')); };
        window.open = () => { frameAudit.open++; return null; };
        for (const k of ['alert','confirm','prompt']) window[k] = () => { frameAudit.dialogs++; };
        for (const k of ['Worker','SharedWorker']) if (window[k]) window[k] = new Proxy(window[k], {construct(){frameAudit.workers++;throw new Error('Unexpected worker');}});
        if (window.SharedArrayBuffer) window.SharedArrayBuffer = new Proxy(window.SharedArrayBuffer,{construct(){frameAudit.sharedBuffers++;throw new Error('Unexpected shared buffer');}});
        if (navigator.serviceWorker) navigator.serviceWorker.register = () => {frameAudit.serviceWorkers++;return Promise.reject(new Error('Unexpected service worker'));};
        if (denied) for (const k of ['localStorage','sessionStorage']) Object.defineProperty(window,k,{get(){throw new DOMException('Denied','SecurityError');}});
    }, {denied});
    const page = await context.newPage();
    page.on('pageerror', e => errors.push(e.message));
    page.on('dialog', async d => { dialogs.push(d.type()); await d.dismiss(); });
    await context.route('**/*', async route => {
        const request = route.request();
        const destination = new URL(request.url()).origin;
        const allowed = destination === origin || (destination === parentOrigin && request.frame() === page.mainFrame());
        if (!allowed) { external.push(request.url()); await route.abort(); }
        else await route.continue();
    });
    const t0 = performance.now();
    await page.goto(parentOrigin);
    const frame = page.frames().find(f => f.url().startsWith(origin));
    assert(frame, 'cross origin game frame exists');
    await frame.waitForFunction(() => typeof pl !== 'undefined' && pl && document.querySelector('canvas'));
    await frame.locator('#start').waitFor({state:'visible'});
    const firstLoadMs = Math.round(performance.now()-t0);
    assert.equal(await page.locator('iframe').getAttribute('sandbox'),'allow-scripts allow-same-origin');
    assert.equal(await page.locator('iframe').getAttribute('allow'),null);
    return {context,page,frame,external,errors,dialogs,firstLoadMs};
}
async function start(session, touch=false) {
    const button = session.frame.locator('#start');
    if (await button.isVisible()) touch ? await tap(session, '#start') : await button.click();
    else touch ? await tap(session, '#restart') : await session.frame.locator('#restart').click();
    const s = await state(session.frame);
    assert.equal(s.paused,false); assert.equal(s.level,0); assert.equal(s.bombs,2); assert.equal(s.hp,7);
    return s;
}
async function keyboard(session) {
    await start(session);
    const before = await state(session.frame);
    await session.page.keyboard.down('ArrowRight');
    await session.page.keyboard.down('z');
    try { await session.frame.waitForFunction(x => pl.pos.x > x+12 && bullets.some(b => b.fromPlayer && !b.dead),before.x,{timeout:4000}); }
    finally { await session.page.keyboard.up('z'); await session.page.keyboard.up('ArrowRight'); }
    const after = await state(session.frame);
    assert(after.x > before.x+12 && after.shots > 0,'S3 actual movement and player shot');
    await session.page.keyboard.press('x'); assert((await state(session.frame)).slowTime > 0);
    await session.page.keyboard.press('c'); assert.equal((await state(session.frame)).bombs,1);
    await session.page.keyboard.press('p'); assert.equal((await state(session.frame)).paused,true);
    return {before,after};
}
async function tap(session, selector) {
    const r = await session.frame.locator(selector).boundingBox();
    assert(r); await session.page.touchscreen.tap(r.x+r.width/2,r.y+r.height/2);
}
async function touch(session) {
    await start(session,true);
    const before = await state(session.frame);
    const stick = await session.frame.locator('#stick').boundingBox();
    const fire = await session.frame.locator('#fire').boundingBox();
    const cdp = await session.context.newCDPSession(session.page);
    const p1 = {id:1,x:stick.x+stick.width-8,y:stick.y+stick.height/2,radiusX:4,radiusY:4};
    const p2 = {id:2,x:fire.x+fire.width/2,y:fire.y+fire.height/2,radiusX:4,radiusY:4};
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[p1]});
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[p1,p2]});
    try { await session.frame.waitForFunction(x => pl.pos.x > x+12 && bullets.some(b=>b.fromPlayer&&!b.dead),before.x,{timeout:4000}); }
    finally { await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]}); await cdp.detach(); }
    const after = await state(session.frame);
    assert(after.x>before.x+12 && after.shots>0,'S4 actual multitouch move and shot');
    assert.equal(await session.frame.evaluate(() => held.size),0,'normal touchEnd releases keys');
    const tickAfterRelease=await session.frame.evaluate(() => frameCount);
    await session.frame.waitForFunction(t => frameCount > t+2,tickAfterRelease);
    assert(await session.frame.evaluate(() => pl.vel.x===0 && pl.vel.y===0));
    await session.page.screenshot({path:`${output}/touch-${session.page.viewportSize().width}x${session.page.viewportSize().height}.png`});
    await tap(session,'[data-key="88"]'); assert((await state(session.frame)).slowTime>0);
    await tap(session,'[data-key="67"]'); assert.equal((await state(session.frame)).bombs,1);
    await tap(session,'[data-key="80"]'); assert.equal((await state(session.frame)).paused,true);
    const pos = await state(session.frame);
    const tick = await session.frame.evaluate(() => frameCount);
    await session.frame.waitForFunction(tick => frameCount > tick+5,tick);
    assert.equal((await state(session.frame)).x,pos.x);
    await tap(session,'#more');
    const names = {70:'showFPS',71:'lowGraphics',72:'showHitboxes',84:'blackStarfield',89:'showStars'};
    for (const [code,name] of Object.entries(names)) {
        const prior = (await state(session.frame))[name];
        await tap(session,`[data-key="${code}"]`);
        assert.equal((await state(session.frame))[name],!prior,`touch ${name}`);
    }
    await tap(session,'#more'); await tap(session,'#restart');
    const restarted=await state(session.frame); assert.equal(restarted.bombs,2); assert.equal(restarted.score,0);
    assert.equal(await session.frame.evaluate(() => held.size),0);
    return {before,after,restarted};
}
async function audit(s) {
    const counters = await s.frame.evaluate(() => frameAudit);
    assert.equal(counters.pointerLock,0,'S5 pointer lock'); assert.equal(counters.fullscreen,0);
    assert.equal(counters.open,0); assert.equal(counters.dialogs,0); assert.equal(s.dialogs.length,0);
    assert.deepEqual(counters.foreignAttempts,[],'S5 foreign attempts');
    assert.deepEqual(s.external,[],'S5 external origins'); assert.deepEqual(s.errors,[],'runtime errors');
    assert.deepEqual(await s.context.cookies(),[]);
    assert.equal(counters.workers,0); assert.equal(counters.serviceWorkers,0); assert.equal(counters.sharedBuffers,0);
    return counters;
}
async function touchRecovery(s) {
    await start(s,true);
    const stick=await s.frame.locator('#stick').boundingBox(),fire=await s.frame.locator('#fire').boundingBox();
    const p1={id:1,x:stick.x+stick.width-8,y:stick.y+stick.height/2},p2={id:2,x:fire.x+fire.width/2,y:fire.y+fire.height/2};
    const cdp=await s.context.newCDPSession(s.page);
    try {
        await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[p1]});
        await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[p1,p2]});
        const p3={...p2,id:3,x:p2.x+2};
        await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[p1,p2,p3]});
        // CDP derives individual releases from the active points on touchMove.
        await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[p1,p2]});
        assert(await s.frame.evaluate(()=>held.has(90)&&keyIsDown(90)), 'Fire keeps its original pointer owner '+JSON.stringify(await s.frame.evaluate(()=>({held:[...held],pointers:[...buttonPointers.values()],stickPointer,key:keyIsDown(90)}))));
        await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{...p1,x:stick.x+8,y:stick.y+8},p2]});
        const before=await state(s.frame);
        await s.frame.waitForFunction(p=>pl.pos.x<p.x-8&&pl.pos.y<p.y-8,before);
        await cdp.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});
        assert.equal(await s.frame.evaluate(()=>held.size),0);
        assert(await s.frame.evaluate(()=>[37,38,39,40,90].every(n=>!keyIsDown(n))));
        await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[p1]});
        await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[p1,p2]});
        await s.page.locator('body').evaluate(e=>{e.tabIndex=0;e.focus();});
        assert.equal(await s.frame.evaluate(()=>held.size),0,'iframe blur releases keys');
        assert(await s.frame.evaluate(()=>[37,38,39,40,90].every(n=>!keyIsDown(n))));
        await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
    } finally { await cdp.detach(); }
    await touch(s);
    return {extraPointer:true,directionChange:true,touchCancel:true,blur:true,healthyAfterward:true};
}
const targetSizes = [{width:320,height:240},{width:240,height:320},{width:390,height:844},{width:844,height:390},
    {width:1920,height:1080},{width:1080,height:1920}];
const controlSelectors = ['#start','#restart','[data-key="80"]','#more',
    '.legal-link','#stick','#fire','[data-key="88"]','[data-key="67"]',
    '[data-key="70"]','[data-key="71"]','[data-key="72"]','[data-key="84"]','[data-key="89"]'];
async function targetMeasurements(s, size, started=false) {
    await s.page.setViewportSize(size);
    await s.frame.waitForFunction(size => innerWidth === size.width && innerHeight === size.height, size);
    await s.frame.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))));
    const measure = async selectors => s.frame.evaluate(selectors => selectors.map(selector => {
        const element = document.querySelector(selector), r = element.getBoundingClientRect();
        const points = [[r.x+r.width/2,r.y+r.height/2],[r.x+1,r.y+1],
            [r.right-1,r.y+1],[r.x+1,r.bottom-1],[r.right-1,r.bottom-1]];
        const hits = points.map(([x,y]) => {
            const hit=document.elementFromPoint(x,y);
            return {x,y,hit:hit===element,actual:hit && (hit.id || hit.className || hit.tagName)};
        });
        return {selector,x:r.x,y:r.y,width:r.width,height:r.height,
            visible:!!element.getClientRects().length,hits};
    }).filter(t => t.visible), selectors);
    const closed = await measure(controlSelectors);
    await tap(s,'#more');
    const opened = await measure(controlSelectors);
    const fit = await s.frame.evaluate(() => {
        const d=document.documentElement,b=document.body,o=document.getElementById('options');
        const t=document.querySelector('.toolbar'),r=o.getBoundingClientRect();
        return {documentScroll:d.scrollWidth>innerWidth || d.scrollHeight>innerHeight ||
            b.scrollWidth>innerWidth || b.scrollHeight>innerHeight,
            optionsScroll:o.scrollWidth>o.clientWidth || o.scrollHeight>o.clientHeight,
            optionsInside:r.x>=0 && r.y>=0 && r.right<=innerWidth && r.bottom<=innerHeight,
            toolbarHeight:t.getBoundingClientRect().height};
    });
    await s.page.screenshot({path:`${output}/targets-${size.width}x${size.height}.png`});
    await tap(s,'#more');
    return {size,started,closed,opened,fit};
}
function assertTargets(measurements) {
    const failures=[];
    for (const {size,started,closed,opened,fit} of measurements) {
        const expected=started ? controlSelectors.slice(1) : controlSelectors;
        for (const selector of expected) if (![...closed,...opened].some(t=>t.selector===selector))
            failures.push(`${size.width}x${size.height} ${selector} never reachable`);
        for (const [phase,targets] of [['closed',closed],['opened',opened]]) {
        const visible=phase==='closed' ? expected.filter(s=>!controlSelectors.slice(9).includes(s))
            : controlSelectors.filter(s=>!['#start','#stick','#fire','[data-key="88"]','[data-key="67"]'].includes(s));
        if (JSON.stringify(targets.map(t=>t.selector))!==JSON.stringify(visible))
            failures.push(`${size.width}x${size.height} ${phase} unexpected visible controls`);
        for (const t of targets) {
            if (t.width<44 || t.height<44) failures.push(`${size.width}x${size.height} ${t.selector} ${t.width}x${t.height} below 44`);
            if (t.hits.some(p=>!p.hit) || t.x<0 || t.y<0 || t.x+t.width>size.width || t.y+t.height>size.height)
                failures.push(`${size.width}x${size.height} ${t.selector} outside frame or unreachable`);
        }
        for (let i=0;i<targets.length;i++) for (const b of targets.slice(i+1)) {
            const a=targets[i];
            if (Math.min(a.x+a.width,b.x+b.width)>Math.max(a.x,b.x) &&
                Math.min(a.y+a.height,b.y+b.height)>Math.max(a.y,b.y))
                failures.push(`${size.width}x${size.height} ${phase} ${a.selector} overlaps ${b.selector}`);
        }
        }
        if (fit.documentScroll || fit.optionsScroll || !fit.optionsInside)
            failures.push(`${size.width}x${size.height} document/options fit`);
        if (fit.toolbarHeight<44) failures.push(`${size.width}x${size.height} toolbar cannot reserve 44`);
    }
    assert.equal(failures.length,0,`S7 touch targets: ${failures.join('; ')}`);
}
async function allTargets(s, key='targetMeasurements', started=false) {
    const measurements=[];
    for (const size of targetSizes) measurements.push(await targetMeasurements(s,size,started));
    report[key]=measurements;
    assertTargets(measurements);
    return measurements;
}
async function lowerBomb(size) {
    const s=await open(false,size);
    try {
        await start(s,true);
        const before=await state(s.frame),r=await s.frame.locator('[data-key="67"]').boundingBox();
        const point={x:r.x+r.width/2,y:r.y+r.height-8};
        await s.page.touchscreen.tap(point.x,point.y);
        assert.equal(s.frame.url(),`${origin}${prefix}`,'lower Bomb stays in game');
        const after=await state(s.frame);
        assert.equal(after.bombs,before.bombs-1,'lower Bomb activates Bomb');
        await audit(s);
        return {size,point,beforeBombs:before.bombs,afterBombs:after.bombs};
    } finally { await s.context.close(); }
}
async function layout(s,size) {
    await s.page.setViewportSize(size);
    await s.frame.waitForFunction(size => innerWidth === size.width && innerHeight === size.height, size);
    await s.frame.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))));
    const geometry = await s.frame.evaluate(() => {
        const c=document.querySelector('canvas'),r=c.getBoundingClientRect(),a=document.getElementById('stage').getBoundingClientRect();
        return {x:r.x,y:r.y,width:r.width,height:r.height,pixels:c.width,density:pixelDensity(),stage:{width:a.width,height:a.height},viewport:{width:innerWidth,height:innerHeight},overflow:document.body.scrollWidth>innerWidth};
    });
    assert(Math.abs(geometry.width/geometry.height-600/750)<0.015);
    assert(geometry.x>=0&&geometry.y>=0&&geometry.x+geometry.width<=size.width+1&&geometry.y+geometry.height<=size.height+1, JSON.stringify(geometry));
    assert(geometry.density<=2&&geometry.pixels/geometry.width<=2.02&&!geometry.overflow, JSON.stringify(geometry));
    assert(Math.min(geometry.stage.width-geometry.width,geometry.stage.height-geometry.height)<2);
    await s.page.screenshot({path:`${output}/${size.width}x${size.height}.png`});
    return geometry;
}
try {
    browser = await chromium.launch({executablePath,headless:true,args:['--no-sandbox','--disable-gpu']});
    report.browserVersion=browser.version();
    const healthy=await open();
    pass('S1',{firstLoadMs:healthy.firstLoadMs,crossOrigin:true,prefix,noRange:true});
    const bootTargets=[];
    for (const size of targetSizes) {
        const boot=await open(false,size);
        try { bootTargets.push(await targetMeasurements(boot,size)); await audit(boot); }
        finally { await boot.context.close(); }
    }
    report.bootTargetMeasurements=bootTargets; assertTargets(bootTargets); pass('S7-BOOT',bootTargets);
    pass('S7',await allTargets(healthy));
    pass('S2',await start(healthy)); pass('S3',await keyboard(healthy));
    pass('S7-PLAY',await allTargets(healthy,'playingTargetMeasurements',true));
    for (const size of targetSizes) pass(`LOWER-BOMB-${size.width}x${size.height}`,await lowerBomb(size));
    const layouts=[];
    for (const size of targetSizes) layouts.push(await layout(healthy,size));
    pass('LAYOUT',layouts);
    for (const size of [{width:390,height:844},{width:844,height:390}]) {
        await healthy.page.setViewportSize(size); pass(`S4-${size.width}x${size.height}`,await touch(healthy));
    }
    pass('TOUCH-RECOVERY',await touchRecovery(healthy));
    pass('S5',await audit(healthy));
    await tap(healthy,'.legal-link'); await healthy.frame.waitForURL(`${origin}${prefix}legal/`);
    assert.equal(await healthy.frame.locator('h1').textContent(),'Bullet Hell legal');
    assert((await healthy.frame.locator('a[href="SOURCE.txt"]').count())>0);
    await healthy.context.close();
    const denied=await open(true,{width:390,height:844});
    assert(await denied.frame.evaluate(()=>{try{localStorage;return false;}catch{return true;}}));
    const deniedEvidence={keyboard:await keyboard(denied),touch:await touch(denied),audit:await audit(denied)};
    pass('S6',deniedEvidence); await denied.context.close();
    // Healthy control above always precedes the source mutations.
    for (const [name,file,mutate,check,expected] of [
        ['input-disabled','scripts/class/player.js',s=>s.replace('controls() {','controls() { return;'),keyboard,'Timeout'],
        ['pointer-lock','scripts/frame.js',s=>s+'\nwindow.addEventListener("load",()=>document.body.requestPointerLock().catch(()=>{}));\n',audit,'S5 pointer lock'],
        ['off-origin','scripts/frame.js',s=>s+'\nwindow.addEventListener("load",()=>fetch("https://example.invalid/mutation").catch(()=>{}));\n',audit,'S5 foreign attempts'],
        ['small-targets','style.css',s=>s.replace('min-height: 44px;', 'min-height: 32px;'),s=>allTargets(s,'mutantTargetMeasurements'),'below 44'],
        ['colliding-layout','style.css',s=>s.replace('bottom: 48px;', 'bottom: 16px;'),s=>allTargets(s,'collidingTargetMeasurements'),'.legal-link overlaps [data-key="67"]']
    ]) {
        const control=await open();
        try { await check(control); await audit(control); }
        finally { await control.context.close(); }
        const path=resolve(root,file), original=await readFile(path);
        let killed=false,session;
        try {
            const changed=mutate(original.toString()); assert.notEqual(changed,original.toString()); await writeFile(path,changed);
            session=await open();
            try { await check(session); } catch(e) { assert(String(e).includes(expected),String(e)); killed=true; report.mutations.push({name,killed:true,healthyBefore:true,witness:String(e)}); console.log(`PASS MUTATION ${name} rejected`); }
            assert(killed,`${name} survived`);
        } finally { if(session) await session.context.close(); await writeFile(path,original); assert.deepEqual(await readFile(path),original); }
        const recovered=await open();
        try {
            if (name==='small-targets' || name==='colliding-layout') await allTargets(recovered,'recoveredTargetMeasurements');
            else await check(recovered);
            await audit(recovered);
            report.mutations.at(-1).restoredByteForByte=true;
            report.mutations.at(-1).healthyAfterward=true;
        } finally { await recovered.context.close(); }
    }
    const restored=await open(); await allTargets(restored,'restoredTargetMeasurements'); await keyboard(restored); await audit(restored); await restored.context.close();
    pass('RESTORED',{byteForByte:true,healthyControl:true});
    report.status='PASS';
} catch(e) { report.status='FAIL'; report.error=String(e.stack||e); console.error(e); process.exitCode=1; }
finally {
    if(browser) await browser.close();
    await Promise.all([new Promise(r=>gameServer.close(r)),new Promise(r=>parentServer.close(r))]);
    report.stopped=new Date().toISOString(); report.serversStopped=true;
    await writeFile(`${output}/report.json`,JSON.stringify(report,null,2)+'\n');
}
