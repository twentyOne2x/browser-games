# Bullet Hell hosting decision

Reuse selenebun/bullethell commit 75173f8c37868ac7f30b886da6d28560e8e4418b.
It is already a working JavaScript/p5 browser game with procedural art and a
locally bundled font and library. No new engine or game rules are needed.
The original title is Bullet Hell and original author is Amelia Clarke.

The code and procedural game data carry MIT permission. The font embeds OFL 1.1.
The p5 vendor is byte-identical to official npm p5@0.6.0 and is LGPL 2.1.
All bundled dependency notices, readable library, preferred core modules,
build scripts and original lock are supplied locally. No unclear game data is used.
Licence grant sentences, exact asset hashes and source addresses are in DATA.md.

The shell follows twentyone2x/browser-games at
9e94abf8755175e03efc82bbc84ff4a67e69a264: 2048's relative legal page, source pin,
numbered patch notice and corner link; Doom's local corresponding-source archive.
No engine code was copied from those siblings. No Bullethell sibling exists at
that pin. The Mac/Q LEGOS index and shared work logs are unavailable on this box.
The supplied preamble and reachable repositories were checked; no local duplicate
work or existing game checkout was present. No attn-packs source was changed.

Fix the logical playfield at 600x750. The original variable-height setup shrinks
world geometry on short frames; entities snapshot their bounds at construction.
CSS fitting preserves the original world and follows every resize. The density
tracks rendered scale and device density with a maximum of 2. This also avoids
oversized backing buffers on small phones.

Touch feeds the existing p5 keyboard handlers, preserving diagonal normalization,
weapons, bombs, slow time, pause and debug toggles. Each held control owns one
pointer. Cancellation, capture loss, iframe blur and visibility loss release it.
Start/restart call the existing resetGame() and explicitly resume its paused flag.

Rejected options: rewriting an engine; replacing the game with a look-alike;
remote CDNs; viewport-dependent world bounds; pointer lock/fullscreen; storage;
a separate player application; adding this page to a submitted public listing.
No ioquake build or unrelated game-data archive is relevant to this JavaScript game.

Proof reads the real player, bullet, cooldown and game-state objects. It uses a
cross-origin sandbox frame, a nested path prefix, DPR 3 with capped backing pixels,
keyboard, simultaneous CDP touches and denied storage. Healthy controls precede
mutants disabling Player.controls() and adding a pointer-lock request. Files are
restored byte for byte, followed by another healthy input and audit run.

A transient harness race after viewport resize and after legal navigation was
resolved by waiting for actual frame dimensions and the destination URL. A touch
recovery check used the wrong CDP partial-release event; the pinned protocol says
touchEnd must have no points. touchMove with remaining active points tests the
individual release. These development failures are retained in the evidence.
The original import was a new port. Fix round 2 repairs the reviewed touch-size
defect with a test-only failing commit followed by the CSS fix commit. The
reviewed base and upstream history are preserved, including their old messages.
Both new commit messages carry attribution and explicit size declarations.

The fix retains stage width and height by compensating the 12px taller toolbar
with 12px less bottom inset. It retains the enlarged Legal hit area in the lower
right. Independent round 2 review found it covers Bomb at 240x320. The game aspect, dimensions and
gameplay target rules remain unchanged. S7 measures all fourteen controls at
the five requested sizes and kills a restored-32px mutation. The added off-origin
fetch mutation is detected as an attempt even when CSP prevents network traffic.

Fix round 3 addresses only the reviewed control boundary. Portrait reserves
Legal's 44px row with a 4px gap, raising the touch rail, status and stage bottom
by 32px. Landscape keeps its existing rail geometry. Transparent pseudo elements
extend rounded controls to their claimed rectangular bounds without changing
their visible shape or input handlers. Controls is a menu state, hiding the
gameplay rail and welcome button while open; closing restores them. Its smaller
padding and height cap fit above Legal at both short proof sizes.

The red-first production proof checks all fourteen controls across both active
states at all six retained sizes. It tests exact elementFromPoint hits at centres
and four 1px inner corners, every active control pair, fresh boot, playing and
live resize. Trusted lower-Bomb taps confirm the correct action. The added
mutation restores the old rail bottom inset and must fail specifically on the
240x320 Bomb/Legal intersection, with healthy controls and byte restoration.
