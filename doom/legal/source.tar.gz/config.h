#ifndef FREEDOOM_CONFIG_H
#define FREEDOOM_CONFIG_H
#define PACKAGE_NAME "Chocolate Doom"
#define PACKAGE_TARNAME "chocolate-doom"
#define PACKAGE_VERSION "3.0.0"
#define PACKAGE_STRING "Chocolate Doom 3.0.0"
#define PACKAGE_SHORTNAME "Chocolate"
#define PACKAGE_SHORTDESC "Freedoom browser port"
#define PACKAGE_COPYRIGHT "Copyright (C) 1993-2021"
#define PACKAGE_LICENSE "GNU General Public License, version 2"
#define PACKAGE_MAINTAINER "Chocolate Doom contributors"
#define PACKAGE_URL ""
#define PACKAGE_BUGREPORT ""
#define PROGRAM_PREFIX "chocolate-"
#define HAVE_DIRENT_H 1
#define HAVE_DECL_STRCASECMP 1
#define HAVE_DECL_STRNCASECMP 1
#endif
