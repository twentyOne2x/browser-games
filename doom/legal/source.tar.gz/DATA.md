# Data provenance

| File | Bytes | SHA256 | Source |
| --- | ---: | --- | --- |
| freedoom-0.13.0.zip | 24143781 | 3f9b264f3e3ce503b4fb7f6bdcb1f419d93c7b546f4df3e874dd878db9688f59 | https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0.zip |
| freedoom-0.13.0-CHECKSUM | 898 | 01a627fa0c80b7446f4f435df6fffef8f354a9987b23870bc5ea5464ca82e977 | https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0-CHECKSUM |
| freedoom-0.13.0.zip.sig | 438 | 77f243f179a42317e22e816e3e7b012a505d36e8416fe5cb914220e58412c789 | https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0.zip.sig |
| freedoom1.wad | 28795076 | 7323bcc168c5a45ff10749b339960e98314740a734c30d4b9f3337001f9e703d | https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0.zip#freedoom-0.13.0/freedoom1.wad |
| COPYING.txt | 1644 | 7c62f2c520769c798774f416637eec4921e5f0aafdac1245ae7c8a8cf65fe102 | https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0.zip#freedoom-0.13.0/COPYING.txt |
| CREDITS.txt | 15872 | 72364333d295c598d75ef9553d3b3661ad0b60e27271c87b7637c74b2f46918a | https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0.zip#freedoom-0.13.0/CREDITS.txt |
| CREDITS-MUSIC.txt | 9388 | 2bb77677bbc4e587bba44ccb6514ee0f5397c7bb8ae9580b9188d3d6a57c0a31 | https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0.zip#freedoom-0.13.0/CREDITS-MUSIC.txt |

The archive SHA256 matches the release CHECKSUM. Only freedoom1.wad is extracted as game data. No other WAD is extracted or shipped. GPG verification returned exit 2: the signature names key 90BB5F797B0ED14D310F90BE39B3786A18C93DAD, but that public key is unavailable in the isolated keyring. No signature validity claim is made.
