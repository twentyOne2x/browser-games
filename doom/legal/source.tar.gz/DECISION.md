# Port decision

EXTEND cloudflare/doom-wasm@65e0d3ae2ffa604155eebd96ed40da6567bd08f4. Reuse Chocolate Doom and its Emscripten frame loop.

UTC start: 2026-10-09T15:19:52Z.
UTC end: 2026-10-09T15:31:16Z. The lead engine linked within the 30 minute window.

The pinned tree has CMakeLists.txt and configure.ac. Its CMake path references missing cmake/config.h.cin and missing game directories. The local CMake wrapper uses the existing Makefile.am source inventories and a small config.h. It builds Doom only, with SDL2 and SDL2_mixer. WebSocket and SDL_net transports are excluded. The engine is not rewritten.

Engine: https://github.com/cloudflare/doom-wasm/tree/65e0d3ae2ffa604155eebd96ed40da6567bd08f4
Licence: GPL-2.0, retained in upstream/COPYING.md.
SDK: https://github.com/emscripten-core/emsdk/tree/35ff8a6d150541276abbc6bae512ca90bcfbe220
Emscripten release: 3.1.64, emcc a1fe3902bf73a3802eae0357d273d0e37ea79898, MIT.
SDK toolchain: fd61bacaf40131f74987e649a135f1dd559aff60.
Node tool: 24.19.0, supplied by the pinned SDK manifest.
Browser proof: playwright 1.63.0, Chromium revision 1243, existing Q browser cache. No browser download.

The fallback ozkl/doomgeneric was not needed: the lead engine linked inside the 30 minute choice window. C1 was proven at 2026-10-09T15:42:23Z and delivered at 2026-10-09T15:44:40Z. Build and browser logs are shipped with the report.
