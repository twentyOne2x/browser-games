# Host Freedoom

Upload every file from site.tar.gz to one static folder. The archive has the site files at its top level. No build tool or server program is needed to host it. All resource paths are relative.

Files: index.html, style.css, game.js, freedoom.js, freedoom.wasm, freedoom1.wad, and legal/ with its licence, credits, source notice and corresponding source archive. The complete upload list is written to site-files.txt at packaging.

Preferred content types: .html text/html, .css text/css, .js text/javascript, .wasm application/wasm, .wad application/octet-stream, .txt text/plain, .svg image/svg+xml, .gz application/gzip. The loader always instantiates wasm from an ArrayBuffer, so a wrong .wasm content type works. The server needs neither Range support nor cross-origin isolation headers.

Embed from a different origin:

```html
<iframe src="https://YOUR_STATIC_HOST/YOUR_PATH/index.html" sandbox="allow-scripts allow-same-origin" width="960" height="600"></iframe>
```

Replace the source URL with the hosted folder on its own origin. Do not add permission attributes. The game uses no pointer lock, fullscreen, network play, shared memory, cookies or analytics.

Rebuild on Q with the pinned Emscripten 3.1.64 SDK under W/emsdk and the verified freedoom1.wad under W/downloads:

```sh
bash scripts/build.sh
PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 npm ci --ignore-scripts --no-audit --no-fund
bash proof/run.sh
```

The proof uses dynamic loopback ports and Chromium revision 1243 from the existing Q browser cache. The result and screenshots are written to proof/out/. Server processes are stopped by their recorded PIDs.

The local bundle can be checked without a remote with bash scripts/verify-clean.sh. It checks out main into a fresh folder under W, uses the pinned SDK and verified data files, runs the complete browser and mutation checks, and selects those proven build files for delivery. Source and delivery audits are python3 scripts/audit.py and python3 scripts/audit.py --delivery.
