#!/bin/bash
export W=/lanes2/gamework/doom-drag-1 TMPDIR=/lanes2/gamework/doom-drag-1/tmp npm_config_cache=/lanes2/gamework/doom-drag-1/npm-cache PIP_CACHE_DIR=/lanes2/gamework/doom-drag-1/pip-cache XDG_CACHE_HOME=/lanes2/gamework/doom-drag-1/cache
set -euo pipefail
owner_repo=$(cd "$(dirname "$0")/.." && pwd)
verification_dir=$(mktemp -d "$W/clean-check.XXXXXX")
git init -q -b main "$verification_dir/repo"
git -C "$verification_dir/repo" fetch -q --no-tags "$W/out/repo.bundle" main
git -C "$verification_dir/repo" checkout -q -B main FETCH_HEAD
head=$(git -C "$verification_dir/repo" rev-parse HEAD)
test "$head" = "$(git -C "$owner_repo" rev-parse main)"
test -z "$(git -C "$verification_dir/repo" remote)"
cd "$verification_dir/repo"
PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 npm ci --ignore-scripts --no-audit --no-fund
export FREEDOOM_BUILD_DIR="$verification_dir/build" FREEDOOM_SITE_DIR="$verification_dir/site" SITE_DIR="$verification_dir/site"
bash scripts/build.sh
bash proof/run.sh
bash scripts/ci/fast
python3 scripts/audit.py
test -z "$(git status --porcelain)"
export FREEDOOM_OWNER_REPO="$owner_repo" FREEDOOM_CLEAN_ROOT="$verification_dir"
python3 - <<'PY'
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
w=Path(os.environ['W']); clean=Path(os.environ['FREEDOOM_CLEAN_ROOT']); owner=Path(os.environ['FREEDOOM_OWNER_REPO'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['index.html','game.js','style.css','freedoom.js','freedoom.wasm','freedoom1.wad']
previous={name:sha(w/'site'/name) for name in names}
current={name:sha(clean/'site'/name) for name in names}
shutil.copytree(clean/'site',w/'site',dirs_exist_ok=True)
shutil.copytree(clean/'repo/proof/out',owner/'proof/out',dirs_exist_ok=True)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':'bash scripts/verify-clean.sh','head':subprocess.check_output(['git','-C',str(owner),'rev-parse','main'],text=True).strip(),'clean_root':str(clean),'inputs':current,'same_runtime_bytes':previous==current,'pass':1,'fail':0,'skip':0}
(w/'out/clean-check.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS G3 clean bundle checkout builds and proves the delivered runtime',json.dumps(result,separators=(',',':')))
PY
cd "$owner_repo"
export FREEDOOM_SITE_DIR="$W/site"
bash scripts/ci/fast
printf 'COUNTS PASS 1 FAIL 0 SKIP 0\n'
