from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import argparse
import datetime
import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--delivery', action='store_true')
args = parser.parse_args()
repo = Path(__file__).resolve().parent.parent
W = Path('/lanes2/gamework/doom-drag-1')
site = Path(os.environ.get('FREEDOOM_SITE_DIR', str(W / 'site')))
out = W / 'out'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
results = []

def passed(name, **numbers):
    results.append({'name': name, 'pass': True, 'numbers': numbers})
    print('PASS', name, json.dumps(numbers, separators=(',', ':')), flush=True)

subprocess.run(['python3', str(repo / 'scripts/provenance.py'), 'check'], check=True)
pristine = W / 'upstream'
folder = W / ('patch-check-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f'))
folder.mkdir()
archive = subprocess.check_output(['git', '-C', str(pristine), 'archive', 'HEAD'])
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    tar.extractall(folder, filter='data')
subprocess.run(['patch', '--batch', '-p2', '-d', str(folder), '-i', str(repo / 'patches/browser.patch')], check=True, stdout=subprocess.DEVNULL)
names = subprocess.check_output(['git', '-C', str(pristine), 'ls-tree', '-r', '--name-only', 'HEAD'], text=True).splitlines()
assert all((folder / name).read_bytes() == (repo / 'upstream' / name).read_bytes() for name in names)
assert subprocess.check_output(['git', '-C', str(W / 'emsdk'), 'rev-parse', 'HEAD'], text=True).strip() == '35ff8a6d150541276abbc6bae512ca90bcfbe220'
assert not subprocess.check_output(['git', '-C', str(repo), 'remote'], text=True)
authors = subprocess.check_output(['git', '-C', str(repo), 'log', '--format=%an'], text=True).splitlines()
assert set(authors) == {'DOOM-DRAG-1'}
passed('G0 pinned source patch reproduces the owned tree', files=len(names), commits=len(authors), changed=len(json.loads((repo / 'patches/list.json').read_text())), remotes=0)

zip_path = W / 'downloads/freedoom-0.13.0.zip'
assert zip_path.stat().st_size == 24143781
zip_hash = sha(zip_path)
assert zip_hash == '3f9b264f3e3ce503b4fb7f6bdcb1f419d93c7b546f4df3e874dd878db9688f59'
checksum = (W / 'downloads/freedoom-0.13.0-CHECKSUM').read_text()
assert re.search(r'^SHA256 \(freedoom-0.13.0.zip\) = ' + zip_hash + r'$', checksum, re.M)
wad = site / 'freedoom1.wad'
assert wad.stat().st_size == 28795076 and sha(wad) == '7323bcc168c5a45ff10749b339960e98314740a734c30d4b9f3337001f9e703d'
assert [str(p.relative_to(site)) for p in site.rglob('*.wad')] == ['freedoom1.wad']
with zipfile.ZipFile(zip_path) as z:
    for name in ['COPYING.txt', 'CREDITS.txt', 'CREDITS-MUSIC.txt']:
        assert (site / 'legal' / name).read_bytes() == z.read('freedoom-0.13.0/' + name)
passed('G1 verified Phase 1 data is the only WAD', zip_bytes=zip_path.stat().st_size, zip_sha256=zip_hash, checksum_match=True, wad_bytes=wad.stat().st_size, wad_sha256=sha(wad), wad_count=1)

runtime = (site / 'freedoom.js').read_text()
page = (site / 'game.js').read_text()
for token in ['requestPointerLock', 'pointerLockElement', 'requestFullscreen', 'SharedArrayBuffer', 'WebSocket', 'serviceWorker', 'document.cookie']:
    assert token not in runtime and token not in page, token
assert not re.search(r'["\']pointerlock(?:change|error)["\']', runtime)
assert not re.search(r'\b(?:alert|confirm|prompt)\s*\(|window\.open\s*\(', runtime + page)
sources = re.findall(r'\bupstream/[\w/]+\.c\b', (repo / 'CMakeLists.txt').read_text())
for name in sources:
    assert 'SDL_SetRelativeMouseMode(' not in (repo / name).read_text()
assert 'net_websockets.c' not in sources and 'net_sdl.c' not in sources
proof = json.loads((repo / 'proof/out/report.json').read_text())
assert proof['mode'] == 'full' and proof['fail'] == 0
for item in proof['results']:
    if 'lock counters' in item['name']:
        assert item['numbers']['lock_calls'] == 0
passed('G2 built input and runtime keep lock calls at zero', c_sources=len(sources), healthy_lock_checks=sum('lock counters' in r['name'] for r in proof['results']), lock_calls=0)
assert all(any(r['name'].startswith('S' + str(n)) and r['pass'] for r in proof['results']) for n in range(8))
passed('G3 real browser invariants S0 through S7 pass', passed=proof['pass'], failed=proof['fail'], skipped=proof['skip'], command='bash proof/run.sh')
mutations = json.loads((repo / 'proof/out/mutations.json').read_text())
assert mutations['pass'] == 5 and mutations['fail'] == 0 and mutations['checks'][-1]['sha256'] == sha(site / 'game.js')
assert mutations['test_sha256'] == sha(repo / 'proof/mutations.py')
passed('G4 healthy controls detect both mutations and restore bytes', passed=5, failed=0, restored_sha256=sha(site / 'game.js'))

class Links(HTMLParser):
    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in ['src', 'href'] and value:
                assert not urlsplit(value).scheme and not value.startswith('//') and not value.startswith('/'), value

for html in site.rglob('*.html'):
    Links().feed(html.read_text())
assert not re.search(r'https?://', runtime + page)
filenames = [str(p.relative_to(site)) for p in site.rglob('*') if p.is_file()]
assert len({name.casefold() for name in filenames}) == len(filenames)
assert 'instantiateStreaming' not in page and 'wasmBinary' in page
wasm = (site / 'freedoom.wasm').read_bytes()
assert wasm[:8] == b'\x00asm\x01\x00\x00\x00'
def leb(data, pos):
    value, shift = 0, 0
    while True:
        byte = data[pos]; pos += 1; value |= (byte & 127) << shift
        if not byte & 128:
            return value, pos
        shift += 7
offset, memories = 8, []
while offset < len(wasm):
    section = wasm[offset]; length, start = leb(wasm, offset + 1)
    if section == 5:
        count, pos = leb(wasm, start)
        for _ in range(count):
            flags, pos = leb(wasm, pos); minimum, pos = leb(wasm, pos)
            maximum = None
            if flags & 1: maximum, pos = leb(wasm, pos)
            assert not flags & 2, 'Wasm memory must be unshared'
            memories.append({'flags': flags, 'minimum_pages': minimum, 'maximum_pages': maximum})
    offset = start + length
assert memories
assert any(r['name'].startswith('S7 Range-less') and r['pass'] and r['numbers']['type'] == 'text/plain' for r in proof['results'])
passed('G5 relative resources, prefix, wrong MIME and unshared memory hold', files=len(filenames), memories=memories, case_collisions=0, range_response=200, wasm_type='text/plain')
for name in ['GPL-2.0.txt', 'COPYING.txt', 'CREDITS.txt', 'SOURCE.txt', 'source.tar.gz', 'SDL2-LICENSE.txt', 'SDL2-mixer-LICENSE.txt', 'Emscripten-LICENSE.txt']:
    assert (site / 'legal' / name).is_file(), name
assert (site / 'legal/SOURCE.txt').read_bytes() == (repo / 'SOURCE.txt').read_bytes()
assert any(r['name'].startswith('G6 corner') and r['pass'] for r in proof['results'])
with tarfile.open(site / 'legal/source.tar.gz') as tar:
    for p in repo.rglob('*'):
        rel = p.relative_to(repo)
        if p.is_file() and not any(part in ['.git', 'node_modules', 'out', '__pycache__'] for part in rel.parts):
            assert tar.extractfile(str(rel)).read() == p.read_bytes(), 'Corresponding source differs: ' + str(rel)
passed('G6 licences, credits and exact corresponding source are reachable', source_bytes=(site / 'legal/source.tar.gz').stat().st_size, original_credits=True)

unicode_check = subprocess.run(['git', '-C', str(repo), 'grep', '-n', '-P', r'\x{2013}|\x{2014}'], capture_output=True, text=True)
assert unicode_check.returncode == 1 and not unicode_check.stdout
visible = (site / 'index.html').read_text() + (site / 'legal/index.html').read_text()
assert not re.search(r'\b(?:demo|simulated|simulation|preview|AI)\b', visible, re.I)
assert 'localStorage' in page and 'try {' in page and 'catch' in page
server = (repo / 'proof/server.py').read_text()
assert "('127.0.0.1', 0)" in server
recorded = set()
for log in (out / 'logs').glob('*.log'):
    recorded.update(int(pid) for pid in re.findall(r'(?:SERVER pid=|PID_STOPPED |BROWSER_PID )(\d+)', log.read_text(errors='replace')))
active = []
for pid in recorded:
    command = Path('/proc') / str(pid) / 'cmdline'
    if command.exists() and str(W).encode() in command.read_bytes():
        active.append(pid)
assert not active, active
for directory in Path('/proc').iterdir():
    if not directory.name.isdigit(): continue
    try:
        command = (directory / 'cmdline').read_bytes()
        if (b'chrome-headless-shell' in command or b'/chrome\x00' in command) and str(W / 'tmp').encode() in command:
            active.append(int(directory.name))
    except (FileNotFoundError, PermissionError):
        pass
assert not active, active
passed('G7 authored copy, loopback sockets and process lifecycle hold', unicode_matches=0, banned_visible_words=0, recorded_pids=sorted(recorded), active_owned_pids=active)
passed('G8 size and local load are measured', unpacked_bytes=sum((site / name).stat().st_size for name in filenames), files=len(filenames), first_load_ms=proof['metrics']['firstLoadMs'], samples=1, cache='fresh browser context, warm OS file cache')

if args.delivery:
    destination = Path('/mnt/d/q-inbox/doom-drag-1-out')
    for line in (destination / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert sha(destination / name) == digest, name
    subprocess.run(['git', '-C', str(repo), 'bundle', 'verify', str(destination / 'repo.bundle')], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    with tarfile.open(destination / 'site.tar.gz') as tar:
        assert sorted(m.name for m in tar.getmembers() if m.isfile()) == sorted(filenames)
        for name in filenames: assert tar.extractfile(name).read() == (site / name).read_bytes(), name
    for p in destination.rglob('*'):
        if p.is_file() and p.name not in ['site.tar.gz', 'repo.bundle']:
            assert p.stat().st_size <= (600 * 1024 if p.suffix == '.png' else 2 * 1024 * 1024)
    head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'main'], text=True).strip()
    assert head in (destination / 'REPORT-DOOM-DRAG-1.md').read_text()
    clean = json.loads((out / 'clean-check.json').read_text())
    assert clean['head'] == head and clean['fail'] == 0
    assert all(sha(site / name) == digest for name, digest in clean['inputs'].items())
    passed('G9 copied artifacts, hashes and bundle verify', head=head, site_tar_bytes=(destination / 'site.tar.gz').stat().st_size, site_tar_sha256=sha(destination / 'site.tar.gz'), bundle_bytes=(destination / 'repo.bundle').stat().st_size, destination=str(destination))

report = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': 'python3 scripts/audit.py' + (' --delivery' if args.delivery else ''), 'results': results, 'pass': len(results), 'fail': 0, 'skip': 0}
(out / ('acceptance-delivery.json' if args.delivery else 'acceptance.json')).write_text(json.dumps(report, indent=2) + '\n')
print('COUNTS PASS', len(results), 'FAIL 0 SKIP 0')
