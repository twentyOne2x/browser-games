from pathlib import Path
import hashlib
import json
import os
import sys

repo = Path(__file__).resolve().parent.parent
W = Path('/lanes2/gamework/doom-drag-1')
build = Path(os.environ.get('FREEDOOM_BUILD_DIR', str(W / 'build')))
site = Path(os.environ.get('FREEDOOM_SITE_DIR', str(W / 'site')))
paths = [repo / name for name in ['CMakeLists.txt', 'config.h', 'browser_bridge.c', 'scripts/build.sh', 'scripts/sanitize-runtime.mjs']]
paths += list((repo / 'upstream').rglob('*.c')) + list((repo / 'upstream').rglob('*.h'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = {str(p.relative_to(repo)): sha(p) for p in sorted(paths)}
outputs = {name: sha(site / name) for name in ['freedoom.js', 'freedoom.wasm']}
manifest = build / 'source-manifest.json'
if sys.argv[1] == 'record':
    manifest.write_text(json.dumps({'inputs': inputs, 'outputs': outputs}, indent=2) + '\n')
else:
    actual = json.loads(manifest.read_text())
    assert actual['inputs'] == inputs, 'Native or runtime source changed after build'
    assert actual['outputs'] == outputs, 'Built runtime differs from manifest'
print('PASS build manifest binds source and runtime', len(inputs), 'source files', outputs)
