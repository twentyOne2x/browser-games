from pathlib import Path
import argparse
import datetime
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

W = Path('/lanes2/gamework/doom-drag-1')
repo = Path(__file__).resolve().parent.parent
site = Path(os.environ.get('FREEDOOM_SITE_DIR', str(W / 'site')))
out = W / 'out'
destination = Path('/mnt/d/q-inbox/doom-drag-1-out')
parser = argparse.ArgumentParser()
parser.add_argument('checkpoint')
parser.add_argument('--prepare', action='store_true')
args = parser.parse_args()

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def add_file(tar, path, name):
    info = tar.gettarinfo(str(path), arcname=name)
    info.mtime = 0
    info.uid = info.gid = 0
    info.uname = info.gname = ''
    with path.open('rb') as content:
        tar.addfile(info, content)

def archive_source():
    with (site / 'legal/source.tar.gz').open('wb') as file:
        with gzip.GzipFile(fileobj=file, filename='', mode='wb', mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for p in sorted(repo.rglob('*')):
                    rel = p.relative_to(repo)
                    if p.is_file() and not any(part in ['.git', 'node_modules', 'out', '__pycache__'] for part in rel.parts):
                        add_file(tar, p, str(rel))
                for name, filename in [('sdl2-2.28.4.zip','sdl2.28.4.zip'),('sdl2_mixer-2.8.0.zip','sdl2_mixer.8.0.zip')]:
                    add_file(tar, W / 'cache/emscripten-ports' / filename, 'dependencies/' + name)

out.mkdir(exist_ok=True)
destination.mkdir(parents=True, exist_ok=True)
shutil.copyfile(repo / 'SOURCE.txt', site / 'legal/SOURCE.txt')
files = sorted(str(p.relative_to(site)) for p in site.rglob('*') if p.is_file())
if 'legal/source.tar.gz' not in files:
    files.append('legal/source.tar.gz')
(repo / 'site-files.txt').write_text('\n'.join(sorted(files)) + '\n')
archive_source()
if args.prepare:
    print('PASS corresponding source prepared', (site / 'legal/source.tar.gz').stat().st_size)
    raise SystemExit(0)

head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'main'], text=True).strip()
if args.checkpoint == 'C3':
    clean = json.loads((out / 'clean-check.json').read_text())
    assert clean['head'] == head and clean['pass'] == 1 and clean['fail'] == 0
    for name, digest in clean['inputs'].items():
        assert sha(site / name) == digest, 'Delivery differs from clean checkout: ' + name
    acceptance = json.loads((out / 'acceptance.json').read_text())
    assert acceptance['pass'] == 9 and acceptance['fail'] == 0
with (out / 'site.tar.gz').open('wb') as file:
    with gzip.GzipFile(fileobj=file, filename='', mode='wb', mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for p in sorted(site.rglob('*')):
                if p.is_file():
                    add_file(tar, p, str(p.relative_to(site)))
subprocess.run(['git', '-C', str(repo), 'bundle', 'create', str(out / 'repo.bundle'), 'main'], check=True)
subprocess.run(['git', '-C', str(repo), 'bundle', 'verify', str(out / 'repo.bundle')], check=True)
shutil.copytree(repo / 'proof/out', out / 'proof/out', dirs_exist_ok=True)
with tarfile.open(out / 'logs.tar.gz', 'w:gz') as tar:
    tar.add(out / 'logs', arcname='logs')
now = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
size = sum(p.stat().st_size for p in site.rglob('*') if p.is_file())
files = sum(1 for p in site.rglob('*') if p.is_file())
report_path = repo / 'proof/out/report.json'
proof = json.loads(report_path.read_text())
lines = [f"{'PASS' if item['pass'] else 'FAIL'} {item['name']} {json.dumps(item['numbers'], separators=(',', ':'))}" for item in proof['results']]
patches = json.loads((repo / 'patches/list.json').read_text()) if (repo / 'patches/list.json').exists() else []
purposes = {'d_loop.c': 'Remove external transport', 'd_main.c': 'Expose existing transition readiness', 'g_game.c': 'Keep fullscreen inert and expose weapon selection', 'm_menu.c': 'Return to START and keep information inert', 'p_pspr.c': 'Count accepted fire', 'doomtype.h': 'Keep original boolean ABI', 'i_video.c': 'Page-fed input, rendered frames, resize and title', 'm_controls.c': 'WASD movement and strafe', 'net_dedicated.c': 'Remove external transport', 'net_query.c': 'Remove external resolution', 'net_server.c': 'Remove external transport'}
patch_rows = '\n'.join(f"| {item['file']} | {purposes[Path(item['file']).name]} | {item['added']} | {item['removed']} |" for item in patches)
extensions = {'CMakeLists.txt': 'Build existing source inventory with pinned SDL', 'config.h': 'Configure the original engine', 'browser_bridge.c': 'Post engine input and read authoritative state', 'web/index.html': 'Name, START and controls', 'web/game.js': 'Static loading, drag, touch and lifecycle', 'web/style.css': 'Responsive letterbox and touch layout', 'scripts/sanitize-runtime.mjs': 'Make generated browser permission helpers inert'}
extension_rows = '\n'.join(f"| {name} | {purpose} | {len((repo / name).read_text().splitlines())} |" for name, purpose in extensions.items())
first_load = proof.get('metrics', {}).get('firstLoadMs', 'not measured at C1')
mutation = json.loads((repo / 'proof/out/mutations.json').read_text()) if (repo / 'proof/out/mutations.json').exists() else None
mutation_lines = '\n'.join('PASS ' + item['name'] + ' ' + json.dumps(item) for item in mutation['checks']) if mutation else 'Mutation checks pending.'
acceptance = json.loads((out / 'acceptance.json').read_text()) if (out / 'acceptance.json').exists() else None
acceptance_lines = '\n'.join('PASS ' + item['name'] + ' ' + json.dumps(item['numbers'], separators=(',', ':')) for item in acceptance['results']) if acceptance else 'Acceptance audit pending.'
clean = json.loads((out / 'clean-check.json').read_text()) if (out / 'clean-check.json').exists() else None
clean_line = 'PASS G3 clean bundle checkout ' + json.dumps(clean, separators=(',', ':')) if clean else 'Clean bundle checkout pending.'
delivery_line = 'PASS G9 delivery files and bundle verify ' + json.dumps({'head': head, 'site_tar_bytes': (out / 'site.tar.gz').stat().st_size, 'site_tar_sha256': sha(out / 'site.tar.gz'), 'bundle_bytes': (out / 'repo.bundle').stat().st_size, 'destination': str(destination)}, separators=(',', ':'))
status = 'READY' if args.checkpoint == 'C3' else 'PARTIAL'
next_work = {'C1': 'Touch controls, S0 to S7, mutation checks, final legal/source checks, layout and load measurements.', 'C2': 'C3 polish and final acceptance audit.', 'C3': 'Supervisor uploads the static folder and uses the supplied iframe.'}[args.checkpoint]
report = f'''NEW. EXTEND cloudflare/doom-wasm@65e0d3ae2ffa604155eebd96ed40da6567bd08f4 for hold and drag input.

Run Freedoom Phase 1 in a static folder inside a different-origin iframe with only allow-scripts and allow-same-origin.
Keep the original open source engine and free WAD. Change input and page integration only.
Done means real headless start, movement, drag, fire and touch evidence, no lock calls, and a rerunnable local bundle.

STATUS: {status}, {args.checkpoint}, {now}, main {head}.
Next: {next_work}

## Port and provenance

The lead port linked at 2026-10-09T15:31:16Z, after starting the choice window at 2026-10-09T15:19:52Z. The pinned upstream CMake references missing files. A local CMake wrapper builds its existing Doom sources. Emscripten 3.1.64 is pinned through SDK commit 35ff8a6d150541276abbc6bae512ca90bcfbe220. The engine is GPL-2.0; the SDK is MIT. The upstream tree and licence notices are retained. DECISION.md, SOURCE.txt and the logs give the build evidence.

Modern SDK headers exposed an inconsistent boolean layout in the upstream C files. doomtype.h keeps the original four byte layout. A compile assertion guards the reader. The browser checks validate ammo use and the level start. Earlier failing logs remain in logs.tar.gz.

The readiness reader also checks the engine's existing opening transition flag, pending game action and first rendered frame. This prevents readiness from preceding input processing during the native screen transition.

## Data

{(repo / 'DATA.md').read_text().replace('# Data provenance', '')}

Freedoom terms: "Redistribution and use in source and binary forms, with or without modification, are permitted" subject to retaining the copyright, conditions and disclaimer in COPYING.txt. COPYING.txt and the original credits are shipped in legal/.

## Patches

SOURCE.txt gives the purpose of every patch. patches/browser.patch applies to the pinned upstream snapshot.

| Upstream file | Purpose | Added lines | Removed lines |
| --- | --- | ---: | ---: |
{patch_rows}

| Added integration file | Purpose | Lines |
| --- | --- | ---: |
{extension_rows}

## Controls

| Input | Result |
| --- | --- |
| Primary hold and horizontal drag | Turn clockwise for rightward movement |
| Primary click under 6 px and 250 ms | One fire pulse |
| W, S, Up, Down | Forward and back |
| A, D | Strafe left and right |
| Left, Right | Turn left and right |
| Right mouse, F, Control | Fire |
| E, Space | Use |
| Digits | Select weapon |
| Wheel | Next or previous weapon |
| Escape | Engine menu |
| Quit menu entry | Return to START |
| [ and ] | Sensitivity decrease and increase |
| Enter or START | New normal-skill game on E1M1 |
| First touch, touch=1, T | Show touch controls |
| Touch stick | Forward, back and strafe |
| Touch right half | Look, including letterbox areas |
| Touch FIRE, USE, NEXT WEAPON, MENU | Corresponding engine actions |
| Blur or hidden | Release input, suspend audio, show PAUSED |

Default sensitivity is 0.3 degrees per CSS pixel. Mouse event units = delta_x * sensitivity * 65536 / (360 * 8). Doom multiplies those units by 8 in its tic command. Rightward drag decreases engine yaw; yaw increases counterclockwise from east. A 400 px drag turns about 120 degrees. Doom pitch remains zero. Fractional event units carry to the next tic. Sensitivity storage is in try/catch with an in-memory fallback.

## Proof

Command: bash proof/run.sh c1 for the initial checkpoint. The complete command is bash proof/run.sh, including healthy mutation controls, both detected defects and byte restoration. Raw command UTC stamps, exit values and pass/fail/skip counts are in logs.tar.gz.

```text
{chr(10).join(lines)}
{mutation_lines}
```

The acceptance commands are bash scripts/ci/fast, python3 scripts/audit.py, bash scripts/verify-clean.sh and python3 scripts/audit.py --delivery. The clean check uses a fresh checkout of main from repo.bundle, the pinned SDK, the verified WAD, and a fresh browser context. It runs the complete proof and mutations again. The delivered runtime files are selected from that passing build.

```text
{acceptance_lines}
{clean_line}
{delivery_line}
```

## Size

site.tar.gz: {(out / 'site.tar.gz').stat().st_size} bytes, SHA256 {sha(out / 'site.tar.gz')}.
Unpacked site: {size} bytes. Files: {files}.
First load to START on Q loopback: {first_load} ms, one sample with a fresh browser context and warm OS file cache. The timer ends after the verified WAD is written to the engine filesystem and wasm initialization enables START. HTTP errors and failed requests are zero in the accepted run. No speed comparison or public network load time is claimed.

## Known limits

{next_work}
The pinned engine reports a Freedoom cheat compatibility warning. SDL2 uses the browser ScriptProcessor audio API and Chromium reports its deprecation as a warning. Both are original runtime warnings, with no console error in healthy gameplay runs. No frame rate claim is made. Music is disabled; sound effects are enabled. S8 is optional and was not run. Blur and visibility handlers are exercised with forced lifecycle events in headless Chromium. Real phone hardware and the final hosted ChatGPT embed were not exercised on Q.

## Hosting

{(repo / 'README-HOST.md').read_text().replace('# Host Freedoom', '')}
'''
(out / 'REPORT-DOOM-DRAG-1.md').write_text(report)
(out / 'PROGRESS.md').write_text(f'UTC: {now}\nCheckpoint: {args.checkpoint}\nHead: {head}\nsite.tar.gz SHA256: {sha(out / "site.tar.gz")}\nNext: {next_work}\n')
deliver = ['site.tar.gz', 'repo.bundle', 'logs.tar.gz', 'PROGRESS.md', 'REPORT-DOOM-DRAG-1.md']
(out / 'SHA256SUMS').write_text(''.join(f'{sha(out / name)}  {name}\n' for name in deliver))
for name in deliver + ['SHA256SUMS']:
    p = out / name
    assert name in ['site.tar.gz', 'repo.bundle'] or p.stat().st_size <= 2 * 1024 * 1024
    shutil.copyfile(p, destination / name)
shutil.copytree(out / 'proof', destination / 'proof', dirs_exist_ok=True)
for p in (destination / 'proof').rglob('*'):
    if p.is_file():
        assert p.stat().st_size <= (600 * 1024 if p.suffix == '.png' else 2 * 1024 * 1024)
for name in deliver:
    assert sha(destination / name) == sha(out / name), 'Copy differs: ' + name
print('DELIVERY', json.dumps({'checkpoint': args.checkpoint, 'utc': now, 'head': head, 'site_bytes': (out / 'site.tar.gz').stat().st_size, 'unpacked_bytes': size, 'files': files, 'sha256': sha(out / 'site.tar.gz'), 'output': str(destination)}))
