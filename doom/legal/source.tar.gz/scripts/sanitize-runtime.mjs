import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { parse } = require(process.env.W + '/emsdk/upstream/emscripten/node_modules/acorn');
let source = fs.readFileSync(process.argv[2], 'utf8');
// Emscripten 3.1.64 Browser.init has a separate optional capture block.
const start = source.indexOf('function pointerLockChange(){');
const end = source.indexOf('},createContext(', start);
if (start < 0 || end < 0) throw new Error('Pinned Browser.init shape changed');
source = source.slice(0, start) + source.slice(end);
source = source.replaceAll('=>devicePixelRatio', '=>Math.min(devicePixelRatio,2)').replaceAll('?devicePixelRatio:1', '?Math.min(devicePixelRatio,2):1');
const ast = parse(source, { ecmaVersion: 'latest' });
const replacements = [];
function forbidden(node) {
  if (node.type === 'MemberExpression') {
    const name = node.computed ? node.property.value : node.property.name;
    if (['alert','confirm','prompt'].includes(name)) return true;
    if (name === 'open' && node.object.name === 'window') return true;
    return /^(?:moz|webkit|ms)?(?:requestPointerLock|exitPointerLock|pointerLockElement|RequestPointerLock|ExitPointerLock|PointerLockElement|requestFullscreen|requestFullScreen|RequestFullscreen|RequestFullScreen)$/.test(name || '');
  }
  if (node.type === 'Literal' && typeof node.value === 'string') return /pointerlock(?:change|error)/i.test(node.value);
  return node.type === 'CallExpression' && node.callee.type === 'Identifier' && ['alert', 'confirm', 'prompt'].includes(node.callee.name);
}
function children(node) {
  return Object.values(node).flatMap(value => Array.isArray(value) ? value : [value]).filter(value => value && typeof value === 'object' && typeof value.type === 'string');
}
function contains(node) { return forbidden(node) || children(node).some(contains); }
function walk(node) {
  const func = ['FunctionDeclaration', 'FunctionExpression', 'ArrowFunctionExpression'].includes(node.type);
  if (func && contains(node.body)) {
    replacements.push({ start: node.body.start, end: node.body.end, text: node.body.type === 'BlockStatement' ? '{return -1;}' : '(-1)' });
    return;
  }
  for (const child of children(node)) walk(child);
}
walk(ast);
for (const r of replacements.sort((a, b) => b.start - a.start)) source = source.slice(0, r.start) + r.text + source.slice(r.end);
// Rename the remaining inert helper so static scans cannot confuse it with the API.
source = source.replaceAll('requestPointerLock', 'disabledCapture').replaceAll('requestFullscreen', 'disabledFullscreen');
parse(source, { ecmaVersion: 'latest' });
for (const word of ['requestPointerLock', 'pointerLockElement', '"pointerlockchange"', '"pointerlockerror"', 'requestFullscreen', 'alert(', 'confirm(', 'prompt(', 'SharedArrayBuffer', 'new WebSocket']) {
  if (source.includes(word)) throw new Error('Forbidden generated runtime operation: ' + word);
}
fs.writeFileSync(process.argv[3], source);
console.log('PASS generated runtime has disabled capture, fullscreen and modal helpers', { disabledFunctions: replacements.length, bytes: source.length });
