from pathlib import Path
import difflib
import json
import subprocess
import sys

repo = Path(__file__).resolve().parent.parent
pristine = Path('/lanes2/gamework/doom-drag-1/upstream')
pin = '65e0d3ae2ffa604155eebd96ed40da6567bd08f4'
assert subprocess.check_output(['git', '-C', str(pristine), 'rev-parse', 'HEAD'], text=True).strip() == pin
assert not subprocess.check_output(['git', '-C', str(pristine), 'status', '--porcelain'], text=True)
names = subprocess.check_output(['git', '-C', str(pristine), 'ls-tree', '-r', '--name-only', 'HEAD'], text=True).splitlines()
assert sorted(names) == sorted(str(p.relative_to(repo / 'upstream')) for p in (repo / 'upstream').rglob('*') if p.is_file())
tracked = subprocess.check_output(['git', '-C', str(repo), 'ls-files', 'upstream'], text=True).splitlines()
assert sorted('upstream/' + name for name in names) == sorted(tracked), 'Bundle must retain every pinned upstream file, including paths matched by upstream ignore rules'
patch, rows = [], []
for name in names:
    a, b = pristine / name, repo / 'upstream' / name
    if a.read_bytes() == b.read_bytes():
        continue
    lines = list(difflib.unified_diff(a.read_text().splitlines(keepends=True), b.read_text().splitlines(keepends=True), fromfile='a/upstream/' + name, tofile='b/upstream/' + name))
    patch.extend(lines)
    rows.append({'file': 'upstream/' + name, 'added': sum(s.startswith('+') and not s.startswith('+++') for s in lines), 'removed': sum(s.startswith('-') and not s.startswith('---') for s in lines)})
text = ''.join(patch)
if sys.argv[1] == 'record':
    (repo / 'patches/browser.patch').write_text(text)
    (repo / 'patches/list.json').write_text(json.dumps(rows, indent=2) + '\n')
else:
    assert (repo / 'patches/browser.patch').read_text() == text, 'Patch does not match changed upstream files'
    assert json.loads((repo / 'patches/list.json').read_text()) == rows
print('PASS G0 upstream inventory and exact patch', json.dumps({'pin': pin, 'files': len(names), 'changed': len(rows), 'otherwise_unchanged': len(names) - len(rows)}))
