#!/bin/bash
export W=/lanes2/gamework/doom-drag-1 TMPDIR=/lanes2/gamework/doom-drag-1/tmp npm_config_cache=/lanes2/gamework/doom-drag-1/npm-cache PIP_CACHE_DIR=/lanes2/gamework/doom-drag-1/pip-cache XDG_CACHE_HOME=/lanes2/gamework/doom-drag-1/cache
set -euo pipefail
repo=$(cd "$(dirname "$0")/.." && pwd)
source "$W/emsdk/emsdk_env.sh" >/dev/null 2>&1
export EM_CACHE="$W/cache/emscripten" EM_PORTS="$W/cache/emscripten-ports"
build_dir=${FREEDOOM_BUILD_DIR:-$W/build}
site_dir=${FREEDOOM_SITE_DIR:-$W/site}
emcmake cmake -S "$repo" -B "$build_dir" -DCMAKE_BUILD_TYPE=Release
cmake --build "$build_dir" -j4
mkdir -p "$site_dir/legal"
cp "$repo/web/"* "$site_dir/"
cp "$repo/legal/"* "$site_dir/legal/"
cp "$repo/SOURCE.txt" "$site_dir/legal/"
cp "$W/downloads/freedoom1.wad" "$site_dir/"
cp "$build_dir/freedoom.wasm" "$site_dir/"
node "$repo/scripts/sanitize-runtime.mjs" "$build_dir/freedoom.js" "$site_dir/freedoom.js"
node --check "$site_dir/game.js"
python3 "$repo/scripts/build-manifest.py" record
python3 "$repo/scripts/package.py" BUILD --prepare
