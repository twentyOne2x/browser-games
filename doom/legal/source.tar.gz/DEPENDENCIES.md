# Build dependencies

Emscripten 3.1.64: MIT and University of Illinois/NCSA licences, pinned SDK as recorded in DECISION.md. Its WebAssembly toolchain SHA256 is c39de24beca60fd580f6dff0eca0e275016042a30234588b19eda82397e299f3, 301536980 bytes. SDK Node 24.19.0 is 31633904 bytes, SHA256 14b342e71204f811bde6153be8e04b62aef63c236fef92b55f9c83154b409647.

SDL2 2.28.4 and SDL2_mixer 2.8.0: zlib licences. Source archives are fetched from the pinned GitHub URLs in the Emscripten 3.1.64 port recipes. The build disables mixer file formats and uses only WAD sound effects. The first compile fetched the default Ogg/Vorbis recipes before that setting was disabled; they are excluded from the shipped link. Download hashes are printed in downloads.log.

Playwright 1.63.0: Apache-2.0, npm package-lock.json pins integrity and dependencies. The matching Chromium revision is 1243. No browser was downloaded.

The corresponding source archive also contains the pinned SDL2 and SDL2_mixer source ZIPs. Their original licence texts and the Emscripten licence are shipped in legal/.
