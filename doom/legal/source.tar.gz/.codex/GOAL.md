# Goal

Deliver DOOM-DRAG-1 as a static Freedoom Phase 1 browser folder in site/, using pinned cloudflare/doom-wasm and Emscripten. Hold primary and drag turns without any pointer lock call. Keyboard and touch movement, use and fire work in a different-origin iframe with sandbox allow-scripts allow-same-origin.

# Done

S0 through S7 and both mutation controls pass with real engine state. A clean checkout from the local bundle builds and reruns the proof. G0 through G9 hold. Source, licences, verified free data provenance, screenshots and report are delivered to /mnt/d/q-inbox/doom-drag-1-out/.

# Authorization and scope

Only work under /lanes2/gamework/doom-drag-1, plus the specified outputs folder. Keep all tools and caches under that folder within 8 GiB. Commit locally on main with no remote and no push. Keep the attn launch checkout unchanged. Use only the named free release data and allowed pinned dependency downloads. No payment code, accounts, analytics, network play, pointer lock, fullscreen, modal dialogs, shared memory or service workers. No Computer Use.
