#include <math.h>
#include <stdio.h>
#include <emscripten.h>
#include "doom/doomdef.h"
#include "doom/doomstat.h"
#include "doom/d_player.h"
#include "doom/d_items.h"
#include "doom/g_game.h"
#include "doom/d_main.h"
#include "doom/m_menu.h"
#include "d_event.h"
#include "doom/s_sound.h"
extern int mousex, mousey;
extern void M_ClearMenus(void);
_Static_assert(sizeof(boolean) == 4, "Engine boolean ABI must remain four bytes");
unsigned int browser_frame, browser_shots;
static double drag_units;
static int moving_keys[256];

extern boolean paused;
extern boolean browser_wiping;
extern boolean menuactive;
EMSCRIPTEN_KEEPALIVE int Browser_MenuActive(void) { return menuactive; }
EMSCRIPTEN_KEEPALIVE void Browser_Key(int key, int down) {
    event_t ev = {0};
    ev.type = down ? ev_keydown : ev_keyup;
    ev.data1 = key; ev.data2 = key; ev.data3 = key;
    D_PostEvent(&ev);
    if (key == 'w' || key == 'a' || key == 's' || key == 'd' || key == 173 || key == 175) {
        moving_keys[key] = down;
        if (!down && !moving_keys['w'] && !moving_keys['a'] && !moving_keys['s'] &&
            !moving_keys['d'] && !moving_keys[173] && !moving_keys[175]) {
            mobj_t *m = players[consoleplayer].mo;
            if (m) m->momx = m->momy = 0;
        }
    }
}
EMSCRIPTEN_KEEPALIVE void Browser_Drag(double pixels, double sensitivity) {
    if (!paused) drag_units += pixels * sensitivity * 65536.0 / (360.0 * 8.0);
}
EMSCRIPTEN_KEEPALIVE void Browser_ReadMouse(void) {
    int units = (int)drag_units;
    event_t ev = {0};
    drag_units -= units;
    if (units) {
        ev.type = ev_mouse; ev.data2 = units;
        D_PostEvent(&ev);
    }
}

EMSCRIPTEN_KEEPALIVE void Browser_Pause(int value) {
    paused = value != 0;
    drag_units = 0;
    mousex = mousey = 0;
    if (paused) S_PauseSound(); else S_ResumeSound();
}
EMSCRIPTEN_KEEPALIVE void Browser_NewGame(void) {
    browser_shots = 0; paused = false; M_ClearMenus();
    G_DeferedInitNew(sk_medium, 1, 1);
}
EMSCRIPTEN_KEEPALIVE const char *Browser_State(void) {
    static char state[768];
    player_t *p = &players[consoleplayer];
    mobj_t *m = p->mo;
    int ammo_type = weaponinfo[p->readyweapon].ammo;
    char ammo[32];
    if (ammo_type == am_noammo) snprintf(ammo,sizeof ammo,"null");
    else snprintf(ammo,sizeof ammo,"%d",p->ammo[ammo_type]);
    snprintf(state,sizeof state,
      "{\"ready\":%s,\"map\":\"E%dM%d\",\"frame\":%u,\"pos\":[%.5f,%.5f,%.5f],\"yaw\":%.6f,\"pitch\":0,\"health\":%d,\"ammo\":%s,\"shots\":%u,\"weapon_frame\":%ld}",
      gamestate == GS_LEVEL && gameaction == ga_nothing && m && !browser_wiping && browser_frame > 0 ? "true":"false", gameepisode,gamemap,browser_frame,
      m?m->x/65536.0:0,m?m->y/65536.0:0,m?m->z/65536.0:0,
      m?m->angle*(360.0/4294967296.0):0,p->health,ammo,browser_shots,
      p->psprites[ps_weapon].state ? (long)p->psprites[ps_weapon].state : 0L);
    return state;
}
