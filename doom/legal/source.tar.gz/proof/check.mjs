import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { once } from 'node:events';
import { chromium } from 'playwright';
const W = process.env.W;
const root = process.cwd();
const output = path.join(root, 'proof/out');
fs.mkdirSync(output, { recursive: true });
const servers = [], results = [];
let browser;
function invariant(name, pass, numbers) {
  results.push({ name, pass, numbers });
  console.log(`${pass ? 'PASS' : 'FAIL'} ${name} ${JSON.stringify(numbers)}`);
  if (!pass) throw new Error(name);
}
async function server(dir, portA = 0) {
  const args = [path.join(root, 'proof/server.py'), '--root', dir, '--proof', path.join(root, 'proof'), '--port-a', String(portA)];
  const child = spawn('python3', args, { stdio: ['ignore', 'pipe', 'pipe'] });
  servers.push(child);
  child.stderr.pipe(fs.createWriteStream(path.join(W, 'out/logs', `server-${child.pid}.log`)));
  const reader = createInterface({ input: child.stdout });
  const [line] = await once(reader, 'line');
  const { port } = JSON.parse(line);
  console.log(`SERVER pid=${child.pid} bind=127.0.0.1 port=${port} range=false wasm_type=text/plain`);
  return port;
}
const state = frame => frame.evaluate(() => window.__proof.state());
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const yawDelta = (a, b) => ((b - a + 540) % 360) - 180;
try {
  const portA = await server(process.env.SITE_DIR || path.join(W, 'site'));
  const portB = await server(path.join(root, 'proof'), portA);
  const args = ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage', '--no-sandbox'];
  console.log('BROWSER playwright=1.63.0 chromium_revision=1243 flags=' + JSON.stringify(args));
  browser = await chromium.launch({ headless: true, args });
  const context = await browser.newContext({ viewport: { width: 1000, height: 640 } });
  await context.addInitScript({ path: path.join(root, 'proof/init.js') });
  const page = await context.newPage();
  const errors = [], failed = [], outside = [];
  page.on('pageerror', e => { errors.push(e.message); console.log('BROWSER_ERROR',e.message); });
  page.on('console', m => { if (m.type() === 'error') { errors.push(m.text()); console.log('CONSOLE_ERROR',m.text()); } if (m.type() === 'warning') console.log('CONSOLE_WARNING',m.text()); });
  page.on('requestfailed', r => failed.push(r.url() + ':' + r.failure()?.errorText));
  const origins = [`http://localhost:${portA}`, `http://127.0.0.1:${portB}`];
  page.on('request', r => { if (!origins.includes(new URL(r.url()).origin)) outside.push(r.url()); });
  await page.goto(`http://127.0.0.1:${portB}/outer.html`);
  console.log('IFRAME', await page.locator('#g').evaluate(e => Object.fromEntries([...e.attributes].map(a => [a.name, a.value]))));
  const frame = page.frames().find(f => f.url().startsWith(origins[0]));
  await frame.waitForFunction(() => !document.getElementById('start').disabled, null, { timeout: 60000 });
  await frame.locator('#start').click();
  await frame.waitForFunction(() => window.__proof.state().ready, null, { timeout: 60000 });
  await wait(1000);
  const initial = await state(frame); await wait(300); const active = await state(frame);
  invariant('C1 start and engine frames advance', active.ready && active.map === 'E1M1' && active.frame > initial.frame, active);
  await page.keyboard.down('w'); await wait(1000); await page.keyboard.up('w'); await wait(500);
  const moved = await state(frame);
  const distance = Math.hypot(moved.pos[0] - active.pos[0], moved.pos[1] - active.pos[1]);
  invariant('C1 WASD enters engine movement', distance > 30, { distance, before: active.pos, after: moved.pos });
  const box = await frame.locator('#canvas').boundingBox(); const x = box.x + box.width / 2, y = box.y + box.height / 2;
  await page.mouse.move(x, y); const beforeDrag = await state(frame);
  await page.mouse.down(); await page.mouse.move(x + 300, y, { steps: 10 }); await page.mouse.up(); await wait(400);
  const turned = await state(frame); const delta = yawDelta(beforeDrag.yaw, turned.yaw);
  invariant('C1 primary drag turns engine yaw', delta < -67.5 && delta > -112.5, { delta, expected: -90 });
  const beforeFire = await state(frame);
  await page.keyboard.down('f'); await wait(180); await page.keyboard.up('f'); await wait(500);
  const fired = await state(frame);
  invariant('C1 fire is accepted with ammunition use', fired.shots > beforeFire.shots && fired.ammo < beforeFire.ammo, { before: beforeFire, after: fired });
  const locks = await frame.evaluate(() => ({ calls: window.__lockCalls, events: window.__plLog }));
  console.log('ERRORS', JSON.stringify({ errors, failed, outside }));
  invariant('C1 no lock and only local requests', locks.calls === 0 && locks.events.length === 0 && !errors.length && !failed.length && !outside.length, locks);
  await page.screenshot({ path: path.join(output, 'c1.png') });
} catch (e) {
  console.error('PROOF_ERROR', e.stack);
  if (!results.some(r => !r.pass)) results.push({ name: 'browser execution completes', pass: false, numbers: { error: e.message } });
  process.exitCode = 1;
} finally {
  if (browser) await browser.close();
  for (const child of servers) {
    child.kill('SIGTERM'); await once(child, 'exit');
    console.log('PID_STOPPED', child.pid);
  }
  fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify({ results, pass: results.filter(r => r.pass).length, fail: results.filter(r => !r.pass).length, skip: 0 }, null, 2));
  console.log(`COUNTS PASS ${results.filter(r => r.pass).length} FAIL ${results.filter(r => !r.pass).length} SKIP 0`);
}
