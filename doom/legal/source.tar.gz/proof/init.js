(() => {
  window.__plLog = [];
  window.__inputLog = [];
  for (const name of ['pointerdown','pointerup','pointermove','gotpointercapture','lostpointercapture','blur','focus','visibilitychange']) {
    addEventListener(name, event => {
      window.__inputLog.push({type:name,target:event.target.id || event.target.nodeName || 'window',x:event.clientX,y:event.clientY,button:event.button,trusted:event.isTrusted});
      if(window.__inputLog.length>40)window.__inputLog.shift();
    },true);
  }
  window.__lockCalls = 0;
  const original = Element.prototype.requestPointerLock;
  Element.prototype.requestPointerLock = function (...args) {
    ++window.__lockCalls;
    return original.apply(this, args);
  };
  const originalExit = document.exitPointerLock;
  document.exitPointerLock = function (...args) {
    ++window.__lockCalls;
    return originalExit.apply(this, args);
  };
  for (const name of ['pointerlockchange', 'pointerlockerror']) {
    document.addEventListener(name, () => window.__plLog.push(name));
  }
})();
