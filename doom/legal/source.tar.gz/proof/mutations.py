from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

repo = Path(__file__).resolve().parent.parent
W = Path('/lanes2/gamework/doom-drag-1')
target = Path(os.environ.get('SITE_DIR',str(W / 'site'))) / 'game.js'
original = target.read_bytes()
digest = lambda b: hashlib.sha256(b).hexdigest()
checks = []

def run(mode, label):
    print('MUTATION_COMMAND', label, 'UTC_START', datetime.datetime.now(datetime.timezone.utc).isoformat(), 'bash proof/run.sh', mode, flush=True)
    result = subprocess.run(['bash', 'proof/run.sh', mode], cwd=repo, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (W / 'out/logs' / (label + '.log')).write_text(result.stdout)
    report = json.loads((repo / 'proof/out' / ('report-' + mode + '.json')).read_text())
    print('MUTATION_COMMAND', label, 'EXIT', result.returncode, 'PASS', report['pass'], 'FAIL', report['fail'], 'SKIP', report['skip'], flush=True)
    for line in result.stdout.splitlines():
        if line.startswith(('PASS S3 primary', 'FAIL ', 'PASS S5 ', 'PID_STOPPED')):
            print(line, flush=True)
    return result.returncode, report

try:
    assert target.read_bytes() == original
    code, control = run('mutation-drag', 'drag-healthy-control')
    assert code == 0 and control['fail'] == 0
    checks.append({'name': 'healthy drag control', 'pass': True, 'input_sha256': digest(original)})
    text = original.decode()
    needle = 'Module._Browser_Drag(dx, sensitivity);'
    assert text.count(needle) == 1
    target.write_text(text.replace(needle, 'void dx;'))
    code, report = run('mutation-drag', 'drag-disabled')
    failures = [r for r in report['results'] if not r['pass']]
    assert code != 0 and len(failures) == 1 and failures[0]['name'] == 'S3 primary drag has the configured yaw'
    assert abs(failures[0]['numbers']['delta']) < .05
    checks.append({'name': 'S3 detects disabled drag', 'pass': True, 'observed': failures[0]})
    print('PASS MUTATION disabled drag is detected', json.dumps(failures[0]['numbers']), flush=True)
    target.write_bytes(original)
    assert target.read_bytes() == original
    code, control = run('mutation-lock', 'lock-healthy-control')
    assert code == 0 and control['fail'] == 0
    checks.append({'name': 'healthy lock control', 'pass': True, 'input_sha256': digest(original)})
    target.write_bytes(original + b"\ndocument.getElementById('start').addEventListener('click', () => { try { const result = document.getElementById('canvas').requestPointerLock(); if (result && result.catch) result.catch(() => {}); } catch {} });\n")
    code, report = run('mutation-lock', 'lock-added')
    failures = [r for r in report['results'] if not r['pass']]
    assert code != 0 and len(failures) == 1 and failures[0]['name'] == 'S5 lock counters and browser diagnostics remain clear'
    assert failures[0]['numbers']['lock_calls'] > 0
    checks.append({'name': 'S5 detects added lock request', 'pass': True, 'observed': failures[0]})
    print('PASS MUTATION lock request is detected', json.dumps(failures[0]['numbers']), flush=True)
finally:
    target.write_bytes(original)
    assert target.read_bytes() == original
    print('PASS MUTATION restored byte for byte', 'before', digest(original), 'after', digest(target.read_bytes()), flush=True)

checks.append({'name': 'byte for byte restoration', 'pass': True, 'sha256': digest(original)})
(repo / 'proof/out/mutations.json').write_text(json.dumps({'checks': checks, 'pass': len(checks), 'fail': 0, 'skip': 0, 'test_sha256': digest(Path(__file__).read_bytes())}, indent=2))
print('COUNTS PASS', len(checks), 'FAIL 0 SKIP 0')
