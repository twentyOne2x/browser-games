#!/bin/bash
export W=/lanes2/gamework/doom-drag-1 TMPDIR=/lanes2/gamework/doom-drag-1/tmp npm_config_cache=/lanes2/gamework/doom-drag-1/npm-cache PIP_CACHE_DIR=/lanes2/gamework/doom-drag-1/pip-cache XDG_CACHE_HOME=/lanes2/gamework/doom-drag-1/cache
set -euo pipefail
cd "$(dirname "$0")/.."
export PLAYWRIGHT_BROWSERS_PATH=/home/builder/.cache/ms-playwright
mkdir -p "$W/out/logs" proof/out
printf 'PROOF UTC_START %s COMMAND bash proof/run.sh %s\n' "$(date -u +%FT%TZ)" "$*"
set +e
if [ "${1:-full}" = c1 ]; then script=proof/check.mjs; else script=proof/full.mjs; fi
node "$script" "$@" 2>&1 | tee "$W/out/logs/proof-${1:-full}.log"
result=${PIPESTATUS[0]}
set -e
printf 'PROOF UTC_END %s EXIT %s\n' "$(date -u +%FT%TZ)" "$result"
if [ "$result" -eq 0 ] && [ "${1:-full}" = full ]; then
  python3 proof/mutations.py
fi
exit "$result"
