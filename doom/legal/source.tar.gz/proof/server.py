import argparse
import http.server
import json
from pathlib import Path
import signal
from urllib.parse import urlparse, parse_qs

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--proof', required=True)
p.add_argument('--port-a', type=int, default=0)
a = p.parse_args()
root = Path(a.root).resolve()
proof = Path(a.proof).resolve()

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(root), **kwargs)

    def do_GET(self):
        path = self.path.split('?')[0]
        if path.endswith('/outer.html'):
            content = (proof / 'outer.html').read_text().replace('PORT_A', str(a.port_a))
            query = parse_qs(urlparse(self.path).query)
            if query.get('control') == ['1']:
                content = content.replace('index.html?proof=1', 'plcheck.html')
            elif query.get('prefix') == ['1']:
                content = content.replace('/index.html?proof=1', '/nested/freedoom/index.html?proof=1')
            if query.get('mobile') == ['1']:
                width = int(query['width'][0])
                height = int(query['height'][0])
                content = content.replace('index.html?proof=1', 'index.html?proof=1&touch=1')
                content = content.replace('width="960"', f'width="{width}"')
                content = content.replace('height="600"', f'height="{height}" style="border:0"')
            data = content.encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif path.endswith('/plcheck.html'):
            data = (proof / 'plcheck.html').read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif path == '/favicon.ico':
            self.send_response(204)
            self.end_headers()
        else:
            if path.startswith('/nested/freedoom/'):
                self.path = self.path[len('/nested/freedoom'):]
            super().do_GET()

    def guess_type(self, path):
        if path.endswith('.wasm'):
            return 'text/plain'
        return super().guess_type(path)

server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
server.daemon_threads = True
print(json.dumps({'port': server.server_port}), flush=True)
server.serve_forever()
