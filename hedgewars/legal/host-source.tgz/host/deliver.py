#!/usr/bin/env python3
"""Create the fix-round delivery from an exact-head passing proof on Mac or Linux."""
import gzip
import json
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BASE = '285f65d8b2ca8e8fef737aacb112f1a273e706f0'
TICKET = 'PLAY-HOST-HEDGEWARS-2'
OUT = Path(sys.argv[1] if len(sys.argv)>1 else 'build/delivery/out').resolve()
OUT.mkdir(parents=True,exist_ok=True)
CACHE = ROOT/'build/delivery'; CACHE.mkdir(parents=True,exist_ok=True)
def run(args): return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def sha(path): return run(['sha256sum',str(path)]).split()[0]
def archive(target,paths):
    def stable(info):
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ''
        info.mode = 0o755 if info.isdir() or info.mode & 0o111 else 0o644
        info.pax_headers = {}
        return info
    members = set()
    for name in paths:
        path = ROOT/name; members.add(path)
        if path.is_dir(): members.update(path.rglob('*'))
    with target.open('wb') as raw, gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as bundle:
            for path in sorted(members): bundle.add(path,arcname=path.relative_to(ROOT).as_posix(),recursive=False,filter=stable)

head = run(['git','rev-parse','HEAD'])
assert run(['git','rev-parse','main'])==head
assert not run(['git','status','--porcelain','--untracked-files=no'])
assert not run(['git','diff',BASE,head,'--name-only','--','dist','vendor','hedgewars'])
proof = json.loads((ROOT/'proof/results/report.json').read_text())
assert proof['ticket']==TICKET and proof['result']=='PASS' and proof['head']==head
assert {'S1','S2','S3','S4','S5','S6','H1','O1','L1','B1','M1','M2'} <= {c['id'] for c in proof['checks'] if c['result']=='PASS'}
files = sorted((p for p in (ROOT/'site').rglob('*') if p.is_file()),key=lambda p:p.as_posix())
assert proof['siteHashes']==run(['sha256sum',*[str(p.relative_to(ROOT)) for p in files]]).splitlines()
assert sum(p.stat().st_size for p in files)<=150_000_000
assert max(p.stat().st_size for p in files)<=90_000_000
joined = CACHE/'site.tgz'; archive(joined,['site'])
parts = []
with joined.open('rb') as stream:
    while data := stream.read(24_000_000):
        path = OUT/('site.part-'+str(len(parts)+1).zfill(2)+'.tgz'); path.write_bytes(data); parts.append(path)
subprocess.run(['git','bundle','create',str(OUT/'repo.bundle'),'main','^'+BASE],cwd=ROOT,check=True)
subprocess.run(['git','bundle','verify',str(OUT/'repo.bundle')],cwd=ROOT,check=True)
archive(OUT/'proof.tgz',['proof/results','proof/evidence'])
assert (OUT/'proof.tgz').stat().st_size<=24_000_000
owned = parts+[OUT/'repo.bundle',OUT/'proof.tgz']
for name in ['DATA.md','README-HOST.md','LICENSE-CATALOG.md','TOOLS.json']:
    target=OUT/name; shutil.copy2(ROOT/name,target); owned.append(target)
ledger = json.loads((ROOT/'COMMIT-SIZES.json').read_text())
ledger['commits'] = []
exempt_names = {'package-lock.json','DATA.md','DATA.json','DEPENDENCIES.json','PATCHES.patch'}
new_heads = set(run(['git','rev-list',BASE+'..'+head]).splitlines())
for commit in run(['git','rev-list','--reverse',head]).splitlines():
    counted = excluded = 0
    for line in run(['git','show','--format=','--numstat',commit]).splitlines():
        added,removed,name = line.split('\t')
        if added=='-': continue
        lines = int(added)+int(removed)
        exempt = name.startswith(('vendor/','hedgewars/','dist/')) or name in exempt_names or (name.startswith('proof/evidence/') and name!='proof/evidence/README.md')
        if exempt: excluded += lines
        else: counted += lines
    if commit in new_heads:
        assert counted<=450,(commit,counted)
        assert 'Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>' in run(['git','show','-s','--format=%B',commit])
    ledger['commits'].append({'commit':commit,'subject':run(['git','show','-s','--format=%s',commit]),'handwrittenChangedLines':counted,'vendoredGeneratedEvidenceLinesExcluded':excluded})
ledger.update({'ticket':TICKET,'head':head,'base':BASE,'newCommitLineLimit':450})
(OUT/'COMMIT-SIZES.json').write_text(json.dumps(ledger,indent=2)+'\n'); owned.append(OUT/'COMMIT-SIZES.json')
sizes = {'ticket':TICKET,'head':head,'base':BASE,'siteJoinedSha256':sha(joined),
    'archiveBytes':joined.stat().st_size,'unpackedBytes':sum(p.stat().st_size for p in files),
    'siteFiles':len(files),'largestSiteFileBytes':max(p.stat().st_size for p in files),
    'parts':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in parts],
    'repoBundleBytes':(OUT/'repo.bundle').stat().st_size,'proofArchiveBytes':(OUT/'proof.tgz').stat().st_size,
    'firstLoadMs':proof['cases'][0]['loadMs'],'browser':proof['browser'],'measurement':proof['measurement'],
    'newCommitSizes':[r for r in ledger['commits'] if r['commit'] in new_heads]}
(OUT/'sizes.json').write_text(json.dumps(sizes,indent=2)+'\n'); owned.append(OUT/'sizes.json')
join = 'cat '+' '.join(p.name for p in parts)+' > site.tgz'
count_lines = '\n'.join(f"| {r['commit']} | {r['handwrittenChangedLines']} | {r['vendoredGeneratedEvidenceLinesExcluded']} |" for r in sizes['newCommitSizes'])
report = f'''# {TICKET} delivery

READY fix-round static local hotseat Hedgewars. Branch main, head {head}.
Base: {BASE}. Original joined site SHA256:
80498083b560bd36c8dd79df5645575f97135d2cf8451a6cbd72b9c2b870e8ed.
REUSE delivered host shell, pinned upstream engine/data and existing full proof.
The targeted LEGOS index did not cover this import; exact supplied local sources
and SOURCE.txt retain the sibling browser-games template and provider pins.
Owner: play-host-hedgewars-2-mac. Sole runtime: task-owned loopback frame proof
in this checkout. Two bounded read-only helpers advised legal and proof changes.
All work ran on the Mac. No push, cloud operation or engine rebuild occurred.

## Repair and review dispositions

P1-1 fixed: Capture and Record are removed. KeyC and KeyR, both keydown and
keyup, are stopped before SDL. The new regression fails on the rejected shell
and reproduces its false Screenshot saved feedback. The fixed keyboard and
both trusted-touch rounds have no advertised output actions, no C/R input
events reaching the canvas and no saved-output feedback. Original failing
and corrected witnesses are preserved in proof/evidence/fix2-*.

| Note | Disposition |
| --- | --- |
| P2-1 | Every new commit has the requested coauthor trailer. The ten old messages stay unchanged because rewriting delivered history is forbidden. |
| P2-2 | All ten original exact heads and counts are corrected, including ab9cb0e = 421. Output COMMIT-SIZES.json recomputes every original and new head, counting the handwritten ledger. |
| P2-3 | All new exempt-material messages declare exclusions. Historical declarations for the five named commits are in COMMIT-SIZES.json; their original messages stay unchanged to preserve history. |
| P2-4 | Existing buttons, map selector and legal link have 44px minimum dimensions. Short frames retain those limits and use compact menu text. Proof measures start, open controls and live game layouts, including 320x240 and 240x320. |
| P2-5 | The licensed flag row explicitly names its unchanged site/favicon.png alias and exact hash. |
| P2-6 | CC BY grants mark omitted clauses with [...] and the original c. label; full licences remain intact. |
| P2-7 | Inferred SVG companions require exact directory filename equality. Mac regeneration has 472 source files, lowercase hedgehog.svg once, and no uppercase duplicate. |
| P3-1 | Locked npm dependencies installed from package-lock.json URLs; locked Chromium 149 already cached. Full package/legal generation and fresh proof ran. Engine compilation is outside this fix and was not attempted. |

## Byte preservation and licences

The engine source, original assets, dist runtime and WASM have no changes from
the base. B1 compares seven shipped runtime/data files to the original supplied
manifest. Engine WASM SHA256: {sha(ROOT/'site/hwengine.wasm')}.
Only shell, proof, legal receipts, packaging and documentation changed.
Engine source pin: apmlabs/webwars 2269ab1eab930b496b6ceb69ce65be5f30b0545d.
Data pin: apmlabs/webwars 406e53fde3cd811f15ca4cc5ff0909e69f58e276.
GPL-2.0 code grant: "You may copy and distribute verbatim copies of the Program's
source code as you receive it, in any medium, provided that you conspicuously
and appropriately publish on each copy an appropriate copyright notice and
disclaimer of warranty; keep intact all the notices that refer to this License
and to the absence of any warranty; and give any other recipients of the
Program a copy of this License along with the Program."
GFDL-1.2 data fallback: "You may copy and distribute the Document in any medium,
either commercially or noncommercially, provided that this License, the
copyright notices, and the license notice saying this License applies to the
Document are reproduced in all copies, and that you add no other conditions
whatsoever to those of this License."
These are local verbatim COPYING grants. README.md assigns the licences and
CREDITS supplies the fallback. DATA.md retains each file's applicable grant,
including explicit CC BY, CC0, public-domain and font terms, with attribution
and preferred sources. Original notices remain intact. Unverified recordings
and music remain excluded. No unclear-licence assets were added.

## Proof and sizes

bash proof/run.sh exited 0 at this head: S1-S6, H1, O1, L1, B1, M1 and M2.
Cross-origin iframe uses only allow-scripts allow-same-origin and no allow
attribute. Nested paths, wrong WASM MIME, no Range, keyboard play, both phone
touch layouts, both maps, actual projectile/next team, target selection,
storage denial, resizing, quit, restart and legal return pass. Forbidden
capabilities and off-origin requests are zero in healthy cases. Both mutants
fail their intended assertions and all site bytes restore exactly.
One headless Playwright instance, GPU disabled, software WebGL; Chromium
{sizes['browser']}. First local cold-context START-ready measurement:
{sizes['firstLoadMs']:.1f} ms. WebGL2 and JSPI required; no Safari/iOS claim.
Archive {sizes['archiveBytes']} bytes; unpacked {sizes['unpackedBytes']} bytes;
{sizes['siteFiles']} files; largest {sizes['largestSiteFileBytes']} bytes.
Parts are at most 24000000 bytes; proof is {sizes['proofArchiveBytes']} bytes.

| New commit | Counted added plus removed | Excluded generated/evidence lines |
| --- | ---: | ---: |
{count_lines}

Each new commit is at most 450 counted lines. SIZE-EXCEPTION NONE.
KIT-GAP digest: the task allowlist excludes pluginpad kit sources; existing
sha256sum performs checks, with no new hashing implementation.

## Delivery and next owned action

```bash
{join}
sha256sum -c SHA256SUMS.txt
tar -xzf site.tgz
git clone /path/to/original-input/repo.bundle reproduce
cd reproduce
git fetch /path/to/fix-round-output/repo.bundle main
git checkout -B main FETCH_HEAD
npm ci
python3 host/build.py
python3 host/legal.py
bash proof/run.sh
```

The output repo.bundle is incremental and requires the exact original base
bundle. The existing release owner receives these parts, bundle and proof,
joins/verifies them, then uploads the complete site folder to the game's
separate origin and follows the Play entry point. This requested artifact
delivery is complete; no hosted deployment or Play catalog change is claimed.

Joined site SHA256: {sizes['siteJoinedSha256']}.
LEGOS-REGISTER {json.dumps({'slug':'play-host-hedgewars-2-mac','built':'Truthful output controls, touch sizing and legal fix delivery','repo':'browser-games-hedgewars-import','branch':'main','head':head,'feature':TICKET,'paths':['host/frame.js','host/style.css','host/legal.py','host/deliver.py','proof/check.mjs'],'reuse':['host/','proof/','SOURCE.txt']})}
{TICKET} READY {sizes['siteJoinedSha256']}
'''
report_path=OUT/('REPORT-'+TICKET+'.md')
report_path.write_text(report); owned.append(report_path)
(OUT/'SITE-SHA256SUMS.txt').write_text('\n'.join(proof['siteHashes'])+'\n'); owned.append(OUT/'SITE-SHA256SUMS.txt')
(OUT/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in owned)+sizes['siteJoinedSha256']+'  site.tgz\n')
print(json.dumps(sizes,indent=2)); print('Joined site SHA256:',sizes['siteJoinedSha256'])
print('SHA256SUMS.txt',sha(OUT/'SHA256SUMS.txt'))
