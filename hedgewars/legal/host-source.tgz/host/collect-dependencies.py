#!/usr/bin/env python3
"""One-time capture of locked upstream build dependencies and original notices."""
import json
import re
import shutil
import subprocess
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SDK = Path('/root/work/game/tools/emsdk/upstream/emscripten')
PORTS = SDK / 'cache/ports'
DEST = ROOT / 'vendor/tool-ports'
NOTICES = ROOT / 'vendor/dependency-notices'
DEST.mkdir(parents=True,exist_ok=True)
NOTICES.mkdir(parents=True,exist_ok=True)
rows = []
def checksum(path,algorithm='sha256sum'):
    return subprocess.check_output([algorithm,str(path)],text=True).split()[0]

specs = {
    'zlib':('1.3.1','https://github.com/madler/zlib/archive/refs/tags/v1.3.1.tar.gz'),
    'freetype':('2.13.3','https://github.com/freetype/freetype/archive/VER-2-13-3.zip'),
    'harfbuzz':('3.2.0','https://github.com/harfbuzz/harfbuzz/releases/download/3.2.0/harfbuzz-3.2.0.tar.xz'),
    'libpng':('1.6.39','https://storage.googleapis.com/webassembly/emscripten-ports/libpng-1.6.39.tar.gz'),
    'sdl2':('2.32.8','https://github.com/libsdl-org/SDL/archive/release-2.32.8.zip'),
    'sdl2_ttf':('2.20.2','https://github.com/libsdl-org/SDL_ttf/archive/release-2.20.2.zip'),
    'sdl2_mixer':('2.8.0','https://github.com/libsdl-org/SDL_mixer/archive/release-2.8.0.zip'),
    'sdl2_image':('2.6.0','https://github.com/libsdl-org/SDL_image/archive/refs/tags/release-2.6.0.zip'),
    'ogg':('version_1','https://github.com/emscripten-ports/ogg/archive/version_1.zip'),
    'vorbis':('version_1','https://github.com/emscripten-ports/vorbis/archive/version_1.zip'),
}
source_dirs = {'src','include','lib','cmake','builds','build-scripts','build-aux','m4','config','scripts'}
for name,(version,url) in specs.items():
    archive = next(p for p in PORTS.glob(name+'.*') if p.is_file())
    recipe = (SDK / 'tools/ports' / (name+'.py')).read_text()
    expected = re.search(r"^HASH = '([^']+)'",recipe,re.M)[1]
    assert checksum(archive,'sha512sum') == expected, name + ' tool-port digest mismatch'
    source = next(p for p in (PORTS/name).iterdir() if p.is_dir())
    for path in source.rglob('*'):
        if not path.is_file() or path.is_symlink(): continue
        relative = path.relative_to(source)
        # Build-library source only. Exclude test artwork, fonts, sample music,
        # prebuilt DLLs and unrelated platform packaging.
        notice = any(word in path.name.upper() for word in ('LICENSE','COPYING','COPYRIGHT','AUTHORS','FTL.TXT','GPLV2.TXT'))
        source_file = len(relative.parts) == 1 or relative.parts[0] in source_dirs
        content = path.read_bytes()
        if b'\0' in content or len(content) > 8_000_000: continue
        if notice or source_file:
            target = DEST/name/relative; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(path,target)
        if notice:
            target = NOTICES/name/relative; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(path,target)
    licenses = {'freetype':'GPL-2.0','harfbuzz':'Old MIT and ISC','libpng':'Libpng-2.0','ogg':'BSD-3-Clause','vorbis':'BSD-3-Clause'}
    rows.append({'name':name,'version':version,'source':url,'sha256':checksum(archive),'sha512':expected,
                 'license':licenses.get(name,'Zlib'),'type':'Emscripten 4.0.13 tool port'})
    print(name,version,checksum(archive),url)
closures = [('Rust','vendor/engine-source/hedgewars/rust/lib-hwengine-future/Cargo.lock','vendor/cargo'),
            ('Rust-stdlib','vendor/rust-stdlib/library/Cargo.lock','vendor/rust-stdlib-cargo')]
for family,lock_path,source_root in closures:
    lock = tomllib.loads((ROOT/lock_path).read_text())
    for package in lock['package']:
        if 'checksum' not in package: continue
        name,version = package['name'],package['version']
        archive = next(Path('/root/work/game/tools/cargo/registry/cache').glob('*/'+name+'-'+version+'.crate'))
        actual = checksum(archive); assert actual == package['checksum']
        source = ROOT/source_root/name
        metadata = tomllib.loads((source/'Cargo.toml').read_text())['package']
        for path in source.rglob('*'):
            if path.is_file() and any(word in path.name.upper() for word in ('LICENSE','COPYING','COPYRIGHT','NOTICE','AUTHORS')):
                target = NOTICES/family/name/path.relative_to(source); target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(path,target)
        rows.append({'name':name,'version':version,'source':'https://static.crates.io/crates/'+name+'/'+name+'-'+version+'.crate',
                     'sha256':actual,'license':metadata.get('license','See preserved source notice'),'type':family+' pinned Cargo.lock source dependency'})
        print(name,version,actual)
for name in ['wasip1','wasip2','wasip3','vex-sdk']:
    target = NOTICES/'Rust-stdlib'/name; target.mkdir(parents=True,exist_ok=True)
    shutil.copy2(ROOT/'vendor/rust-stdlib-cargo/wit-bindgen/LICENSE-MIT',target/'DECLARED-MIT.txt')
    (target/'README.txt').write_text('Supplemental full text for the declared MIT option. Original source notices remain intact; no copyright holder or date is inferred.\n')
mpl = subprocess.check_output(['node','-e',"process.stdout.write(require('spdx-license-list/full')['MPL-2.0'].licenseText)"],cwd=ROOT,text=True)
(NOTICES/'Rust-stdlib/fortanix-sgx-abi').mkdir(parents=True,exist_ok=True)
(NOTICES/'Rust-stdlib/fortanix-sgx-abi/DECLARED-MPL-2.0.txt').write_text(mpl+'\n')
for name,source in {'Emscripten-LICENSE.txt':'LICENSE','Emscripten-AUTHORS.txt':'AUTHORS',
                    'MiniLZ4.js':'third_party/mini-lz4.js','musl-COPYRIGHT.txt':'system/lib/libc/musl/COPYRIGHT',
                    'compiler-rt-LICENSE.txt':'system/lib/compiler-rt/LICENSE.TXT',
                    'libcxx-LICENSE.txt':'system/lib/libcxx/LICENSE.TXT',
                    'libcxxabi-LICENSE.txt':'system/lib/libcxxabi/LICENSE.TXT'}.items():
    shutil.copy2(SDK/source,NOTICES/name)
wasip2 = NOTICES/'Rust/wasip2'
wasip2.mkdir(parents=True,exist_ok=True)
shutil.copy2(ROOT/'vendor/cargo/wit-bindgen/LICENSE-MIT',wasip2/'DECLARED-MIT.txt')
(wasip2/'README.txt').write_text('Supplemental full text for the MIT option explicitly declared in the original wasip2 Cargo.toml. No copyright holder or date is inferred. Original source and manifest are preserved. This target does not link wasip2.\n')
shutil.copy2('/home/cloudlane/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/share/doc/rust/COPYRIGHT-library.html',NOTICES/'Rust-stdlib-COPYRIGHT.html')
(ROOT/'DEPENDENCIES.json').write_text(json.dumps({'sdk':'4.0.13','sdkPin':'404dc1ec13f64fce1af1eaf5c007e18212f63527',
    'rust':'1.97.1','rustCommit':'8bab26f4f68e0e26f0bb7960be334d5b520ea452',
    'enginePin':'2269ab1eab930b496b6ceb69ce65be5f30b0545d','compiled':True,
    'originalCompilerPins':'The undocumented published binary is not delivered. These are the actual freshly compiled engine inputs.',
    'packages':rows},indent=2)+'\n')
files = sorted(str(p.relative_to(ROOT)) for directory in [DEST,ROOT/'vendor/cargo',ROOT/'vendor/emscripten-runtime',ROOT/'vendor/rust-stdlib',ROOT/'vendor/rust-stdlib-cargo',NOTICES] for p in directory.rglob('*') if p.is_file())
(ROOT/'vendor/dependencies.SHA256SUMS.txt').write_bytes(subprocess.check_output(['sha256sum',*files],cwd=ROOT))
