// Reencode PNG pixel data as RGBA for the older upstream SDL image converter.
// Original assets and notices remain available with the corresponding source.
import { PNG } from 'pngjs';
const chunks = [];
for await (const chunk of process.stdin) chunks.push(chunk);
process.stdout.write(PNG.sync.write(PNG.sync.read(Buffer.concat(chunks)), {colorType:6}));
