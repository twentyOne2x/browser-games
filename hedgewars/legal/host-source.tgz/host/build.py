#!/usr/bin/env python3
"""Package the pinned upstream engine and a small, explicit data subset."""
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'hedgewars/share/hedgewars/Data'
SITE = ROOT / 'site'
SITE.mkdir(exist_ok=True)
(SITE / '.nojekyll').write_text('')
paths = set(DATA.glob('Graphics/*.png'))
for directory in ['Graphics/Hedgehog', 'Graphics/AmmoMenu', 'Graphics/SuddenDeath',
                  'Shaders', 'Themes/Nature',
                  'Sounds/voices/Default', 'Maps/Castle', 'Maps/Mushrooms']:
    paths.update(p for p in (DATA / directory).rglob('*') if p.is_file() and p.suffix in ('.png','.cfg','.vs','.fs','.ogg'))
# External recordings whose original grants are not stated in the permitted
# source tree are omitted. No music is redistributed.
uncertain_audio = {'mineimpact.ogg','hammer.ogg','sinegun.ogg','knife_impact.ogg'}
paths.update(p for p in DATA.glob('Sounds/*.ogg') if p.name not in uncertain_audio)
for filename in ['Graphics/Flags/hedgewars.png', 'Graphics/Hats/NoHat.png',
                 'Graphics/Hats/Reserved/chef.png',
                 'Graphics/Graves/Statue.png', 'Forts/EarthL.png', 'Forts/EarthR.png',
                 'Fonts/DejaVuSans-Bold.ttf', 'Locale/en.txt', 'map_templates.yaml',
                 'maze_templates.yaml', 'wfc_templates.toml', 'misc/keys.csv']:
    paths.add(DATA / filename)
blob = bytearray()
files = []
for path in sorted(paths):
    if not path.is_file():
        raise FileNotFoundError(path)
    start = len(blob)
    original = path.read_bytes()
    content = subprocess.check_output(['node', str(ROOT / 'host/rgba.mjs')], input=original) if path.suffix == '.png' and original[25] not in (2,6) else original
    if path.relative_to(DATA).as_posix() == 'Themes/Nature/theme.cfg':
        content = content.replace(b'music = Nature.ogg\n', b'')
    blob.extend(content)
    files.append({'name': '/Data/' + path.relative_to(DATA).as_posix(), 'start': start, 'end': len(blob), 'reencoded': path.suffix == '.png' and content != original})
font = next(f for f in files if f['name'] == '/Data/Fonts/DejaVuSans-Bold.ttf')
aliases = {'Fonts/wqy-zenhei.ttc':'Fonts/DejaVuSans-Bold.ttf','Sounds/mineimpact.ogg':'Sounds/grenadeimpact.ogg',
           'Sounds/sinegun.ogg':'Sounds/gun.ogg','Sounds/hammer.ogg':'Sounds/pickhammer.ogg','Sounds/knife_impact.ogg':'Sounds/graveimpact.ogg'}
for alias,source_name in aliases.items():
    original = next(f for f in files if f['name'] == '/Data/' + source_name)
    files.append({**original,'name':'/Data/' + alias,'source':source_name})
(SITE / 'game.data').write_bytes(blob)
(SITE / 'observer.lua').write_bytes((ROOT / 'host/PlayObserver.lua').read_bytes())
(SITE / 'data.json').write_text(json.dumps({'files': files}, separators=(',', ':')) + '\n')
source = (ROOT / 'dist/hwengine.js').read_text()
runtime = source[source.index('var arguments_=[];'):]
if 'Module.onRuntimeInitialized=async function()' in runtime:
    runtime = runtime[:runtime.index('Module.onRuntimeInitialized=async function()')]
runtime = 'var ENVIRONMENT_IS_WEB=true;var ENVIRONMENT_IS_WORKER=false;var ENVIRONMENT_IS_NODE=false;\n' + runtime
# Return unsupported before Emscripten can request forbidden frame capabilities.
begin = runtime.index('var _emscripten_request_pointerlock=')
end = runtime.index(';var growMemory=', begin)
runtime = runtime[:begin] + 'var _emscripten_request_pointerlock=()=>-1' + runtime[end:]
begin = runtime.index('var _emscripten_request_fullscreen_strategy=')
end = runtime.index(';var _emscripten_request_pointerlock=', begin)
runtime = runtime[:begin] + 'var _emscripten_request_fullscreen_strategy=()=>-1' + runtime[end:]
# Always instantiate from bytes. No MIME or Range dependency and no cookies.
begin = runtime.index('async function instantiateAsync(')
end = runtime.index('function getWasmImports(', begin)
runtime = runtime[:begin] + 'async function instantiateAsync(binary,file,imports){return instantiateArrayBuffer(file,imports)}' + runtime[end:]
runtime = runtime.replace('credentials:"same-origin"', 'credentials:"omit"')
runtime = runtime.replace('globalThis.devicePixelRatio??1', 'Math.min(globalThis.devicePixelRatio||1,2)')
runtime = runtime.replace('var reply=window.prompt(str,"i");', 'var reply="i";')
(SITE / 'hwengine.js').write_text('/* Adapted 2026-10-11 for the Play frame. Engine GPL-2.0; Emscripten MIT/NCSA notices in legal/. */\n' + runtime)
shutil.copy2(ROOT / 'dist/hwengine.wasm', SITE / 'hwengine.wasm')
shutil.copy2(DATA / 'Graphics/Flags/hedgewars.png', SITE / 'favicon.png')
for name in ['index.html', 'frame.js', 'style.css', 'bridge.js']:
    shutil.copy2(ROOT / 'host' / name, SITE / name)
print(f'Packaged {len(files)} data files, {len(blob)} data bytes')
