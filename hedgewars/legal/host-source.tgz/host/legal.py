#!/usr/bin/env python3
"""Preserve original grants and generate a per-file distribution ledger."""
import html
import gzip
import json
import re
import shutil
import struct
import subprocess
import tarfile
import tempfile
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'hedgewars/share/hedgewars/Data'
LEGAL = ROOT / 'site/legal'
PIN = '406e53fde3cd811f15ca4cc5ff0909e69f58e276'
ENGINE = '2269ab1eab930b496b6ceb69ce65be5f30b0545d'
SOURCE = 'https://github.com/apmlabs/webwars/blob/' + PIN + '/'
LEGAL.mkdir(parents=True, exist_ok=True)
@contextmanager
def archive_at(path):
    def stable(info):
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ''
        info.mode = 0o755 if info.isdir() or info.mode & 0o111 else 0o644
        return info
    with path.open('wb') as raw, gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as archive:
            class StableArchive:
                def add(self,*args,**kwargs): archive.add(*args,**kwargs,filter=stable)
            yield StableArchive()

def digest(path):
    return subprocess.check_output(['sha256sum', str(path)], text=True).split()[0]

def compact(text):
    return ' '.join(text.split())

copying = (ROOT / 'hedgewars/COPYING').read_text()
gpl = compact(re.search(r"You may copy and distribute verbatim copies.*?along with the Program\.", copying, re.S)[0])
gfdl = compact(re.search(r'You may copy and distribute the Document.*?of this\s+License\.', copying, re.S)[0])
font_text = (ROOT / 'hedgewars/Fonts_LICENSE.txt').read_text()
font_grant = compact(re.search(r'Permission is hereby granted.*?following conditions:', font_text, re.S)[0])
licenses = json.loads(subprocess.check_output(['node', '-e', "console.log(JSON.stringify(require('spdx-license-list/full')))"], cwd=ROOT))
ccby_text = licenses['CC-BY-3.0']['licenseText']
ccby = compact(re.search(r'Subject to the terms.*?as stated below:', ccby_text, re.S)[0]) + ' [...] c. ' + compact(re.search(r'to Distribute and Publicly Perform.*?Collections;', ccby_text, re.S)[0])
cc0_text = licenses['CC0-1.0']['licenseText']
cc0 = compact(re.search(r'To the greatest extent.*?\(the "Waiver"\)\.', cc0_text, re.S)[0])
grants = {'GPL-2.0':gpl, 'GFDL-1.2':gfdl, 'CC-BY-3.0':ccby, 'CC0-1.0':cc0,
          'Public domain':'Rubber duck sounds are in the Public Domain.',
          'Bitstream Vera / Arev; DejaVu changes public domain':font_grant}
grants['CC-BY-3.0 + GFDL-1.2 game edits'] = ccby + ' Game edits: ' + gfdl
grants['GFDL-1.2 + original CC0-1.0'] = gfdl + ' Original recording: ' + cc0
for name in ['COPYING','CREDITS','README.md','Fonts_LICENSE.txt']:
    shutil.copy2(ROOT / 'hedgewars' / name, LEGAL / name)
    if name in ('COPYING','CREDITS'): shutil.copy2(ROOT / 'hedgewars' / name,LEGAL / (name + '.txt'))
shutil.copy2(ROOT / 'hedgewars/QTfrontend/res/credits.csv', LEGAL / 'credits.csv')
for name in ['CC-BY-3.0','CC0-1.0']:
    (LEGAL / (name + '.txt')).write_text(licenses[name]['licenseText'] + '\n')
# The bundled font embeds the additional Arev permission and copyright notices.
font = (DATA / 'Fonts/DejaVuSans-Bold.ttf').read_bytes()
tables = struct.unpack_from('>H', font, 4)[0]
name_offset = next(struct.unpack_from('>II',font,12+i*16+8)[0] for i in range(tables) if font[12+i*16:16+i*16] == b'name')
_, count, storage = struct.unpack_from('>HHH',font,name_offset)
notices = set()
for i in range(count):
    platform, _, _, name_id, length, offset = struct.unpack_from('>HHHHHH',font,name_offset+6+i*12)
    if name_id in (0,13):
        raw = font[name_offset+storage+offset:name_offset+storage+offset+length]
        notices.add(raw.decode('utf-16-be' if platform in (0,3) else 'latin1'))
(LEGAL / 'Font-embedded-notices.txt').write_text('\n\n'.join(sorted(notices)) + '\n')

ccby_audio = {'extratime.ogg':'uair01','jetpackboost.ogg':'Jagadamba','dynamitefuse.ogg':'apolloaiello',
              'dynamiteimpact.ogg':'kev_durr','landgun.ogg':'Benboncan','portalshot.ogg':'bubaproducer',
              'firepunch_hit.ogg':'CGEffex, adapted by alfadur',
              **{f'Droplet{i}.ogg':'saugox (2017)' for i in range(1,4)}}
cc0_audio = {'airmine_impact.ogg':'Wuzzy, based on batchku','portalswitch.ogg':'Wuzzy','portalopen.ogg':'Wuzzy',
             **{f'countdown{i}.ogg':'Wuzzy' for i in range(1,5)}}
cc0_remix = {'lasersight.ogg':'drzhn/drzhnn','blowtorch.ogg':'rombard/rombart',
             'flamethrower.ogg':'AslakHostaker','invulnerable.ogg':'pepingrillin'}
ccby_images = {'Graphics/Explosives.png','Graphics/ExplosivesRoll.png',
               'Themes/Nature/mushroom.png','Themes/Nature/mushroom2.png','Themes/Nature/snail.png'}
def terms(relative):
    path = Path(relative)
    author = 'Andrey Korotaev and Hedgewars contributors; preserved CREDITS and credits.csv'
    evidence = SOURCE + 'hedgewars/CREDITS'
    license_id = 'GFDL-1.2' if path.suffix in ('.png','.ogg','.svg') else 'GPL-2.0'
    note = 'Project fallback: CREDITS says "IF NO LICENSE IS SPECIFIED, THE LICENSE IS THE SAME AS MENTIONED IN README.md." Images/sounds use GFDL; configuration, shaders and locale are treated as project source under GPL.'
    if relative in ccby_images or relative.removesuffix('.svg') + '.png' in ccby_images:
        license_id, author = 'CC-BY-3.0','Carlos Vives B.'
        evidence, note = SOURCE + 'hedgewars/share/hedgewars/Data/' + relative.replace('.png','.svg'), 'Explicit SVG RDF grant; original editable source preserved.'
    elif path.name in ccby_audio:
        license_id, author = 'CC-BY-3.0 + GFDL-1.2 game edits', ccby_audio[path.name]
        note = 'Original recording CC-BY-3.0 and project GFDL-1.2 for game edits. Both terms and original attribution preserved.'
        if path.name.startswith('Droplet'):
            license_id, note = 'CC-BY-3.0','Delivered Ogg copyright tag explicitly states CC BY 3.0; preserved unchanged.'
    elif path.name in cc0_audio:
        license_id, author, note = 'CC0-1.0',cc0_audio[path.name],'Delivered result explicitly credited CC-0.'
    elif path.name in cc0_remix:
        license_id, author, note = 'GFDL-1.2 + original CC0-1.0',cc0_remix[path.name], 'Original recording CC0-1.0; project game adaptation uses the GFDL-1.2 fallback.'
    elif path.name in ('rubberduck_die.ogg','rubberduck_drop.ogg','rubberduck_water.ogg'):
        license_id, note = 'Public domain','Explicit CREDITS public domain declaration.'
    elif path.suffix in ('.ttf','.ttc'):
        license_id, author = 'Bitstream Vera / Arev; DejaVu changes public domain','Bitstream Inc.; Tavmjong Bah; DejaVu contributors'
        evidence, note = SOURCE + 'hedgewars/Fonts_LICENSE.txt','Full font terms and embedded Arev notices preserved. Alias filename only; unmodified DejaVu bytes, no WenQuanYi font.'
    if relative.startswith('Sounds/voices/Default/'): author = 'Stephen Alexander (Armagon)'
    if relative.startswith('Maps/Castle/'): author = 'Stanko Tadic (original credits spell Tadić)'
    if relative.startswith('Maps/Mushrooms/'): author = 'John Dum'
    if relative.startswith('Themes/Nature/') and relative.removesuffix('.svg') + '.png' not in ccby_images and relative not in ccby_images: author = 'John Dum and Hedgewars contributors'
    if relative in ('Graphics/BlueWater.png','Graphics/BlueWater.svg','Graphics/Droplet.png','Graphics/Droplet.svg'): author = 'Carlos Vives B.'
    return license_id,author,evidence,note

manifest = json.loads((ROOT / 'site/data.json').read_text())['files']
blob = (ROOT / 'site/game.data').read_bytes()
rows, source_files = [], set()
with tempfile.TemporaryDirectory(dir=ROOT) as temporary:
    scratch = Path(temporary) / 'delivered'
    for item in manifest:
        relative = item['name'].removeprefix('/Data/')
        original_relative = item.get('source',relative)
        source_path = DATA / original_relative
        source_files.add(source_path)
        scratch.write_bytes(blob[item['start']:item['end']])
        license_id, author, evidence, note = terms(original_relative)
        if relative != original_relative: note += ' Virtual filename alias of unchanged ' + original_relative + ' bytes. Original excluded recording/font is not redistributed.'
        modified = item['reencoded'] or relative == 'Themes/Nature/theme.cfg'
        if item['reencoded']: note += ' PNG reencoded as RGBA, preserving pixel values, for old engine compatibility.'
        if relative == 'Themes/Nature/theme.cfg': note += ' Removed music reference; no music redistributed.'
        if relative == 'Graphics/Flags/hedgewars.png': note += ' Also delivered unchanged as site/favicon.png.'
        rows.append({'name':item['name'],'size':scratch.stat().st_size,'sha256':digest(scratch),
                     'sourceSha256':digest(source_path),'sourceSize':source_path.stat().st_size,'source':SOURCE + 'hedgewars/share/hedgewars/Data/' + original_relative,
                     'license':license_id,'grant':grants[license_id],'author':author,'evidence':evidence,'note':note,'modified':modified})
# Preserve available editable SVG originals alongside the exact delivered PNGs.
for path in list(source_files):
    svg = path.with_suffix('.svg')
    if svg.is_file() and any(entry.name == svg.name for entry in svg.parent.iterdir()): source_files.add(svg)
for extra in ['Graphics/hedgehog.svg','Maps/Castle/credits.txt','Maps/Mushrooms/credits.txt','Themes/Nature/credits.txt']:
    if (DATA / extra).is_file(): source_files.add(DATA / extra)
with archive_at(LEGAL / 'data-source.tgz') as archive:
    for path in sorted(source_files):
        archive.add(path,arcname='Data/' + path.relative_to(DATA).as_posix())
        if path.suffix == '.svg' or path.name == 'credits.txt':
            relative = path.relative_to(DATA).as_posix()
            license_id,author,evidence,note = terms(relative)
            if relative == 'Graphics/hedgehog.svg': license_id, note, evidence = 'GPL-2.0','Explicit GPL-2.0 SVG notice. Association with Hedgehog.png is not asserted.',SOURCE + 'hedgewars/share/hedgewars/Data/' + relative
            rows.append({'name':'data-source.tgz:Data/' + relative,'size':path.stat().st_size,'sha256':digest(path),
                         'sourceSha256':digest(path),'sourceSize':path.stat().st_size,'source':SOURCE + 'hedgewars/share/hedgewars/Data/' + relative,
                         'license':license_id,'grant':grants[license_id],'author':author,'evidence':evidence,'note':note,'modified':False})
with archive_at(LEGAL / 'engine-source.tgz') as archive:
    archive.add(ROOT / 'vendor/engine-source',arcname='engine-source')
with archive_at(LEGAL / 'dependency-source.tgz') as archive:
    for name in ['cargo','tool-ports','emscripten-runtime','rust-stdlib','rust-stdlib-cargo','dependency-notices']:
        archive.add(ROOT / 'vendor' / name,arcname=name)
    for name in ['DEPENDENCIES.json','DEPENDENCIES.md','TOOLS.json']: archive.add(ROOT / name,arcname=name)
shutil.copytree(ROOT / 'vendor/dependency-notices',LEGAL / 'dependency-notices',dirs_exist_ok=True)
with archive_at(LEGAL / 'host-source.tgz') as archive:
    for path in sorted((ROOT / 'host').glob('*')):
        if path.is_file(): archive.add(path,arcname='host/' + path.name)
    for name in ['package.json','package-lock.json']: archive.add(ROOT / name,arcname=name)
(ROOT / 'DATA.json').write_text(json.dumps({'dataPin':PIN,'enginePin':ENGINE,'files':rows},indent=2) + '\n')
lines = ['# Hedgewars delivered data ledger','',f'Data source: {SOURCE}hedgewars/share/hedgewars/Data/','',
         'Every game file is listed below with original and delivered hashes. Virtual font alias shares the same blob range. Editable SVG companions are included in data-source.tgz. Original PNG/Ogg bytes are the preferred sources where upstream supplies no editable counterpart. Licence texts, original notices and credits are preserved in legal/. No invariant sections or cover texts were identified in the project GFDL notice. Full distribution terms apply, including source and attribution conditions.','',
         '| File | Bytes | Delivered SHA256 | Source SHA256 | Licence and quoted redistribution grant | Author, evidence and modifications | Source address |',
         '| --- | ---: | --- | --- | --- | --- | --- |']
for row in rows:
    lines.append('| ' + ' | '.join([row['name'],str(row['size']),row['sha256'],row['sourceSha256'],
                                  row['license'] + ': "' + row['grant'] + '"',row['author'] + '; ' + row['note'] + ' Evidence: ' + row['evidence'],row['source']]) + ' |')
(ROOT / 'DATA.md').write_text('\n'.join(lines) + '\n')
for name in ['DATA.md','DATA.json','LICENSE-CATALOG.md','DECISION.md','DEPENDENCIES.md','DEPENDENCIES.json','TOOLS.json','README-HOST.md']:
    shutil.copy2(ROOT / name,LEGAL / name)
shutil.copy2(ROOT / 'SOURCE.txt',LEGAL / 'SOURCE.txt')
links = ['SOURCE.txt','COPYING.txt','CREDITS.txt','README.md','credits.csv','CC-BY-3.0.txt','CC0-1.0.txt',
         'Fonts_LICENSE.txt','Font-embedded-notices.txt','LICENSE-CATALOG.md','DATA.md','DATA.json',
         'DECISION.md','README-HOST.md','DEPENDENCIES.md','DEPENDENCIES.json','TOOLS.json','engine-source.tgz','data-source.tgz','host-source.tgz','dependency-source.tgz']
(LEGAL / 'index.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Hedgewars legal and source</title><link rel="stylesheet" href="legal.css"><h1>Hedgewars legal and source</h1><p>Copyright Andrey Korotaev and contributors. Browser port by apmlabs/webwars. Local frame adaptations are GPL-2.0. Engine code is GPL-2.0; images and sounds use the project GFDL-1.2 fallback or the explicit free terms listed for each file. DejaVu has its original font terms.</p><p>Complete corresponding engine source, frame patches, original data sources, licence texts and credits are available here. No music or externally unverified recordings are included.</p><ul>' + ''.join('<li><a href="' + name + '">' + html.escape(name) + '</a></li>' for name in links) + '</ul><p><a href="../">Back to game</a></p></html>\n')
(LEGAL / 'legal.css').write_text('body{max-width:850px;margin:24px auto;padding:0 16px;background:#081222;color:#edf5ff;font:16px/1.5 system-ui}a{color:#9de3ff}\n')
print(f'Licence ledger: {len(rows)} files, game manifest: {len(manifest)} entries')
