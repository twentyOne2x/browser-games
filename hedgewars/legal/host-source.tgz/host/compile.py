#!/usr/bin/env python3
"""Compile the pinned upstream generated engine without changing its rules."""
import concurrent.futures
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'vendor/engine-source'
HW = SRC / 'hedgewars'
SDK = Path(os.environ.get('PLAY_EMSDK','/root/work/game/tools/emsdk'))
RUST = Path(os.environ.get('PLAY_RUST_TOOLCHAIN','/home/cloudlane/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu'))
BUILD = ROOT / 'build/engine'
BUILD.mkdir(parents=True,exist_ok=True)
env = {**os.environ,'EM_CONFIG':str(SDK/'.emscripten'),'CARGO_HOME':str(ROOT.parent/'tools/cargo'),
       'RUSTC':str(RUST/'bin/rustc'),'PATH':str(SDK/'upstream/emscripten')+':'+os.environ['PATH']}
subprocess.run([str(RUST/'bin/cargo'),'build','--locked','--offline','--config','source.crates-io.replace-with="vendored-sources"',
    '--config','source.vendored-sources.directory="'+str(ROOT/'vendor/cargo')+'"','--release','--target','wasm32-unknown-emscripten',
    '--manifest-path',str(HW/'rust/lib-hwengine-future/Cargo.toml'),'--target-dir',str(BUILD/'rust')],env=env,check=True)
includes = [SRC/'generated/pas2c',HW/'project_files/hwc/rtl',HW/'misc/liblua',HW/'misc/libphysfs',HW/'misc/libphyslayer']
flags = ['-O2','-fwasm-exceptions','-sSUPPORT_LONGJMP=wasm','-sUSE_SDL=2','-sUSE_SDL_MIXER=2',
         '-sUSE_SDL_IMAGE=2','-sSDL2_IMAGE_FORMATS=png','-sUSE_SDL_TTF=2','-sUSE_LIBPNG=1','-sUSE_VORBIS=1','-sUSE_OGG=1',
         '-DPAS2C','-DHWLIBRARY','-DPHYSFS_SUPPORTS_ZIP=1','-DPHYSFS_NO_THREAD_SUPPORT=1','-DPHYSFS_NO_CDROM_SUPPORT=1']
flags += ['-I'+str(path) for path in includes]
sources = sorted((SRC/'generated/pas2c').glob('*.c'))
sources += sorted((HW/'project_files/hwc/rtl').glob('*.c'))
sources += [HW/'project_files/hwc/web_entry.c',HW/'project_files/hwc/ipc_browser.c']
sources += sorted((HW/'misc/liblua').glob('*.c'))
sources += sorted((HW/'misc/libphyslayer').glob('*.c'))
sources += [HW/'misc/libphysfs'/name for name in ['physfs.c','physfs_byteorder.c','physfs_unicode.c','platform_posix.c',
    'platform_unix.c','platform_macosx.c','platform_windows.c','archiver_dir.c','archiver_unpacked.c','archiver_grp.c',
    'archiver_hog.c','archiver_lzma.c','archiver_mvl.c','archiver_qpak.c','archiver_wad.c','archiver_zip.c','archiver_iso9660.c']]
def compile_source(item):
    index,path = item
    output = BUILD / (str(index)+'.o')
    extra = ['-include',str(HW/'misc/liblua/lua.h')] if path.name == 'hwpacksmounter.c' else []
    subprocess.run([str(SDK/'upstream/emscripten/emcc'),*flags,*extra,'-c',str(path),'-o',str(output)],env=env,check=True)
    return output
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    objects = list(pool.map(compile_source,enumerate(sources)))
subprocess.run([str(SDK/'upstream/emscripten/emcc'),*flags,*map(str,objects),
    str(BUILD/'rust/wasm32-unknown-emscripten/release/libhwengine_future.a'),
    '-sMIN_WEBGL_VERSION=2','-sMAX_WEBGL_VERSION=2','-sGL_PREINITIALIZED_CONTEXT','-sALLOW_MEMORY_GROWTH=1',
    '-sINITIAL_MEMORY=268435456','-sSTACK_SIZE=5MB','-sJSPI',
    '-sJSPI_EXPORTS=hwengine_RunEngine_internal','-sJSPI_IMPORTS=emscripten_sleep',
    '-Wl,--wrap=hwengine_MainLoop','-sEXPORTED_RUNTIME_METHODS=FS,HEAPU8',
    '-sEXPORTED_FUNCTIONS=_hwengine_RunEngine_internal,_mainloop_frame_bg','--no-entry','-o',str(BUILD/'hwengine.js')],env=env,check=True)
print('Compiled',len(sources),'upstream C sources, pinned Rust dependency closure, Emscripten 4.0.13')
