# PLAY-HOST-OPENARENA-1

Build the existing OpenArena game as a static page for the Play app. Keep one START action, three local bot skirmish arenas, drag look and phone controls. READY requires provenance, free redistribution terms, S1 through S6, failing mutations, restored bytes and verified delivery archives.

EXTEND the Play Quake sibling shell in twentyone2x/browser-games at 833bdd9d84fc578f7a695e34a35e5588aa1639f4. REUSE official ioquake/ioq3 at 83a776283bdb958f82db25554b5ed0966aaf6e49. STACKS-COVERED launchpads royale stonkpacks challenger. The stack map did not index this new OpenArena page. Targeted LEGOS found the existing Doom, Freedoom and Quake work and no current OpenArena duplicate. The index was stale and the lookup was deliberately restricted to its existing index.

This lane is the sole build and integration owner. Work and output are local to the explicitly named Mac lane. The final main bundle goes to the existing Play release owner. No push or deployment is part of this lane.

The official current engine has an Emscripten CMake target and includes local server simulation and bot AI in its browser client. No separate game server is started. Network access is disabled through net_enabled=0. Upstream QVM generation is disabled; original OpenArena 0.8.8 QVMs are mounted from the official data release.

QuakeJS was rejected as the first choice because its older port adds legacy content-server loading and storage work. It also contains a local listen server, so a dedicated server is not intrinsically required. No engine is rewritten.

The first build used Emscripten 4.0.16, compiled successfully, then failed shader compilation under the software-rendered browser. The upstream CI pins 3.1.58, which is the final compiler version. Cached Chromium software GPU processes crashed in libvk_swiftshader while compiling the WebGL 2 shader set. An independent exact-shader control compiled successfully. The upstream WebGL 1 path then compiled all 114 shaders and reached a real match with two bots. The final patch caps MAX_WEBGL_VERSION at 1. Earlier failed witnesses are retained separately.

The page bridge forwards only numeric key and drag events to the engine event queue, selects one of three fixed maps and reports engine snapshot state. The source patch is in engine.patch. SDL mouse activation is disabled in web builds, so no relative mode or pointer lock is requested. All keyboard and touch inputs use the same guarded handler. No URL query can inject a command.

Data selection retains oa_dm1, aggressor, oa_minia, their BSP and AAS pairs, bot files, two Sarge-model bots, OpenArena QVMs, and selected shared assets. No commercial Quake data is included. Selection uses original PK3 override ordering and retained files remain byte-identical to the release. DATA.json records each member's release path, bytes, hash and licence.

UX-BUDGET: one START action; zero confirmation controls; five required touch actions and one next-arena action; zero accounts, purchases or storage dependencies. The explicit lane brief supplies the page contract and authorizes implementation using the finished sibling shell.

Canvas resize waits for the renderer restart to adopt the requested backing dimensions. SDL CSS writes are observed and the page restores the fitted 16:9 CSS dimensions. Proof compares measured dimensions to the requested frame size and checks the actual engine-created WebGL context. SDL assertion handling aborts with a stderr message instead of requesting a browser prompt.

KIT-GAP digest: this isolated upstream-build lane does not install fleet application kits. Provenance uses existing platform SHA256 tools and the selector uses Python hashlib; no hashing algorithm is copied or implemented.

The native g_elimination=1 starting-loadout option gives the player and bots the game's finite-ammo weapon set immediately in these free-for-all skirmishes. Original game code is unchanged. This makes the required touch weapon control useful from the first spawn instead of waiting for an arena pickup.
