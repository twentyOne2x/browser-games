#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p proof/.tmp
export TMPDIR="$PWD/proof/.tmp"
exec node proof/run.mjs "$@"
