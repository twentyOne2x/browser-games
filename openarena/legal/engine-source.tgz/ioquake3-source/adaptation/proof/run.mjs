// OpenArena frame contract proof. This harness never injects game actions.
import { chromium } from 'playwright';
import http from 'node:http';
import { readFile, writeFile, mkdir, stat, readdir } from 'node:fs/promises';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const command=promisify(execFile);
import { fileURLToPath } from 'node:url';

const repo = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const site = path.resolve(process.env.PROOF_SITE || path.join(repo, 'site'));
const output = path.resolve(process.env.PROOF_OUT || path.join(repo, 'proof', 'results'));
const timeout = Number(process.env.PROOF_TIMEOUT_MS || 180000);
const prefix = '/prefix/openarena/';
const inputMarker = process.env.PROOF_INPUT_MARKER || 'function input(kind, a, b) {\n  if (!active) return;';
const pointerMarker = '// START_POINTER_LOCK_MUTATION';
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const baseHead = '33fad0adbfa8f6aecab290c2b57f21ab0293d0d5';
const report = { ticket: 'PLAY-HOST-OPENARENA-2', started: new Date().toISOString(), status: 'FAIL', scenarios: [], mutations: [], runtime: { pid: process.pid } };
const lines = [];
const log = (message, data) => { const line = `${new Date().toISOString()} ${message}${data === undefined ? '' : ` ${JSON.stringify(data)}`}`; lines.push(line); console.log(line); };
class ProofError extends Error { constructor(check, message) { super(message); this.check = check; } }
const must = (condition, check, message) => { if (!condition) throw new ProofError(check, message); };
const mime = name => name.endsWith('.wasm') ? 'text/plain' : ({ '.html': 'text/html', '.js': 'application/javascript', '.mjs': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ogg': 'audio/ogg' }[path.extname(name)] || 'application/octet-stream');
const listen = server => new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', () => resolve(`http://127.0.0.1:${server.address().port}`)); });
const closeServer = server => new Promise(resolve => { if (!server?.listening) return resolve(); server.close(resolve); server.closeAllConnections?.(); });

function instrument({ denyStorage, storageMethods, lateStorage }) {
  const counters = { contextLosses: 0, pointerLock: 0, fullscreen: 0, dialogs: 0, windowOpen: 0, serviceWorkers: 0, workers: 0, sockets: 0, cookieWrites: 0, storageDenials: 0, denyStorage };
  Object.defineProperty(window, '__frameProof', { value: counters });
  window.addEventListener('webglcontextlost',()=>counters.contextLosses++,true);
  const contexts=new WeakMap(),getContext=HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext=function(kind,...args){
    const context=getContext.call(this,kind,...args);
    if(this.id==='canvas' && context && ['webgl','webgl2','experimental-webgl'].includes(kind))contexts.set(this,context);
    return context;
  };
  Object.defineProperty(window,'__frameRender',{value(){
    const gl=contexts.get(document.getElementById('canvas'));
    return {webgl:!!gl,contextLost:gl?.isContextLost(),width:gl?.drawingBufferWidth,height:gl?.drawingBufferHeight};
  }});
  for (const key of ['requestPointerLock', 'mozRequestPointerLock', 'webkitRequestPointerLock']) Object.defineProperty(Element.prototype, key, { configurable: true, value() { counters.pointerLock++; return Promise.resolve(); } });
  for (const key of ['requestFullscreen', 'webkitRequestFullscreen', 'mozRequestFullScreen']) Object.defineProperty(Element.prototype, key, { configurable: true, value() { counters.fullscreen++; return Promise.resolve(); } });
  for (const key of ['alert', 'confirm', 'prompt']) window[key] = () => { counters.dialogs++; return null; };
  window.open = () => { counters.windowOpen++; return null; };
  const forbidden = key => function () { counters[key]++; throw new DOMException('Unavailable in this frame', 'SecurityError'); };
  for (const key of ['Worker', 'SharedWorker']) Object.defineProperty(window, key, { configurable: true, value: forbidden('workers') });
  Object.defineProperty(window, 'WebSocket', { configurable: true, value: forbidden('sockets') });
  Object.defineProperty(window, 'SharedArrayBuffer', { configurable: true, value: undefined });
  if (navigator.serviceWorker) navigator.serviceWorker.register = forbidden('serviceWorkers');
  const cookie = Object.getOwnPropertyDescriptor(Document.prototype, 'cookie');
  if (cookie) Object.defineProperty(Document.prototype, 'cookie', { configurable: true, get() { return ''; }, set() { counters.cookieWrites++; } });
  if (denyStorage) {
    const handles = [window.localStorage, window.sessionStorage, window.indexedDB];
    const denied = () => { counters.storageDenials++; throw new DOMException('Storage denied by proof', 'SecurityError'); };
    const install = () => {
      if (storageMethods) {
        for (const key of ['getItem', 'setItem', 'removeItem', 'clear', 'key']) Object.defineProperty(Storage.prototype, key, { configurable: true, value: denied });
        for (const key of ['open', 'deleteDatabase']) Object.defineProperty(IDBFactory.prototype, key, { configurable: true, value: denied });
      } else for (const key of ['localStorage', 'sessionStorage', 'indexedDB']) Object.defineProperty(window, key, { configurable: true, get: denied });
    };
    const receipt = () => {
      const probes = storageMethods ? handles.slice(0, 2).flatMap((store, index) => ['getItem', 'setItem', 'removeItem', 'clear', 'key'].map(method => ({ name: `${index ? 'sessionStorage' : 'localStorage'}.${method}`, run: () => store[method]('__proof_denial__', 'denied') }))).concat(['open', 'deleteDatabase'].map(method => ({ name: `indexedDB.${method}`, run: () => handles[2][method]('__proof_denial__') }))) : ['localStorage', 'sessionStorage', 'indexedDB'].map(key => ({ name: key, run: () => window[key] }));
      return probes.map(probe => { try { probe.run(); return { name: probe.name, denied: false }; } catch (error) { return { name: probe.name, denied: error.name === 'SecurityError' }; } });
    };
    Object.defineProperty(window, '__storageProof', { value: { install, receipt } });
    if (!lateStorage) install();
  }
}

async function state(frame, check = 'S3') {
  const value = await frame.evaluate(() => window.play.state());
  must(value && typeof value === 'object', check, 'state() did not return engine state');
  for (const key of ['x', 'y', 'z', 'pitch', 'yaw', 'ammo', 'weapon', 'eventSequence', 'time', 'botCount']) must(Number.isFinite(value[key]), check, `Engine state ${key} is not finite`);
  must(value.ready === true && typeof value.map === 'string' && value.map.length > 0, check, 'Engine has no ready match or map');
  return value;
}

async function pollState(frame, predicate, check, message, duration = 1600) {
  const end = Date.now() + duration;
  let current;
  do { current = await state(frame, check); if (predicate(current)) return current; await sleep(40); } while (Date.now() < end);
  throw new ProofError(check, `${message}: ${JSON.stringify(current)}`);
}

async function point(frame, selector, fx = .5, fy = .5, check = 'S3') {
  const box = await frame.locator(selector).boundingBox();
  must(box && box.width > 0 && box.height > 0, check, `${selector} is not reachable`);
  return { x: box.x + box.width * fx, y: box.y + box.height * fy, box };
}

async function touch(cdp, type, position, id = 1) {
  await cdp.send('Input.dispatchTouchEvent', { type, touchPoints: position ? [{ x: position.x, y: position.y, radiusX: 5, radiusY: 5, force: 1, id }] : [] });
}

async function touchTap(frame, cdp, selector, duration = 150, check = 'S4') {
  const p = await point(frame, selector, .5, .5, check);
  await touch(cdp, 'touchStart', p); await sleep(duration); await touch(cdp, 'touchEnd');
}

const focus = frame => frame.evaluate(() => document.activeElement?.id || document.activeElement?.tagName);
async function tabTo(page, frame, id, evidence, check = 'K1') {
  for (let i = 0; i < 14; i++) {
    const before = await focus(frame);
    if (before === id) return;
    await page.keyboard.press('Tab');
    const after = await focus(frame);
    evidence.tabs.push({ before, after });
    must(before !== 'canvas' || after !== 'canvas', check, 'Native Tab did not leave the focused canvas');
  }
  throw new ProofError(check, `Native Tab did not reach ${id}`);
}

async function living(page, frame, cdp, mobile, check, evidence) {
  const before = await state(frame, check);
  if (before.weapon !== 0) return before;
  const attempt = { before, action: mobile ? 'trusted touch FIRE to respawn' : 'mouse FIRE to respawn' };
  (evidence.respawns ||= []).push(attempt);
  const p = await point(frame, '#fire', .5, .5, check), pressed = Date.now();
  if (mobile) await touch(cdp, 'touchStart', p);
  else { await page.mouse.move(p.x, p.y); await page.mouse.down(); }
  try { attempt.after = await pollState(frame, s => s.weapon > 0, check, 'Normal FIRE did not respawn the dead native player', 3000); }
  finally { if (mobile) await touch(cdp, 'touchEnd'); else await page.mouse.up(); attempt.heldMs = Date.now() - pressed; }
  return attempt.after;
}

async function keyboardJourney(page, frame, evidence) {
  const check = 'K1'; evidence.tabs = [];
  must(await focus(frame) === 'canvas', check, 'START did not focus the game canvas');
  for (const id of ['fire', 'jump', 'weapon', 'arena', 'legal-link']) {
    await living(page, frame, null, false, check, evidence);
    await tabTo(page, frame, id, evidence);
    if (id === 'legal-link') break;
    const before = await state(frame, check);
    const action = evidence[id] = { before, focused: await focus(frame) };
    if (id === 'fire') {
      must(before.ammo > 0, check, 'Keyboard FIRE needs finite native ammunition');
      await page.keyboard.press('Enter');
      action.after = await pollState(frame, s => s.weapon === before.weapon && s.ammo < before.ammo, check, 'Enter on focused FIRE did not spend native ammunition');
    } else if (id === 'jump') {
      await page.keyboard.down('Space'); action.heldSamples = [];
      try { for (let i = 0; i < 8; i++) { await sleep(25); action.heldSamples.push(await state(frame, check)); } }
      finally { await page.keyboard.up('Space'); }
      must(action.heldSamples.every(s => s.z <= before.z + 2), check, 'Space on focused JUMP leaked into gameplay before its native click');
      action.after = await pollState(frame, s => s.z > before.z + 2, check, 'Space activation of focused JUMP did not raise the native player', 500);
    } else if (id === 'weapon') {
      await page.keyboard.press('Enter');
      action.after = await pollState(frame, s => s.weapon > 0 && s.weapon !== before.weapon, check, 'Enter on focused WEAPON did not change native weapon');
    } else {
      await page.keyboard.press('Enter');
      action.enter = await readyArena(frame, 'aggressor', check);
      await sleep(500); action.spaceBefore = await state(frame, check); action.heldSamples = [];
      await page.keyboard.down('Space');
      try { for (let i = 0; i < 8; i++) { await sleep(25); action.heldSamples.push(await state(frame, check)); } }
      finally { await page.keyboard.up('Space'); }
      must(action.heldSamples.every(s => s.map === action.spaceBefore.map), check, 'NEXT ARENA activated before native Space keyup');
      must(action.heldSamples.every(s => s.z <= action.spaceBefore.z + 2), check, 'Space on focused NEXT ARENA jumped the native player');
      action.space = await readyArena(frame, 'oa_minia', check);
      await page.keyboard.press('Enter'); action.returnMap = await readyArena(frame, 'oa_dm1', check);
    }
  }
  const reached = evidence.tabs.map(t => t.after);
  must(['fire', 'jump', 'weapon', 'arena', 'legal-link'].every(id => reached.includes(id)), check, 'Tab did not reach every active action and the legal link');
  await frame.locator('#canvas').click({ position: { x: 10, y: 10 } });
  must(await focus(frame) === 'canvas', check, 'A real canvas click did not return gameplay focus');
}

async function oldKeyboardWitness(page, frame, evidence) {
  const witness = evidence.regressionWitness = { focusSetup: 'DOM focus only to isolate native activation when Tab is trapped' };
  witness.tab = evidence.tabs.find(t => t.before === 'canvas' && t.after === 'canvas');
  must(witness.tab, 'MUTATION', 'Old handler did not independently witness trapped native Tab');
  await living(page, frame, null, false, 'MUTATION', evidence);
  await frame.locator('#arena').focus();
  witness.enter = { focused: await focus(frame), before: await state(frame, 'MUTATION') };
  await page.keyboard.press('Enter'); await sleep(500);
  witness.enter.after = await state(frame, 'MUTATION');
  must(witness.enter.focused === 'arena' && witness.enter.after.map === witness.enter.before.map && witness.enter.after.time > witness.enter.before.time, 'MUTATION', 'Old handler did not independently block native arena Enter while simulation advanced');
  await living(page, frame, null, false, 'MUTATION', evidence);
  await frame.locator('#arena').focus();
  witness.space = { focused: await focus(frame), before: await state(frame, 'MUTATION'), heldSamples: [] };
  await page.keyboard.down('Space');
  try { for (let i = 0; i < 20; i++) { await sleep(25); witness.space.heldSamples.push(await state(frame, 'MUTATION')); } }
  finally { await page.keyboard.up('Space'); }
  must(witness.space.focused === 'arena' && witness.space.heldSamples.some(s => s.weapon > 0 && s.z > witness.space.before.z + 2), 'MUTATION', 'Old handler did not independently forward focused arena Space as native jump');
  must(witness.space.heldSamples.every(s => s.map === witness.space.before.map), 'MUTATION', 'Old handler unexpectedly activated the arena while Space was held');
  witness.allThreeFailuresObserved = true;
}

async function actions(page, frame, cdp, mobile, check, evidence = {}) {
  const attempts = evidence.move = { attempts: [] };
  for (const direction of [{ key: 'w', dx: 0, dy: -1 }, { key: 'a', dx: -1, dy: 0 }, { key: 's', dx: 0, dy: 1 }, { key: 'd', dx: 1, dy: 0 }]) {
    const idleBefore = await living(page, frame, cdp, mobile, check, evidence); await sleep(250); const before = await state(frame, check);
    const idleDistance = Math.hypot(before.x - idleBefore.x, before.y - idleBefore.y);
    const attempt = { direction: direction.key.toUpperCase(), input: mobile ? 'CDP touch joystick' : 'keyboard', heldMs: 700, idleBefore, before, idleDistance };
    attempts.attempts.push(attempt);
    if (mobile) {
      const p = await point(frame, '#move', .5, .5, check);
      const end = { x: p.x + direction.dx * p.box.width * .35, y: p.y + direction.dy * p.box.height * .35 };
      attempt.touch = { start: { x: p.x, y: p.y }, end };
      await touch(cdp, 'touchStart', p);
      try { await touch(cdp, 'touchMove', end); await sleep(700); } finally { await touch(cdp, 'touchEnd'); }
    } else {
      await page.keyboard.down(direction.key);
      try { await sleep(700); } finally { await page.keyboard.up(direction.key); }
    }
    attempt.after = await state(frame, check);
    attempt.distance = Math.hypot(attempt.after.x - before.x, attempt.after.y - before.y);
    attempt.minimumDistance = Math.max(2, idleDistance * 3 + 1);
    attempt.accepted = attempt.distance > attempt.minimumDistance;
    if (attempt.accepted) { Object.assign(attempts, { before, after: attempt.after, distance: attempt.distance, idleDistance, direction: attempt.direction }); break; }
  }
  must(attempts.attempts.some(attempt => attempt.accepted), check, 'None of the four actual movement directions exceeded idle motion');
  const beforeMove = attempts.before;

  const beforeLook = await state(frame, check);
  const p = await point(frame, mobile ? '#look' : '#canvas', .45, .4, check);
  const destination = { x: p.x + Math.min(100, p.box.width * .25), y: p.y + Math.min(30, p.box.height * .1) };
  if (mobile) {
    await touch(cdp, 'touchStart', p);
    for (let step = 1; step <= 8; step++) { await touch(cdp, 'touchMove', { x: p.x + (destination.x - p.x) * step / 8, y: p.y + (destination.y - p.y) * step / 8 }); await sleep(20); }
    await touch(cdp, 'touchEnd');
  } else {
    await page.mouse.move(p.x, p.y); await page.mouse.down(); await page.mouse.move(destination.x, destination.y, { steps: 8 }); await sleep(160); await page.mouse.up();
  }
  const afterLook = await pollState(frame, s => Math.hypot(s.pitch - beforeLook.pitch, s.yaw - beforeLook.yaw) > .01, check, 'Drag did not turn the engine view');
  evidence.look = { before: beforeLook, after: afterLook };

  await sleep(500);
  const beforeShot = await living(page, frame, cdp, mobile, check, evidence);
  must(beforeShot.ammo > 0, check, 'A finite-ammo weapon is required to prove a shot');
  const fire = await point(frame, '#fire', .5, .5, check), shotSamples = [];
  if (mobile) await touch(cdp, 'touchStart', fire);
  else { await page.mouse.move(fire.x, fire.y); await page.mouse.down(); }
  try { for (let i = 0; i < 64 && (i < 9 || !shotSamples.some(s => s.weapon === beforeShot.weapon && s.ammo < beforeShot.ammo)); i++) { await sleep(25); shotSamples.push(await state(frame, check)); } }
  finally { if (mobile) await touch(cdp, 'touchEnd'); else await page.mouse.up(); }
  const afterShot = shotSamples.find(s => s.weapon === beforeShot.weapon && s.ammo < beforeShot.ammo);
  evidence.shot = { before: beforeShot, after: afterShot, heldSamples: shotSamples };
  must(afterShot, check, 'Fire did not spend engine ammunition while held');
  must(afterShot.time > beforeMove.time, check, 'Engine simulation time did not advance');
  if (!mobile) {
    const before = await living(page, frame, cdp, mobile, check, evidence);
    must(before.ammo > 0, check, 'Focused canvas F needs finite native ammunition');
    await frame.locator('#canvas').click({ position: { x: 10, y: 10 } }); await page.keyboard.down('f');
    try { evidence.canvasFire = { before, after: await pollState(frame, s => s.weapon === before.weapon && s.ammo < before.ammo, check, 'Focused canvas F did not spend native ammunition') }; }
    finally { await page.keyboard.up('f'); }
  }

  const beforeJump = await living(page, frame, cdp, mobile, check, evidence);
  if (mobile) await touch(cdp, 'touchStart', await point(frame, '#jump', .5, .5, check));
  else { await frame.locator('#canvas').click({ position: { x: 10, y: 10 } }); await page.keyboard.down('Space'); }
  const samples = [];
  try { for (let i = 0; i < 12; i++) { await sleep(25); samples.push(await state(frame, check)); } }
  finally { if (mobile) await touch(cdp, 'touchEnd'); else await page.keyboard.up('Space'); }
  must(samples.some(s => s.z > beforeJump.z + 2), check, `${mobile ? 'Touch' : 'Focused canvas Space'} jump did not raise the engine player`);
  evidence.jump = { before: beforeJump, maximumZ: Math.max(...samples.map(s => s.z)), samples };
  const beforeWeapon = await living(page, frame, cdp, mobile, check, evidence);
  let afterWeapon;
  if (mobile) await touch(cdp, 'touchStart', await point(frame, '#weapon', .5, .5, check));
  else { await frame.locator('#canvas').click({ position: { x: 10, y: 10 } }); await page.keyboard.down('e'); }
  try { afterWeapon = await pollState(frame, s => s.weapon > 0 && s.weapon !== beforeWeapon.weapon, check, `${mobile ? 'Touch' : 'Focused canvas E'} did not change the engine weapon`); }
  finally { if (mobile) await touch(cdp, 'touchEnd'); else await page.keyboard.up('e'); }
  evidence.weapon = { before: beforeWeapon, after: afterWeapon };
  return evidence;
}

async function readyArena(frame, map, check = 'S2') {
  try { await frame.waitForFunction(expected => { const s = window.play.state(); return s.ready === true && s.map === `maps/${expected}.bsp` && s.botCount === 2; }, map, { timeout }); }
  catch (error) { throw new ProofError(check, `NEXT ARENA did not yield ready ${map} with two bots: ${error.message}`); }
  return state(frame, check);
}

async function arenaTransitions(page, frame, name, transitions = [], { mobile = false, cdp = null } = {}) {
  for (const map of mobile ? ['aggressor'] : ['aggressor', 'oa_minia', 'oa_dm1']) {
    const transition = { expectedMap: map, before: await state(frame, 'S2'), action: mobile ? 'trusted touch NEXT ARENA' : 'NEXT ARENA button click' };
    transitions.push(transition);
    must(transition.before.botCount === 2, 'S2', 'Map cycle began without exactly two active engine bots');
    if (mobile) await touchTap(frame, cdp, '#arena', 100, 'S2'); else await frame.locator('#arena').click();
    transition.readyState = await readyArena(frame, map);
    await sleep(1500);
    transition.settledState = await state(frame, 'S2');
    must(transition.settledState.map === `maps/${map}.bsp` && transition.settledState.botCount === 2, 'S2', `Map ${map} changed or duplicated its bots after loading`);
    must(transition.settledState.time > transition.readyState.time, 'S2', `Simulation did not advance on ${map}`);
    transition.layout = await layout(page, frame);
    transition.screenshot = `${name}-arena-${map}.png`;
    await page.screenshot({ path: path.join(output, transition.screenshot), scale: 'css' });
  }
  return transitions;
}

async function layout(page, frame, viewport) {
  if (viewport) {
    await page.setViewportSize(viewport);
    await frame.waitForFunction(() => {
      const c=document.getElementById('canvas'),r=c.getBoundingClientRect();
      const d=Math.min(devicePixelRatio||1,2),w=Math.min(innerWidth,innerHeight*16/9),h=w*9/16;
      return Math.abs(r.width-w)<1 && Math.abs(r.height-h)<1 && c.width===Math.max(320,Math.round(w*d)) && c.height===Math.max(180,Math.round(h*d));
    }, null, {timeout:15000});
  }
  const measurement = await frame.evaluate(() => {
    const canvas = document.getElementById('canvas'); const r = canvas.getBoundingClientRect();
    return { width: innerWidth, height: innerHeight, x: r.x, y: r.y, canvasWidth: r.width, canvasHeight: r.height, bufferWidth: canvas.width, bufferHeight: canvas.height, dpr: devicePixelRatio };
  });
  log('LAYOUT',measurement);
  const rendering=await frame.evaluate(()=>window.__frameRender());
  must(rendering.webgl && !rendering.contextLost && rendering.width>0 && rendering.height>0,'S2','Renderer is unavailable after a resize or map change');
  measurement.rendering=rendering;
  const m = measurement;
  must(m.canvasWidth > 0 && m.canvasHeight > 0 && m.x >= -1 && m.y >= -1 && m.x + m.canvasWidth <= m.width + 1 && m.y + m.canvasHeight <= m.height + 1, 'S1', 'Canvas escapes the frame or is empty');
  must(Math.abs(m.canvasWidth - m.width) <= 2 || Math.abs(m.canvasHeight - m.height) <= 2, 'S1', 'Canvas does not fill either frame dimension');
  must(Math.abs((m.bufferWidth / m.bufferHeight) / (m.canvasWidth / m.canvasHeight) - 1) < .02, 'S1', 'Canvas rendering is stretched');
  must(m.bufferWidth <= m.canvasWidth * 2 + 2 && m.bufferHeight <= m.canvasHeight * 2 + 2, 'S1', 'Canvas exceeds the DPR cap of 2');
  return measurement;
}

let siteServer, hostServer, browserServer, browser;
let siteOrigin, hostOrigin;
async function scenario(name, { mobile = false, viewport = { width: 1280, height: 720 }, denyStorage = false, storageMethods = false, lateStorage = false, expectedFailure = null } = {}) {
  const entry = { name, viewport, mobile, denyStorage, storageMethods, lateStorage, checks: {}, requests: [], otherOriginRequests: [], wasmResponses: [], console: [], pageErrors: [], status: 'FAIL' };
  report.scenarios.push(entry);
  const context = await browser.newContext({ viewport, deviceScaleFactor: 3, hasTouch: mobile, isMobile: mobile, serviceWorkers: 'block' });
  await context.addInitScript(instrument, { denyStorage, storageMethods, lateStorage });
  const page = await context.newPage();
  let nativeDialogs = 0, actualWorkers = 0;
  page.on('dialog', async dialog => { nativeDialogs++; await dialog.dismiss(); });
  page.on('worker', () => actualWorkers++);
  page.on('console', message => { if (entry.console.length < 600) entry.console.push({ type: message.type(), text: message.text() }); if(message.type()==='error' || message.text().startsWith('GL_SHADER_FAILURE'))log(`CONSOLE ${name}`,message.text()); });
  page.on('pageerror', error => entry.pageErrors.push(error.message));
  context.on('request', request => { entry.requests.push({ url: request.url(), method: request.method() }); });
  context.on('response', async response => { if (new URL(response.url()).pathname.endsWith('.wasm')) entry.wasmResponses.push({ url: response.url(), status: response.status(), contentType: await response.headerValue('content-type') }); });
  await context.route('**/*', async route => {
    const request = route.request(); const url = new URL(request.url());
    let fromMain = false; try { fromMain = request.frame() === page.mainFrame(); } catch (_) {}
    const allowed = url.origin === siteOrigin || (fromMain && url.origin === hostOrigin);
    if (!allowed) { entry.otherOriginRequests.push(request.url()); await route.abort(); } else await route.continue();
  });
  const startTime = Date.now();
  try {
    await page.goto(`${hostOrigin}/frame`, { waitUntil: 'domcontentloaded', timeout });
    const iframe = page.locator('iframe');
    must((await iframe.getAttribute('sandbox')) === 'allow-scripts allow-same-origin' && (await iframe.getAttribute('allow')) === null, 'S1', 'Embedding frame contract differs');
    const frame = await (await iframe.elementHandle()).contentFrame();
    must(frame, 'S1', 'Embedding frame has no document');
    await frame.waitForURL(`${siteOrigin}${prefix}index.html`, { timeout });
    must(frame && new URL(frame.url()).origin === siteOrigin && frame.url().includes(prefix), 'S1', 'Page is not under a cross-origin path prefix');
    await frame.locator('#start').waitFor({ state: 'visible', timeout });
    await frame.waitForFunction(() => document.getElementById('start').disabled === false, null, { timeout });
    entry.firstLoadToStartScreenMs = Date.now() - startTime;
    await page.screenshot({ path: path.join(output, `${name}-start.png`), scale: 'css' });
    entry.checks.S1 = { status: 'PASS', crossOrigin: true, prefix, noAllowAttribute: true };
    const cdp = mobile ? await context.newCDPSession(page) : null;
    const gameStartTime = Date.now();
    entry.startInput = mobile ? 'trusted touch' : name === 'storage-denied' ? 'native Tab and Enter' : 'mouse';
    if (mobile) await touchTap(frame, cdp, '#start', 100, 'S2');
    else if (name === 'storage-denied') {
      entry.startTabs = [];
      for (let i = 0; i < 8 && await focus(frame) !== 'start'; i++) { await page.keyboard.press('Tab'); entry.startTabs.push(await focus(frame)); }
      must(await focus(frame) === 'start', 'S2', 'Native Tab did not reach START');
      await page.keyboard.press('Enter');
    } else await frame.locator('#start').click();
    try { await frame.waitForFunction(() => window.play?.ready === true && window.play.state().ready === true && Boolean(window.play.state().map), null, { timeout }); } catch (error) { throw new ProofError('S2', `One START action did not produce a ready match: ${error.message}`); }
    await sleep(1500);
    entry.initialState = await state(frame, 'S2');
    entry.rendering = await frame.evaluate(() => ({...window.__frameRender(),contextLosses:window.__frameProof.contextLosses}));
    must(entry.rendering.webgl && !entry.rendering.contextLost && entry.rendering.contextLosses===0,'S2','Renderer has lost its WebGL context');
    must(entry.initialState.botCount === 2, 'S2', 'Match does not have exactly two active engine bots');
    entry.startToMatchMs = Date.now() - gameStartTime;
    entry.checks.S2 = { status: 'PASS', state: entry.initialState, starts: 1, input: entry.startInput };
    if (denyStorage) {
      if (lateStorage) await frame.evaluate(() => window.__storageProof.install());
      entry.storageBeforeActions = await frame.evaluate(() => window.__storageProof.receipt());
      must(entry.storageBeforeActions.every(probe => probe.denied), 'S6', 'Configured storage denial was not active before gameplay actions');
    }
    if (expectedFailure === 'S5') {
      const earlyEffects = await frame.evaluate(() => ({ ...window.__frameProof }));
      for (const key of ['pointerLock', 'fullscreen', 'dialogs', 'windowOpen', 'serviceWorkers', 'workers', 'sockets', 'cookieWrites']) must(earlyEffects[key] === 0, 'S5', `${key} has ${earlyEffects[key]} calls at START`);
      must(entry.otherOriginRequests.length === 0, 'S5', `Requests escaped the page origin: ${entry.otherOriginRequests.join(', ')}`);
    }
    const keyboardControl = !mobile && (name === 'desktop' || name === 'storage-denied' || expectedFailure === 'K1');
    if (keyboardControl) {
      entry.keyboard = {};
      try { await keyboardJourney(page, frame, entry.keyboard); }
      catch (error) { if (expectedFailure === 'K1' && error.check === 'K1') await oldKeyboardWitness(page, frame, entry.keyboard); throw error; }
    }
    entry.actions = {};
    await actions(page, frame, cdp, mobile, mobile ? 'S4' : 'S3', entry.actions);
    entry.checks[mobile ? 'S4' : 'S3'] = { status: 'PASS', evidence: entry.actions };
    entry.layouts = [await layout(page, frame)];
    if (name === 'desktop') for (const dimensions of [{ width: 320, height: 240 }, { width: 240, height: 320 }, { width: 1920, height: 1080 }, { width: 1080, height: 1920 }, viewport]) entry.layouts.push(await layout(page, frame, dimensions));
    if (name === 'desktop') { entry.arenas = []; await arenaTransitions(page, frame, name, entry.arenas); }
    if (mobile) { entry.arenas = []; await arenaTransitions(page, frame, name, entry.arenas, { mobile, cdp }); }
    entry.counters = await frame.evaluate(() => ({ ...window.__frameProof }));
    entry.counters.nativeDialogs = nativeDialogs; entry.counters.actualWorkers = actualWorkers;
    for (const key of ['contextLosses', 'pointerLock', 'fullscreen', 'dialogs', 'nativeDialogs', 'windowOpen', 'serviceWorkers', 'workers', 'actualWorkers', 'sockets', 'cookieWrites']) must(entry.counters[key] === 0, 'S5', `${key} has ${entry.counters[key]} calls`);
    must(entry.otherOriginRequests.length === 0, 'S5', `Requests escaped the page origin: ${entry.otherOriginRequests.join(', ')}`);
    must(entry.wasmResponses.every(r => r.status === 200 && r.contentType?.startsWith('text/plain')), 'S1', '.wasm was not served completely with the deliberately wrong MIME type');
    entry.checks.S5 = { status: 'PASS', counters: entry.counters, otherOriginRequests: 0 };
    if (denyStorage) {
      const denied = await frame.evaluate(() => window.__storageProof.receipt());
      must(denied.every(probe => probe.denied), 'S6', 'The denied-storage environment is not active after gameplay actions');
      entry.checks.S6 = { status: 'PASS', boundary: storageMethods ? 'methods' : 'properties', installed: lateStorage ? 'after boot' : 'before boot', before: entry.storageBeforeActions, after: denied, state: await state(frame, 'S6') };
    }
    must(entry.pageErrors.length === 0, 'S2', `Uncaught page errors: ${entry.pageErrors.join('; ')}`);
    await page.screenshot({ path: path.join(output, `${name}-playing.png`), scale: 'css' });
    if (keyboardControl) {
      await legalJourney(page, frame, entry, { keyboard: true });
      entry.checks.K1 = { status: 'PASS', evidence: entry.keyboard, legal: entry.legalKeyboard };
    }
    if (name === 'desktop') {
      await frame.locator('#start').click();
      try { await frame.waitForFunction(() => { const s = window.play?.state(); return window.play?.ready === true && s.ready === true && s.botCount === 2; }, null, { timeout }); }
      catch (error) { throw new ProofError('S2', `Legal return did not permit the next START: ${error.message}`); }
      entry.legalRestart = await state(frame, 'S2');
      await legalJourney(page, frame, entry);
    }
    if (mobile) await legalJourney(page, frame, entry, { mobile, cdp });
    entry.status = 'PASS';
    must(!expectedFailure, 'MUTATION', `${expectedFailure} mutant survived`);
    log(`PASS ${name}`, { checks: Object.keys(entry.checks), firstLoadToStartScreenMs: entry.firstLoadToStartScreenMs });
  } catch (error) {
    entry.failure = { check: error.check || 'HARNESS', message: error.message };
    await page.screenshot({ path: path.join(output, `${name}-failure.png`), scale: 'css' }).catch(() => {});
    if (expectedFailure && error.check === expectedFailure) { entry.status = 'EXPECTED_FAIL'; log(`PASS MUTATION ${name}`, entry.failure); }
    else { log(`FAIL ${name}`, entry.failure); throw error; }
  } finally { await context.close(); }
  return entry;
}

async function siteManifest(directory=site, prefix='') {
  const entries=await readdir(directory,{withFileTypes:true});let files=[];
  for(const entry of entries.sort((a,b)=>a.name.localeCompare(b.name))) {
    const name=prefix+entry.name;
    if(entry.isDirectory())files.push(...await siteManifest(path.join(directory,entry.name),name+'/'));
    else files.push(name);
  }
  if(prefix)return files;
  const {stdout}=await command('shasum',['-a','256',...files],{cwd:site});
  return stdout.trim().split('\n').map(line=>({sha256:line.slice(0,64),name:line.slice(66)}));
}

async function legalJourney(page, frame, entry, { mobile = false, cdp = null, keyboard = false } = {}) {
  if (keyboard) { await tabTo(page, frame, 'legal-link', entry.keyboard); await page.keyboard.press('Enter'); }
  else if (mobile) await touchTap(frame, cdp, '#legal-link', 100, 'S4');
  else await frame.locator('#legal-link').click();
  const check = keyboard ? 'K1' : 'S1';
  try { await frame.waitForURL(`${siteOrigin}${prefix}legal/`, {timeout}); }
  catch (error) { throw new ProofError(check, `Focused legal action did not navigate inside the frame: ${error.message}`); }
  must((await frame.locator('h1').textContent()).includes('licences and source'),check,'Legal page did not open in the frame');
  const links=await frame.locator('a').evaluateAll(nodes=>nodes.map(a=>a.getAttribute('href')));
  const result = entry[keyboard ? 'legalKeyboard' : 'legal'] = {status:'PASS',input:keyboard ? 'native Tab and Enter' : mobile ? 'trusted touch' : 'mouse',url:frame.url(),files:[]};
  for(const href of links.filter(h=>h!=='../')) {
    const url=new URL(href,frame.url());
    must(url.origin===siteOrigin,'S5','Legal link escaped the page origin');
    const response=await fetch(url,{method:'HEAD'});
    must(response.status===200,'S1',`Missing legal/source file ${href}`);
    result.files.push({href,status:response.status,bytes:Number(response.headers.get('content-length'))});
  }
  if (keyboard) {
    result.returnTabs = [];
    for (let i = 0; i < 20 && !await frame.evaluate(() => document.activeElement?.getAttribute('href') === '../'); i++) { await page.keyboard.press('Tab'); result.returnTabs.push(await focus(frame)); }
    must(await frame.evaluate(() => document.activeElement?.getAttribute('href') === '../'), check, 'Native Tab did not reach the legal return link');
    await page.keyboard.press('Enter');
  } else if (mobile) await touchTap(frame, cdp, 'a[href="../"]', 100, 'S4');
  else await frame.locator('a[href="../"]').click();
  await frame.locator('#start').waitFor({state:'visible',timeout});
  result.returnToStart=true;
}

let cleanupPromise;
function cleanup() {
  return cleanupPromise ||= (async () => {
    await browser?.close().catch(error => log('CLEANUP browser connection', { error: error.message }));
    await browserServer?.close().catch(error => log('CLEANUP browser', { error: error.message }));
    await closeServer(hostServer); await closeServer(siteServer);
    report.runtime.serversClosed = !hostServer?.listening && !siteServer?.listening;
    if (report.runtime.browserPid) { try { process.kill(report.runtime.browserPid, 0); report.runtime.browserStopped = false; } catch (error) { report.runtime.browserStopped = error.code === 'ESRCH'; } }
    if (!report.runtime.serversClosed || report.runtime.browserStopped === false) { report.status = 'FAIL'; process.exitCode = 1; log('FAIL CLEANUP', report.runtime); }
  })();
}
for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => { process.exitCode = signal === 'SIGINT' ? 130 : 143; log('INTERRUPTED', { signal }); void cleanup(); });

async function mutate(kind, transformed, expectedFailure, original) {
  const file = path.join(site, 'frame.js');
  try {
    await writeFile(file, transformed);
    const result = await scenario(`mutation-${kind}`, { expectedFailure });
    report.mutations.push({ kind, healthyControl: 'desktop', expectedFailure, witnessedFailure: result.failure, status: 'PASS' });
  } finally {
    await writeFile(file, original);
    must((await readFile(file)).equals(original), 'MUTATION', `Byte restoration failed after ${kind}`);
    log(`RESTORED ${kind}`, { byteForByte: true, bytes: original.length });
  }
}

await mkdir(output, { recursive: true });
try {
  report.subject={gitHead:(await command('git',['rev-parse','HEAD'],{cwd:repo})).stdout.trim(),siteFiles:await siteManifest()};
  siteServer = http.createServer(async (request, response) => {
    try {
      const pathname = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname);
      if (!pathname.startsWith(prefix) || !['GET', 'HEAD'].includes(request.method)) throw Error('Not found');
      const file = path.resolve(site, (pathname.slice(prefix.length) || '') + (pathname.endsWith('/') ? 'index.html' : ''));
      if (!file.startsWith(`${site}${path.sep}`)) throw Error('Not found');
      const info=await stat(file);
      const bytes=request.method==='HEAD' ? null : await readFile(file);
      response.writeHead(200, { 'content-type': mime(file), 'content-length': info.size, 'cache-control': 'no-store' });
      response.end(bytes ?? undefined);
    } catch (_) { response.writeHead(404); response.end('Not found'); }
  });
  siteOrigin = await listen(siteServer);
  hostServer = http.createServer((request, response) => {
    if (request.url !== '/frame') { response.writeHead(404); return response.end('Not found'); }
    response.writeHead(200, { 'content-type': 'text/html', 'cache-control': 'no-store' });
    response.end(`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="data:,"><style>html,body{margin:0;width:100%;height:100%;overflow:hidden}iframe{display:block;border:0;width:100%;height:100%}</style><iframe sandbox="allow-scripts allow-same-origin" src="${siteOrigin}${prefix}index.html"></iframe>`);
  });
  hostOrigin = await listen(hostServer);
  report.runtime.siteOrigin = siteOrigin; report.runtime.hostOrigin = hostOrigin;
  const rangeResponse = await fetch(`${siteOrigin}${prefix}index.html`, { headers: { Range: 'bytes=0-15' } });
  const bytes = await rangeResponse.arrayBuffer();
  must(rangeResponse.status === 200 && !rangeResponse.headers.has('content-range') && bytes.byteLength === (await stat(path.join(site, 'index.html'))).size, 'S1', 'Static proof server unexpectedly supports Range');
  report.server = { bind: '127.0.0.1', rangeRequestStatus: rangeResponse.status, rangeFullBytes: bytes.byteLength, wasmMime: 'text/plain', prefix };
  const executablePath = process.env.CHROMIUM_PATH || process.env.PROOF_CHROMIUM;
  browserServer = await chromium.launchServer({ headless: true, host: '127.0.0.1', port: 0, ...(executablePath ? { executablePath } : {}), args: ['--disable-gpu', '--use-gl=angle', '--use-angle=swiftshader-webgl', '--enable-unsafe-swiftshader', '--disable-background-networking', '--disable-component-update', '--no-first-run'] });
  report.runtime.browserPid = browserServer.process().pid;
  await writeFile(path.join(output,'owned-pids.json'),JSON.stringify(report.runtime,null,2)+'\n');
  log('OWNED PIDS', report.runtime);
  browser = await chromium.connect(browserServer.wsEndpoint());
  await scenario('desktop');
  await scenario('touch-portrait', { mobile: true, viewport: { width: 390, height: 844 } });
  await scenario('touch-landscape', { mobile: true, viewport: { width: 844, height: 390 } });
  await scenario('storage-denied', { denyStorage: true });
  await scenario('storage-boot-method', { denyStorage: true, storageMethods: true });
  await scenario('storage-late-property', { denyStorage: true, lateStorage: true });
  await scenario('storage-late-method', { denyStorage: true, storageMethods: true, lateStorage: true });
  const original = await readFile(path.join(site, 'frame.js')); const text = original.toString('utf8');
  must(text.split(inputMarker).length === 2, 'MUTATION', 'Input mutation marker must occur exactly once');
  must(inputMarker.includes('if (!active) return;'), 'MUTATION', 'Input mutation marker does not contain the central guard');
  must(text.split(pointerMarker).length === 2, 'MUTATION', 'START mutation marker must occur exactly once');
  await mutate('input-disabled', Buffer.from(text.replace(inputMarker, inputMarker.replace('if (!active) return;', 'return; /* PROOF input-disabled mutant */'))), 'S3', original);
  await mutate('pointer-lock', Buffer.from(text.replace(pointerMarker, `document.getElementById('canvas').requestPointerLock(); ${pointerMarker}`)), 'S5', original);
  await mutate('off-origin', Buffer.from(text.replace(pointerMarker, `fetch('https://proof.invalid/off-origin').catch(()=>{}); ${pointerMarker}`)), 'S5', original);
  const previous = (await command('git', ['show', `${baseHead}:site/frame.js`], { cwd: repo })).stdout;
  const keyboardBlock = source => {
    const opening = "for(const name of ['keydown','keyup'])", start = source.indexOf(opening), end = source.indexOf('\nfunction move(', start);
    must(start >= 0 && end > start && source.indexOf(opening, start + 1) === -1, 'MUTATION', 'The exact keyboard handler region is ambiguous');
    return { start, end, text: source.slice(start, end) };
  };
  const currentHandler = keyboardBlock(text), previousHandler = keyboardBlock(previous);
  must(currentHandler.text !== previousHandler.text, 'MUTATION', 'Keyboard regression mutation has no changed handler to restore');
  await mutate('old-key-handler', Buffer.from(text.slice(0, currentHandler.start) + previousHandler.text + text.slice(currentHandler.end)), 'K1', original);
  report.mutations.at(-1).restoredHandlerSource = { gitHead: baseHead, path: 'site/frame.js', exactHandler: previousHandler.text };
  report.status = 'PASS';

} catch (error) {
  report.failure = { check: error.check || 'HARNESS', message: error.message, stack: error.stack };
  log('FAIL PROOF', report.failure); process.exitCode = 1;
} finally {
  await cleanup();
  if(report.subject){
    report.subject.unchanged=JSON.stringify(report.subject.siteFiles)===JSON.stringify(await siteManifest());
    if(!report.subject.unchanged){report.status='FAIL';process.exitCode=1;log('FAIL ARTIFACT','Static files changed during proof');}
  }
  if(report.status==='PASS') for(const check of ['S1','S2','S3','S4','S5','S6','K1'])log(`PASS ${check}`);
  report.finished = new Date().toISOString();
  await writeFile(path.join(output, 'report.json'), `${JSON.stringify(report, null, 2)}\n`);
  await writeFile(path.join(output, 'run.log'), `${lines.join('\n')}\n`);
}
