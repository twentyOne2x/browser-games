#!/usr/bin/env python3
"""Refresh verified round-one corresponding sources. GPL-2.0.

Run with the extracted original source trees inside .lane/source-input.
Original game-code source is retained unchanged in site/legal.
"""
import gzip,json,shutil,subprocess,tarfile
from pathlib import Path
R=Path(__file__).resolve().parent;W=R/'.lane/source-input';legal=R/'site/legal'
def digest(p):return subprocess.check_output(['shasum','-a','256',str(p)],text=True).split()[0]
def normalized(info):
 info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;return info

def archive(target,items):
 with target.open('wb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
  for source,name in items:tar.add(source,arcname=name,filter=normalized)
 print(digest(target),target.name,target.stat().st_size,flush=True)
source_root=W/'openarena-media-source'
source=json.loads((source_root/'MANIFEST.json').read_text())
quote="The program and data are licensed under the GNU GPL v2. See the file 'COPYING' for details."
for row in source['sources']:
 data=(source_root/row['path']).read_bytes()
 if b'GNU GENERAL PUBLIC LICENSE' in data[:200] and b'Version ' in data[:200]:
  version='3' if b'Version 3,' in data[:200] else '2'
  row.update(licence=f'GPL-{version}.0 licence document',licence_sentence='Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.')
 else:row.update(licence='GPL-2.0',licence_sentence=quote)
(source_root/'MANIFEST.json').write_text(json.dumps(source,indent=2)+'\n')
archive(legal/'media-source.tgz',[(source_root,'openarena-media-source')])
engine_root=W/'ioquake3-source'
# Retain two upstream files omitted by the imported Git bundle.
shutil.copytree(R/'engine',engine_root/'engine',dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git'))
for name in ['build-engine.sh','engine.patch','prepare-data.py','source-download.py','pack-sources.py','SHELL-LICENSE.txt','REPRODUCE.txt','README-HOST.md','DECISION.md','package.json','package-lock.json']:
 shutil.copy2(R/name,engine_root/'adaptation'/name)
for name in ['index.html','frame.js','style.css']:shutil.copy2(R/'site'/name,engine_root/'adaptation/site'/name)
for name in ['run.sh','run.mjs','README.md']:shutil.copy2(R/'proof'/name,engine_root/'adaptation/proof'/name)
archive(legal/'engine-source.tgz',[(engine_root,'ioquake3-source')])
receipts={name:{'bytes':(legal/name).stat().st_size,'sha256':digest(legal/name)} for name in ['engine-source.tgz','gamecode-source.tgz','media-source.tgz']}
provenance=json.loads((R/'PROVENANCE.json').read_text())
provenance['source_artifacts']=receipts
provenance['runtime_artifacts']={name:{'bytes':(R/'site'/name).stat().st_size,'sha256':digest(R/'site'/name)} for name in ['ioquake3.wasm','ioquake3.js']}
(R/'PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
marker='\n## Browser fix corresponding-source receipts\n'
data=(R/'DATA.md').read_text().split(marker)[0]
data+=marker+'\nFirst engine change and fix notice date: 2026-10-11. All retained data member bytes and grants remain unchanged.\n\n'
for name,row in receipts.items():data+=f"{name}: {row['bytes']} bytes, SHA256 {row['sha256']}.\n\n"
(R/'DATA.md').write_text(data);(legal/'DATA.md').write_text(data)
source_text=(legal/'SOURCE.txt').read_text().split('DELIVERED SOURCE ARTIFACT HASHES\n')[0]
source_text+='DELIVERED SOURCE ARTIFACT HASHES\n'
for name,row in receipts.items():source_text+=f"{row['sha256']}  {name} ({row['bytes']} bytes)\n"
source_text+='\nCORRECTED ENGINE BUILD\nThe five notices are comment-only. Same-path builds with and without the notices\nproduced byte-identical WASM and JavaScript. Source archive hashes are not compiler\ninputs. This delivery includes a fresh pinned build from the corrected source.\n'
for name,row in provenance['runtime_artifacts'].items():source_text+=f"{row['sha256']}  ../{name} ({row['bytes']} bytes)\n"
(legal/'SOURCE.txt').write_text(source_text)
files=[p for p in (R/'site').rglob('*') if p.is_file()];size=sum(p.stat().st_size for p in files)
print(json.dumps({'site_bytes':size,'site_files':len(files),'largest_file':max(p.stat().st_size for p in files)},indent=2))
if size>150000000 or any(p.stat().st_size>90000000 for p in files):raise SystemExit('HOST SIZE REFUSED')
