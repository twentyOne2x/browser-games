#!/usr/bin/env python3
"""Plan or fetch official SVN951 preferred media sources for the retained OA0.8.8 subset."""
import argparse, concurrent.futures, hashlib, html, json, re, tarfile, urllib.parse, urllib.request
from pathlib import Path
P=argparse.ArgumentParser();P.add_argument('--fetch',action='store_true');P.add_argument('--max-bytes',type=int,default=300000000);a=P.parse_args()
R=Path(__file__).resolve().parent;W=R.parent if (R/'site').is_dir() else R;repo=R if (R/'site').is_dir() else R/'repo';B='https://openarena.ws/svn/!svn/bc/951/'
cache=W/'source-metadata';cache.mkdir(exist_ok=True)
rows=json.loads((repo/'site/legal/DATA.json').read_text());names={r['name'] for r in rows}
actual_maps={Path(n).stem for n in names if n.startswith('maps/') and n.endswith('.bsp')}
if a.fetch and actual_maps!={'oa_dm1','aggressor','oa_minia'}:raise SystemExit('SOURCE INPUT REFUSED: regenerate DATA.json for oa_dm1, aggressor, oa_minia before fetch')
image_stems={Path(n).stem.lower() for n in names if n.endswith(('.tga','.jpg','.png'))}
texture_dirs={n.split('/')[1] for n in names if n.startswith('textures/')}
excluded={'angelyss','arachna','assassin','beret','dmo','gangter','hnt','hoppy','kyonshi','major','merman','neko','penguin','skelebot','slshish','sorceress','spacemrn'}
if not any(n.startswith('models/mapobjects/gargoyle/') for n in names):excluded.add('gargoyle')
if not any(n.startswith('models/mapobjects/kit89-models/liz-statue/') for n in names):excluded.add('liz')
aliases={'wood1','fx_lum','firefx','func_waterfall','rootssource','waterfall1','waterfall2','waterriples1','moon','moon2','plate-1','p-rust','p_rustblack','met-sup','met-wall','smoke','spark','steam01','torch','sky','sky_base1','topclouds'}
def url(path):return B+urllib.parse.quote(path,safe='/!+()')
def links(path):
 p=cache/(path.replace('/','_')+'index.html')
 if not p.exists():
  with urllib.request.urlopen(url(path),timeout=30) as r:b=r.read(300001)
  if len(b)>300000:raise RuntimeError('Oversize source directory index '+path)
  p.write_bytes(b)
 s=p.read_text();out=[]
 for raw in re.findall(r'<a href="([^"]+)"',s):
  n=urllib.parse.unquote(html.unescape(raw))
  if n in ('../','./') or '/' in n.rstrip('/') or n.startswith(('http:','https:')):continue
  out.append(path+n)
 return out
def walk(path):
 out=[]
 for n in links(path):out.extend(walk(n) if n.endswith('/') else [n])
 return out
chosen={'COPYING','CREDITS','README','source/assets/COPYING','source/assets/models/README','source/assets/maps/gpl.txt','source/assets/maps/license.txt','source/assets/maps/credits'}
for m in ('oa_dm1','oa_dm1v2','aggressor','oa_minia'):chosen.add('source/assets/maps/'+m+'.map')
model_dirs={'grism','bubble','invis','orb','lightninggun','newarmor','newbfg','newbulcase','newgauntlet','newgib','newgibs','newgren','newhealth','newmgun','newmuz','newplas','newplasrailhit','newquad','newrail','newrock','newshelcase','newsparkness','newtele','powerups','projectiles','proxmine','shotgun','teleporter','vulcan','missionpack'}
if any(n.startswith('models/dpoints/') for n in names):model_dirs.add('dpoint')
if any(n.startswith('models/flags/') for n in names):model_dirs.update({'newflag','newerflag'})
if 'models/mapobjects/banner/banner5.md3' in names:model_dirs.add('newoalogo')
if any(n.startswith('models/mapobjects/flagbase/') for n in names):
 for color in ('blue','neutral','red'):chosen.add('source/assets/models/flagbase-'+color+'.map')
for n in links('source/assets/models/'):
 top=n.rstrip('/').split('/')[-1]
 if top in model_dirs or top=='README':chosen.update(walk(n) if n.endswith('/') else [n])
chosen.update(f for f in walk('source/assets/2d/') if not f.endswith('noise.wavelets'))
if any(n.startswith('music/') for n in names):chosen.update(walk('source/assets/music/'))
chosen.update(walk('source/assets/sound/'))
for n in links('source/assets/textures/'):
 top=n.rstrip('/').split('/')[-1]
 branch=walk(n) if n.endswith('/') else [n]
 for f in branch:
  stem=Path(f).name.lower().split('.',1)[0]
  if stem in image_stems or (top in texture_dirs|{'acc','clown'} and stem in aliases):chosen.add(f)
cached_heads={r['path']:r for r in json.loads((W/'licence-evidence/broad-source-plan.json').read_text())['sources']} if (W/'licence-evidence/broad-source-plan.json').exists() else {}
def head(path):
 if path in cached_heads:return dict(cached_heads[path])
 with urllib.request.urlopen(urllib.request.Request(url(path),method='HEAD'),timeout=30) as r:h=dict(r.headers)
 if 'Content-Length' not in h:raise RuntimeError('Source size absent '+path)
 return {'path':path,'url':url(path),'bytes':int(h['Content-Length']),'etag':h.get('ETag'),'last_modified':h.get('Last-Modified')}
print('SOURCE PLAN metadata only',len(chosen),'files',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:plan=list(ex.map(head,sorted(chosen)))
total=sum(r['bytes'] for r in plan)
report={'source_maps':['oa_dm1','aggressor','oa_minia'],'svn_revision':951,'data_sha256':'5a8faf7f5b51f351b0a1618c06b6b98a5f1a6758f1d39818de2c87df2a0bac4a','files':len(plan),'download_bytes':total,'sources':plan,'retained_data_files':len(rows),'note':'Official media preferred sources. dm1 variant preserved because upstream release does not map its BSP to a unique source filename. Original flat WAV/TGA/JPG files and textual shader/skin/bot files remain unchanged and accessible inside baseoa/play.pk3.'}
(W/'source-plan.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'files':len(plan),'download_bytes':total,'per_top':{k:sum(r['bytes'] for r in plan if r['path'].startswith('source/assets/'+k+'/')) for k in ['models','textures','maps','2d','music','sound']}},indent=2),flush=True)
if not a.fetch:raise SystemExit(0)
if total>a.max_bytes:raise SystemExit('SOURCE BUDGET REFUSED '+str(total)+' > '+str(a.max_bytes))
T=W/'media-source-tree';T.mkdir(exist_ok=True)
for r in plan:
 r['licence']='GPL-2.0';r['licence_sentence']="The program and data are licensed under the GNU GPL v2. See the file 'COPYING' for details."
 p=T/r['path'];p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists() or p.stat().st_size!=r['bytes']:
  q=p.with_name(p.name+'.part')
  with urllib.request.urlopen(r['url'],timeout=60) as f,q.open('wb') as out:
   while b:=f.read(1024*1024):out.write(b)
  if q.stat().st_size!=r['bytes']:raise RuntimeError('Incomplete source '+r['path'])
  q.replace(p)
 r['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();print(r['sha256'],r['path'],flush=True)
(T/'MANIFEST.json').write_text(json.dumps(report,indent=2)+'\n')
(T/'README-SOURCE.txt').write_text('OpenArena 0.8.8 retained media corresponding-source supplement. GPL version 2.\nOfficial SVN revision 951, pinned source URLs and byte hashes in MANIFEST.json.\nRelease source policy: https://openarena.ws/page.php?14= and https://openarena.ws/about.html\nOriginal flat media and editable shader/skin/bot files remain unchanged in baseoa/play.pk3.\nSarge geometry OBJ is models/players/sarge/grism.obj in play.pk3. Grism animation Blender source is under source/assets/models/grism/.\nOpenArena QVM C source and selected engine port source are separate corresponding-source artifacts linked alongside this archive.\n')
archive=repo/'site/legal/media-source.tgz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:tar.add(T,arcname='openarena-media-source')
print('SOURCE ARCHIVE',archive.stat().st_size,hashlib.sha256(archive.read_bytes()).hexdigest(),flush=True)
(W/'source-plan.json').write_text(json.dumps(report,indent=2)+'\n')
