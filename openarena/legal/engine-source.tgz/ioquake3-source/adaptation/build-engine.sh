#!/usr/bin/env bash
set -euo pipefail
# Install pinned emsdk 3.1.58 and CMake >=3.25 locally before running.
# Set EMSDK and CMAKE_BIN to lane-local paths. Nothing is installed globally.
cd "$(dirname "$0")"
: "${EMSDK:?Set EMSDK to the local emsdk folder}"
: "${CMAKE_BIN:?Set CMAKE_BIN to a local CMake executable}"
source "$EMSDK/emsdk_env.sh" >/dev/null 2>&1
export PATH="$(dirname "$CMAKE_BIN"):$PATH"
export EMCC_CORES=2
if [[ ! -f engine/CMakeLists.txt ]]; then
 git clone https://github.com/ioquake/ioq3.git engine
 git -C engine checkout --detach 83a776283bdb958f82db25554b5ed0966aaf6e49
 git -C engine apply ../engine.patch
fi
emcmake cmake -S engine -B build -DCMAKE_BUILD_TYPE=Release -DPRODUCT_VERSION=1.36_g83a7762 -DBUILD_STANDALONE=ON -DBUILD_GAME_QVMS=OFF -DUSE_OPENAL=OFF -DUSE_CODEC_OPUS=OFF -DUSE_VOIP=OFF -DUSE_MUMBLE=OFF
cmake --build build -j 2
cp build/Release/ioquake3.js build/Release/ioquake3.wasm site/
