#!/usr/bin/env python3
"""Select original OpenArena 0.8.8 assets for three local skirmishes. GPL-2.0."""
import argparse, hashlib, json, re, struct, zipfile
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('baseoa',type=Path);args=parser.parse_args()
root=Path(__file__).resolve().parent;site=root/'site';(site/'baseoa').mkdir(exist_ok=True)
archives={p.name:zipfile.ZipFile(p) for p in sorted(args.baseoa.glob('*.pk3'))}
files={}
for pak,z in archives.items():
 for info in z.infolist():
  if not info.is_dir():files[info.filename.lower()]=(pak,info)
def read(n):
 pak,info=files[n];return archives[pak].read(info)
selected=set();used=set();maps=['oa_dm1','aggressor','oa_minia']
for n in files:
 if n.startswith(('gfx/','icons/','menu/','sprites/','vm/','botfiles/','scripts/','glsl/')):selected.add(n)
 if n.startswith(('models/ammo/','models/gibs/','models/powerups/','models/weaphits/','models/weapons2/','models/weapons/','models/players/sarge/')):selected.add(n)
 if n.startswith('sound/') and (not n.startswith('sound/player/') or len(n.split('/'))==3 or n.startswith(('sound/player/sarge/','sound/player/grism/','sound/player/footsteps/'))) and (not n.startswith('sound/world/') or n=='sound/world/wind1.wav'):selected.add(n)
 if n in ['default.cfg','credits','copying','readme','license.txt','readme.txt','oggvorbis.readme.txt','sdl.readme.txt']:selected.add(n)
 for m in maps:
  if n.startswith(f'maps/{m}.') or n.startswith(f'levelshots/{m}.'):selected.add(n)
for m in maps:
 data=read(f'maps/{m}.bsp');offset,length=struct.unpack_from('<2i',data,16)
 for i in range(offset,offset+length,72):used.add(data[i:i+64].split(b'\0')[0].decode().lower())
shaders={}
for n in sorted(selected):
 if n.endswith('.shader'):
  text=re.sub(r'/\*.*?\*/|//[^\n]*','',read(n).decode(errors='replace'),flags=re.S)
  tokens=re.findall(r'"[^"\n]*"|[^\s{}]+|[{}]',text);i=0
  while i<len(tokens)-1:
   name=tokens[i].strip('"').lower();i+=1
   if tokens[i]!='{':continue
   depth=1;i+=1;block=[]
   while i<len(tokens) and depth:
    t=tokens[i];depth+=int(t=='{')-int(t=='}');block.append(t.strip('"'));i+=1
   shaders[name]=block
for n in sorted(selected):
 if n.endswith('.md3'):
  d=read(n)
  if d[:4]!=b'IDP3':continue
  count,off=struct.unpack_from('<i',d,84)[0],struct.unpack_from('<i',d,100)[0]
  for _ in range(count):
   nsh,so,se=struct.unpack_from('<i',d,off+76)[0],struct.unpack_from('<i',d,off+92)[0],struct.unpack_from('<i',d,off+104)[0]
   for k in range(nsh):used.add(d[off+so+k*68:off+so+k*68+64].split(b'\0')[0].decode(errors='replace').lower())
   off+=se
 if n.endswith('.skin'):
  for line in read(n).decode(errors='replace').splitlines():
   if ',' in line:used.add(line.split(',',1)[1].strip().lower())
 if n.startswith('vm/'):
  for part in read(n).split(b'\0'):
   try:s=part.decode('ascii').lower()
   except UnicodeDecodeError:continue
   if s in shaders or s in files:used.add(s)
# Script references are only expanded for shaders registered by selected maps, models and QVMs.
def resolve(n):
 n=n.lower().strip('"')
 if not n or n.startswith('$') or n in ('-','full','half'):return
 if n in files:selected.add(n);return
 base=n.rsplit('.',1)[0] if n.endswith(('.tga','.jpg','.png')) else n
 for ext in ('.tga','.jpg','.png'):
  if base+ext in files:selected.add(base+ext);return
for name in list(used):
 resolve(name)
 if name in shaders:
  b=shaders[name]
  for i,t in enumerate(b):
   if t.lower() in ('map','clampmap','qer_editorimage') and i+1<len(b):resolve(b[i+1])
   if t.lower()=='animmap':
    for item in b[i+2:]:
     if '/' not in item and not item.endswith(('.tga','.jpg','.png')):break
     resolve(item)
   if t.lower()=='skyparms' and i+1<len(b):
    for side in ('bk','dn','ft','lf','rt','up'):resolve(b[i+1]+'_'+side)
# Models and QVMs construct these small shared paths dynamically.
for n in files:
 if n.startswith(('textures/sfx/','textures/effects/')):selected.add(n)
selected.add('textures/oafx/rocketflare.jpg')
quote="The program and data are licensed under the GNU GPL v2. See the file 'COPYING' for details."
source='https://download.tuxfamily.org/openarena/rel/088/openarena-0.8.8.zip'
def licence_info(n):
 if n=='oggvorbis.readme.txt':return ('BSD-3-Clause notice document',"Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:")
 if n=='sdl.readme.txt':return ('GPL-2.0 package notice, historical SDL LGPL-2.1 library notice',"This library is distributed under the terms of the GNU LGPLv2 license:")
 if n in ('copying','license.txt'):return ('GPL-2.0 licence text, verbatim copying permitted',"Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.")
 return ('GPL-2.0',quote)
rows=[]
with zipfile.ZipFile(site/'baseoa/play.pk3','w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
 for n in sorted(selected):
  data=read(n);pak,info=files[n];info_out=zipfile.ZipInfo(n,date_time=(2012,2,28,20,38,6));info_out.compress_type=zipfile.ZIP_DEFLATED;info_out.external_attr=0o100644<<16;out.writestr(info_out,data)
  licence,sentence=licence_info(n)
  rows.append({'name':n,'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),'licence':licence,'licence_sentence':sentence,'source':source,'archive_member':f'openarena-0.8.8/baseoa/{pak}!/{info.filename}'})
legal=site/'legal';(legal/'DATA.json').write_text(json.dumps(rows,indent=2)+'\n')
text='# OpenArena retained data\n\nVersion 0.8.8. Release ZIP SHA256 5a8faf7f5b51f351b0a1618c06b6b98a5f1a6758f1d39818de2c87df2a0bac4a. Official release MD5 9f353d96d7889c377349d692c3905e5b verified.\n\nLicence sentence from the release readme_088.txt:\n\n> '+quote+'\n\nEvery retained byte below is unchanged from that release. Later PK3s override earlier PK3s in normal engine order. See DATA.json for a machine-readable per-file licence sentence and source address. The page-created play.cfg is GPL-2.0 source in frame.js.\n\nSource archive: '+source+'\n\n| File | Bytes | SHA256 | Licence | Licence sentence | Source | Release member |\n| --- | ---: | --- | --- | --- | --- | --- |\n'
for r in rows:text+=f"| {r['name']} | {r['size']} | {r['sha256']} | {r['licence']} | {r['licence_sentence']} | {r['source']} | {r['archive_member']} |\n"
(root/'DATA.md').write_text(text);(legal/'DATA.md').write_text(text)
print(json.dumps({'files':len(rows),'member_bytes':sum(r['size'] for r in rows),'pk3_bytes':(site/'baseoa/play.pk3').stat().st_size,'pk3_sha256':hashlib.sha256((site/'baseoa/play.pk3').read_bytes()).hexdigest()},indent=2))
