# Host OpenArena

Upload the complete site/ folder to the existing Play static host under any prefix. Keep folder structure and legal/ source archives intact. This lane delivers a local archive and Git bundle; it does not publish or push.

Normal content types: .html text/html, .js application/javascript, .css text/css, .wasm application/wasm, .pk3 application/octet-stream, .json application/json, .txt and .md text/plain, .tgz application/gzip. The page explicitly supplies wasmBinary from ArrayBuffer, so a wrong .wasm content type also works. Whole files are fetched without Range requirements.

Embed:

```html
<iframe src="https://YOUR-OWN-HOST/YOUR-PREFIX/index.html" sandbox="allow-scripts allow-same-origin" style="border:0;width:100%;height:100%"></iframe>
```

Do not add an allow attribute. The game does not request pointer lock, fullscreen, dialogs, workers, cookies, external network or storage. Legal opens in the same frame. Touch move, drag look, fire, jump and weapon switch are available in both orientations. NEXT ARENA cycles the three arenas and preserves the two existing bots.

Round-two repo.bundle adds commits on top of 33fad0adbfa8f6aecab290c2b57f21ab0293d0d5 and declares that prerequisite. In the existing round-one checkout, verify the bundle, fetch its main and fast-forward main. Then copy the delivered site/ folder over its site/ directory. Generated runtime binaries and data are delivered in the site archive. Rerun proof from that checkout:

```sh
git bundle verify /path/to/round-two/repo.bundle
git fetch /path/to/round-two/repo.bundle main
git merge --ff-only FETCH_HEAD
PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 npm_config_cache="$PWD/.npm-cache" npm ci --ignore-scripts --no-audit --no-fund
CHROMIUM_PATH=/absolute/path/to/chromium bash proof/run.sh
```

Use the recorded installed headless Chromium path on this Mac, or install the Playwright Chromium browser locally with PLAYWRIGHT_BROWSERS_PATH set inside the checkout. The proof runs one instance and binds every server to 127.0.0.1 on free ports, then closes its recorded browser and owned servers. See proof/README.md for witness details.

The exact delivered runtime uses Emscripten 3.1.58 and the upstream WebGL 1 renderer. Build with lane-local EMSDK and CMAKE_BIN paths using bash build-engine.sh. Use python3 prepare-data.py /path/to/openarena-0.8.8/baseoa to reproduce the selected data. No package is installed globally.

To refresh corresponding-source archives, extract the delivered engine-source.tgz
and media-source.tgz into .lane/source-input, keeping their top-level folders.
Run python3 pack-sources.py from the checkout. It preserves all upstream source
and licence bytes, overlays the current adaptation, and corrects document grants.
The game-code archive remains unchanged. No source-archive hash is a compiler input.
